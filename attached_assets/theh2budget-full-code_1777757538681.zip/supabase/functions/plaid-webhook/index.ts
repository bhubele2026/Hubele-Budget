// plaid-webhook: receives Plaid webhook events and triggers transaction sync.
// Plaid calls this URL directly — no user auth required.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const PLAID_CLIENT_ID = Deno.env.get("PLAID_CLIENT_ID")?.trim();
const PLAID_SECRET = Deno.env.get("PLAID_SECRET")?.trim();
const PLAID_ENV = (Deno.env.get("PLAID_ENV") ?? "sandbox").trim().toLowerCase();
const PLAID_BASE = PLAID_ENV === "production"
  ? "https://production.plaid.com"
  : PLAID_ENV === "development"
    ? "https://development.plaid.com"
    : "https://sandbox.plaid.com";

async function plaidPost(path: string, body: Record<string, unknown>) {
  const res = await fetch(`${PLAID_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: PLAID_CLIENT_ID, secret: PLAID_SECRET, ...body }),
  });
  const data = await res.json();
  if (!res.ok) {
    console.error(`Plaid ${path} error:`, JSON.stringify(data));
    throw new Error(data?.error_message ?? `Plaid error ${res.status}`);
  }
  return data;
}

// ── Helpers (same as plaid-api) ──

function normDesc(d: string): string {
  return (d ?? "").toLowerCase().replace(/\s+/g, " ").trim();
}

function compositeKey(date: string, description: string, amount: number): string {
  return `${date}|${normDesc(description)}|${Math.abs(amount).toFixed(2)}`;
}

function dateAmountKey(date: string, amount: number): string {
  return `${date}|${Math.abs(amount).toFixed(2)}`;
}

async function syncItem(item: any) {
  const userId = item.user_id;
  const sourceTag = item.account === "amex" ? "amex_plaid" : "plaid_import";

  let cursor = item.cursor ?? undefined;
  const allAdded: any[] = [];
  const allModified: any[] = [];
  const allRemoved: any[] = [];
  let hasMore = true;

  while (hasMore) {
    const syncData = await plaidPost("/transactions/sync", {
      access_token: item.access_token,
      cursor: cursor,
    });
    allAdded.push(...(syncData.added ?? []));
    allModified.push(...(syncData.modified ?? []));
    allRemoved.push(...(syncData.removed ?? []));
    cursor = syncData.next_cursor;
    hasMore = syncData.has_more === true;
  }

  const allTxns = [...allAdded, ...allModified];

  if (allTxns.length === 0 && allRemoved.length === 0) {
    if (cursor) await admin.from("plaid_items").update({ cursor, sync_started_at: null }).eq("id", item.id);
    return { imported: 0, updated: 0, removed: 0 };
  }

  // Handle removals
  const removedIds = allRemoved.map((r: any) => r.transaction_id).filter(Boolean);
  if (removedIds.length > 0) {
    for (let i = 0; i < removedIds.length; i += 100) {
      const batch = removedIds.slice(i, i + 100);
      await admin.from("transactions").delete().in("plaid_transaction_id", batch);
    }
  }

  // Build lookup of ALL existing rows in date range
  const dates = allTxns.map((t: any) => t.date).filter(Boolean).sort();
  const minDate = dates[0];
  const maxDate = dates[dates.length - 1];

  const existingByPlaidId = new Map<string, any>();
  const existingByComposite = new Map<string, any[]>();
  const existingByDateAmount = new Map<string, any[]>();

  if (minDate && maxDate) {
    let offset = 0;
    let fetchMore = true;
    while (fetchMore) {
      const { data: rows } = await admin
        .from("transactions")
        .select("id, date, description, amount, source, type, category, member, notes, plaid_transaction_id, plaid_pending_transaction_id, plaid_account_id")
        .in("source", [sourceTag, "manual", "bank_import", "seed"])
        .eq("user_id", userId)
        .gte("date", minDate)
        .lte("date", maxDate)
        .range(offset, offset + 999);

      for (const row of rows ?? []) {
        if (row.plaid_transaction_id) {
          existingByPlaidId.set(row.plaid_transaction_id, row);
        }
        const cKey = compositeKey(row.date, row.description, Number(row.amount));
        if (!existingByComposite.has(cKey)) existingByComposite.set(cKey, []);
        existingByComposite.get(cKey)!.push(row);

        const daKey = dateAmountKey(row.date, Number(row.amount));
        if (!existingByDateAmount.has(daKey)) existingByDateAmount.set(daKey, []);
        existingByDateAmount.get(daKey)!.push(row);
      }
      fetchMore = (rows?.length ?? 0) === 1000;
      offset += 1000;
    }
  }

  // Process transactions
  const newRows: any[] = [];
  let updatedCount = 0;
  const insertedCompositeKeys = new Set<string>();
  const usedExistingIds = new Set<string>();

  for (const pt of allTxns) {
    const ptId = pt.transaction_id;
    const pendingTxnId = pt.pending_transaction_id ?? null;
    const isPending = pt.pending === true;
    const amount = pt.amount;
    const isIncome = amount < 0;
    const desc = pt.name || pt.merchant_name || "Unknown";
    const absAmount = Math.abs(amount);
    const merchantNote = pt.merchant_name ? `Merchant: ${pt.merchant_name}` : null;
    const plaidType = isIncome ? "income" : "expense";
    const pendingNote = isPending
      ? (merchantNote ? `Pending · ${merchantNote}` : "Pending")
      : merchantNote;

    // Check 1: exact plaid_transaction_id match
    if (ptId && existingByPlaidId.has(ptId)) continue;

    // Check 2: posted replacing pending via pending_transaction_id
    if (!isPending && pendingTxnId) {
      const pendingRow = existingByPlaidId.get(pendingTxnId);
      if (pendingRow && !usedExistingIds.has(pendingRow.id)) {
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_pending_transaction_id: pendingTxnId,
          plaid_account_id: pt.account_id ?? null,
          description: desc,
          notes: merchantNote,
          category: pt.personal_finance_category?.primary ?? pt.category?.[0] ?? pendingRow.category,
        };
        await admin.from("transactions").update(patch).eq("id", pendingRow.id);
        usedExistingIds.add(pendingRow.id);
        if (ptId) existingByPlaidId.set(ptId, pendingRow);
        updatedCount++;
        continue;
      }
    }

    // Check 3: fuzzy pending→posted match by date+amount
    if (!isPending) {
      const daKey = dateAmountKey(pt.date, absAmount);
      const candidates = existingByDateAmount.get(daKey) ?? [];
      const pendingMatch = candidates.find(
        (r) =>
          !usedExistingIds.has(r.id) &&
          r.source === sourceTag &&
          (
            (r.notes && (r.notes as string).startsWith("Pending")) ||
            (r.description && (r.description as string).startsWith("ORIG CO NAME:"))
          )
      );
      if (pendingMatch) {
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_pending_transaction_id: pendingMatch.plaid_transaction_id,
          plaid_account_id: pt.account_id ?? null,
          description: desc,
          notes: merchantNote,
        };
        if (!pendingMatch.category || pendingMatch.category === pt.personal_finance_category?.primary) {
          patch.category = pt.personal_finance_category?.primary ?? pt.category?.[0] ?? null;
        }
        await admin.from("transactions").update(patch).eq("id", pendingMatch.id);
        usedExistingIds.add(pendingMatch.id);
        if (ptId) existingByPlaidId.set(ptId, pendingMatch);
        updatedCount++;
        continue;
      }
    }

    // Check 4: composite key match
    const cKey = compositeKey(pt.date, desc, absAmount);
    const compositeMatches = existingByComposite.get(cKey) ?? [];
    const compositeMatch = compositeMatches.find((r) => !usedExistingIds.has(r.id));
    if (compositeMatch) {
      if (!compositeMatch.plaid_transaction_id && ptId) {
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_account_id: pt.account_id ?? null,
        };
        if (pendingTxnId) patch.plaid_pending_transaction_id = pendingTxnId;
        if (!compositeMatch.notes && pendingNote) patch.notes = pendingNote;
        await admin.from("transactions").update(patch).eq("id", compositeMatch.id);
        updatedCount++;
      }
      usedExistingIds.add(compositeMatch.id);
      if (ptId) existingByPlaidId.set(ptId, compositeMatch);
      continue;
    }

    // Check 5: already queued in this batch
    if (insertedCompositeKeys.has(cKey)) continue;

    newRows.push({
      user_id: userId,
      date: pt.date,
      description: desc,
      type: plaidType,
      category: pt.personal_finance_category?.primary ?? pt.category?.[0] ?? null,
      amount: absAmount,
      notes: pendingNote,
      source: sourceTag,
      plaid_transaction_id: ptId || null,
      plaid_pending_transaction_id: pendingTxnId,
      plaid_account_id: pt.account_id ?? null,
    });

    if (ptId) existingByPlaidId.set(ptId, { plaid_transaction_id: ptId });
    insertedCompositeKeys.add(cKey);
  }

  if (newRows.length > 0) {
    const { data: batch, error: batchErr } = await admin.from("import_batches").insert({
      user_id: userId,
      label: `Plaid webhook sync – ${item.institution_name ?? item.item_id} – ${new Date().toISOString().slice(0, 10)}`,
      row_count: newRows.length,
    }).select("id").single();
    if (batchErr) throw batchErr;

    for (let i = 0; i < newRows.length; i += 500) {
      const chunk = newRows.slice(i, i + 500);
      for (const r of chunk) r.import_batch_id = batch.id;
      const { error: insertErr } = await admin.from("transactions").upsert(chunk, {
        onConflict: "plaid_transaction_id",
        ignoreDuplicates: true,
      });
      if (insertErr) {
        console.error("Insert error (falling back to individual):", insertErr.message);
        for (const row of chunk) {
          await admin.from("transactions").upsert([row], {
            onConflict: "plaid_transaction_id",
            ignoreDuplicates: true,
          });
        }
      }
    }
  }

  if (cursor) await admin.from("plaid_items").update({ cursor, sync_started_at: null }).eq("id", item.id);
  else await admin.from("plaid_items").update({ sync_started_at: null }).eq("id", item.id);

  console.log(`Webhook sync [${item.institution_name}]: ${newRows.length} new, ${updatedCount} updated, ${removedIds.length} removed`);
  return { imported: newRows.length, updated: updatedCount, removed: removedIds.length };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "POST required" }, 405);

  let body: any;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON" }, 400);
  }

  const webhookType = body?.webhook_type;
  const webhookCode = body?.webhook_code;
  const itemId = body?.item_id;

  console.log(`Plaid webhook received: ${webhookType} / ${webhookCode} for item ${itemId}`);

  if (webhookType !== "TRANSACTIONS") {
    return json({ received: true, action: "ignored", reason: `webhook_type=${webhookType}` });
  }

  const syncCodes = [
    "SYNC_UPDATES_AVAILABLE",
    "DEFAULT_UPDATE",
    "INITIAL_UPDATE",
    "HISTORICAL_UPDATE",
  ];

  if (!syncCodes.includes(webhookCode)) {
    console.log(`Ignoring webhook code: ${webhookCode}`);
    return json({ received: true, action: "ignored", reason: `code=${webhookCode}` });
  }

  if (!itemId) {
    return json({ error: "item_id missing from webhook" }, 400);
  }

  try {
    const { data: items } = await admin
      .from("plaid_items")
      .select("*")
      .eq("item_id", itemId);

    const item = items?.[0];
    if (!item) {
      console.error(`Webhook: no plaid_item found for item_id=${itemId}`);
      return json({ received: true, action: "skipped", reason: "item not found" });
    }

    // Sync lock: skip if another sync started <2 minutes ago
    const lockAge = item.sync_started_at
      ? Date.now() - new Date(item.sync_started_at).getTime()
      : Infinity;
    if (lockAge < 120_000) {
      console.log(`Webhook: skipping — sync already in progress for ${itemId} (started ${lockAge}ms ago)`);
      return json({ received: true, action: "skipped", reason: "sync in progress" });
    }

    // Acquire lock
    await admin.from("plaid_items").update({ sync_started_at: new Date().toISOString() }).eq("id", item.id);

    try {
      const result = await syncItem(item);
      return json({ received: true, action: "synced", ...result });
    } catch (e) {
      await admin.from("plaid_items").update({ sync_started_at: null }).eq("id", item.id);
      throw e;
    }
  } catch (e: any) {
    console.error("Webhook sync error:", e);
    return json({ error: e?.message ?? "Sync failed" }, 500);
  }
});

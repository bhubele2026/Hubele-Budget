// ledger-api: shared household endpoint for transactions, match rules, and budget lines.
// Same local-JWT-verify pattern as debts-api so transient auth-server hiccups can't take it offline.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.9.6/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const issuer = `${supabaseUrl}/auth/v1`;
const JWKS = createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));
const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

async function verifyCaller(req: Request) {
  const h = req.headers.get("Authorization") ?? "";
  const token = h.toLowerCase().startsWith("bearer ") ? h.slice(7).trim() : h.trim();
  if (!token) return { ok: false as const, status: 401, error: "Not signed in" };
  try {
    const { payload } = await jwtVerify(token, JWKS, { issuer, audience: "authenticated" });
    if (!payload.sub) return { ok: false as const, status: 401, error: "Token missing user id." };
    return { ok: true as const, userId: payload.sub as string };
  } catch {
    return { ok: false as const, status: 401, error: "Sign-in session is invalid or expired." };
  }
}

async function isOwner(userId: string): Promise<boolean> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data, error } = await admin.from("user_roles").select("role").eq("user_id", userId);
    if (error) {
      console.error("owner lookup failed", error);
      if (attempt < 2) { await new Promise((r) => setTimeout(r, 500)); continue; }
      return false;
    }
    return (data ?? []).some((r: any) => r.role === "owner");
  }
  return false;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (!supabaseUrl || !serviceKey) return json({ error: "Server misconfigured" }, 500);

  const v = await verifyCaller(req);
  if (!v.ok) return json({ error: v.error }, v.status);
  const userId = v.userId;
  const owner = await isOwner(userId);

  let action = "list";
  let payload: any = {};
  if (req.method === "POST") {
    try {
      const body = await req.json();
      action = body?.action ?? "list";
      payload = body?.payload ?? {};
    } catch { /* empty body */ }
  } else {
    action = new URL(req.url).searchParams.get("action") ?? "list";
  }

  try {
    switch (action) {
      case "list": {
        const month = payload?.month as number | undefined; // 1..12
        const year = payload?.year as number | undefined;

        const txQ = admin
          .from("transactions")
          .select("id, date, description, type, category, amount, running_balance, notes, member, source, import_batch_id, weekly_allowance, monthly_allowance, unplanned_allowance, reimbursable, reimbursed, forecast_flag")
          .order("date", { ascending: true })
          .order("created_at", { ascending: true });
        if (!owner) txQ.eq("user_id", userId);
        if (year && month) {
          const start = `${year}-${String(month).padStart(2, "0")}-01`;
          const end = month === 12
            ? `${year + 1}-01-01`
            : `${year}-${String(month + 1).padStart(2, "0")}-01`;
          txQ.gte("date", start).lt("date", end);
        }

        const rulesQ = admin
          .from("match_rules")
          .select("id, keyword, category, type, priority")
          .order("priority", { ascending: false });
        if (!owner) rulesQ.eq("user_id", userId);

        const blQ = admin
          .from("budget_lines")
          .select("id, section, label, budgeted, source, notes, linked_debt_id, paycheck_id, sort_order")
          .order("sort_order", { ascending: true });
        if (!owner) blQ.eq("user_id", userId);

        const [tx, rules, bl] = await Promise.all([txQ, rulesQ, blQ]);
        if (tx.error) throw tx.error;
        if (rules.error) throw rules.error;
        if (bl.error) throw bl.error;

        return json({
          transactions: (tx.data ?? []).map((r: any) => ({
            ...r,
            amount: Number(r.amount),
            running_balance: r.running_balance == null ? null : Number(r.running_balance),
          })),
          rules: rules.data ?? [],
          budget_lines: (bl.data ?? []).map((r: any) => ({ ...r, budgeted: Number(r.budgeted) })),
        });
      }

      case "add_transaction": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.date) return json({ error: "date required" }, 400);
        const { error, data } = await admin.from("transactions").insert({
          user_id: userId,
          date: p.date,
          description: p.description ?? "",
          type: p.type ?? "expense",
          category: p.category ?? null,
          amount: Number(p.amount ?? 0),
          notes: p.notes ?? null,
          member: p.member ?? null,
          source: p.source ?? "manual",
          import_batch_id: p.import_batch_id ?? null,
        }).select("id").single();
        if (error) throw error;
        return json({ ok: true, id: data?.id });
      }

      case "update_transaction": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const patch: Record<string, unknown> = {};
        for (const k of ["date","description","type","category","amount","notes","member","weekly_allowance","monthly_allowance","unplanned_allowance","reimbursable","reimbursed","forecast_flag"]) {
          if (p[k] !== undefined) patch[k] = k === "amount" ? Number(p[k]) : p[k];
        }
        const { error } = await admin.from("transactions").update(patch).eq("id", p.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "delete_transaction": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        if (!payload?.id) return json({ error: "id required" }, 400);
        const { error } = await admin.from("transactions").delete().eq("id", payload.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "import_batch": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const rows = payload?.rows as any[];
        if (!Array.isArray(rows) || rows.length === 0) return json({ error: "rows required" }, 400);
        const { data: batch, error: bErr } = await admin
          .from("import_batches")
          .insert({ user_id: userId, label: payload?.label ?? null, row_count: rows.length })
          .select("id").single();
        if (bErr) throw bErr;
        const batchId = batch.id as string;
        const toInsert = rows.map((r: any) => ({
          user_id: userId,
          date: r.date,
          description: r.description ?? "",
          type: r.type ?? "expense",
          category: r.category ?? null,
          amount: Number(r.amount ?? 0),
          notes: r.notes ?? null,
          member: r.member ?? null,
          source: r.source ?? "bank_import",
          import_batch_id: batchId,
        }));
        const { error: tErr } = await admin.from("transactions").insert(toInsert);
        if (tErr) throw tErr;

        // Optional: save new rules in same call
        const newRules = (payload?.new_rules as any[]) ?? [];
        if (newRules.length) {
          await admin.from("match_rules").insert(
            newRules.map((r: any) => ({
              user_id: userId,
              keyword: String(r.keyword ?? "").trim(),
              category: String(r.category ?? "").trim(),
              type: r.type ?? null,
              priority: Number(r.priority ?? 0),
            })).filter((r) => r.keyword && r.category),
          );
        }
        return json({ ok: true, batch_id: batchId, inserted: toInsert.length });
      }

      case "delete_batch": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        if (!payload?.id) return json({ error: "id required" }, 400);
        await admin.from("transactions").delete().eq("import_batch_id", payload.id);
        await admin.from("import_batches").delete().eq("id", payload.id);
        return json({ ok: true });
      }

      case "add_rule": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.keyword || !p.category) return json({ error: "keyword+category required" }, 400);
        const { error } = await admin.from("match_rules").insert({
          user_id: userId,
          keyword: String(p.keyword).trim(),
          category: String(p.category).trim(),
          type: p.type ?? null,
          priority: Number(p.priority ?? 0),
        });
        if (error) throw error;
        return json({ ok: true });
      }

      case "update_rule": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const patch: Record<string, unknown> = {};
        for (const k of ["keyword","category","type","priority"]) {
          if (p[k] !== undefined) patch[k] = k === "priority" ? Number(p[k]) : p[k];
        }
        const { error } = await admin.from("match_rules").update(patch).eq("id", p.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "delete_rule": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        if (!payload?.id) return json({ error: "id required" }, 400);
        const { error } = await admin.from("match_rules").delete().eq("id", payload.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "seed_budget_lines": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const lines = payload?.lines as any[];
        if (!Array.isArray(lines)) return json({ error: "lines required" }, 400);
        // Only seed if empty (idempotent)
        const { count } = await admin.from("budget_lines").select("id", { count: "exact", head: true });
        if ((count ?? 0) > 0) return json({ ok: true, skipped: true });
        const rows = lines.map((l: any, i: number) => ({
          id: l.id,
          user_id: userId,
          section: l.section,
          label: l.label,
          budgeted: Number(l.budgeted ?? 0),
          source: l.source ?? "editable",
          notes: l.notes ?? null,
          linked_debt_id: l.linked_debt_id ?? null,
          paycheck_id: l.paycheck_id ?? null,
          sort_order: l.sort_order ?? i,
        }));
        const { error } = await admin.from("budget_lines").insert(rows);
        if (error) throw error;
        return json({ ok: true, inserted: rows.length });
      }

      case "upsert_budget_line": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const row: any = {
          id: p.id,
          user_id: userId,
          section: p.section ?? "other",
          label: p.label ?? "Untitled",
          budgeted: Number(p.budgeted ?? 0),
          source: p.source ?? "editable",
          notes: p.notes ?? null,
          linked_debt_id: p.linked_debt_id ?? null,
          paycheck_id: p.paycheck_id ?? null,
          sort_order: p.sort_order ?? 0,
        };
        const { error } = await admin.from("budget_lines").upsert(row, { onConflict: "id" });
        if (error) throw error;
        return json({ ok: true });
      }

      case "delete_budget_line": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        if (!payload?.id) return json({ error: "id required" }, 400);
        const { error } = await admin.from("budget_lines").delete().eq("id", payload.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "list_reimbursables": {
        const q = admin
          .from("transactions")
          .select("id, date, description, amount, source, reimbursed")
          .eq("reimbursable", true)
          .order("date", { ascending: false });
        if (!owner) q.eq("user_id", userId);
        const { data: rows, error: rErr } = await q;
        if (rErr) throw rErr;
        return json({
          transactions: (rows ?? []).map((r: any) => ({
            ...r,
            amount: Number(r.amount),
          })),
        });
      }

      default:
        return json({ error: `unknown action: ${action}` }, 400);
    }
  } catch (e) {
    console.error("ledger-api error", e);
    return json({ error: (e as Error).message ?? "Unknown error" }, 500);
  }
});

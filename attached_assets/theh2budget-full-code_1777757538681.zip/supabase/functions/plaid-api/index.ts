// plaid-api: Plaid Link token creation, public-token exchange, and transaction sync.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

const PLAID_CLIENT_ID = Deno.env.get("PLAID_CLIENT_ID")?.trim();
const PLAID_SECRET = Deno.env.get("PLAID_SECRET")?.trim();
const PLAID_REDIRECT_URI = Deno.env.get("PLAID_REDIRECT_URI")?.trim() ?? "https://theh2budget.lovable.app/banking";
const PLAID_ENV = (Deno.env.get("PLAID_ENV") ?? "sandbox").trim().toLowerCase();
const PLAID_BASE = PLAID_ENV === "production"
  ? "https://production.plaid.com"
  : PLAID_ENV === "development"
    ? "https://development.plaid.com"
    : "https://sandbox.plaid.com";

async function verifyCaller(req: Request) {
  const h = req.headers.get("Authorization") ?? "";
  const token = h.toLowerCase().startsWith("bearer ") ? h.slice(7).trim() : h.trim();
  if (!token) return { ok: false as const, status: 401, error: "Not signed in" };
  try {
    const { data, error } = await admin.auth.getUser(token);
    if (error || !data.user?.id) return { ok: false as const, status: 401, error: "Sign-in session is invalid or expired." };
    return { ok: true as const, userId: data.user.id };
  } catch {
    return { ok: false as const, status: 401, error: "Sign-in session is invalid or expired." };
  }
}

async function isOwner(userId: string) {
  const { data } = await admin.from("user_roles").select("role").eq("user_id", userId);
  return (data ?? []).some((r: any) => r.role === "owner");
}

async function plaidPost(path: string, body: Record<string, unknown>) {
  const res = await fetch(`${PLAID_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ client_id: PLAID_CLIENT_ID, secret: PLAID_SECRET, ...body }),
  });
  const data = await res.json();
  if (!res.ok) {
    console.error(`Plaid ${path} error:`, JSON.stringify(data));
    throw new Error(data?.error_message ?? `Plaid error ${res.status}`);
  }
  return data;
}

// ── Helpers ──

function normDesc(d: string): string {
  return (d ?? "").toLowerCase().replace(/\s+/g, " ").trim();
}

/** Build a composite key for matching rows by date+amount+description */
function compositeKey(date: string, description: string, amount: number): string {
  return `${date}|${normDesc(description)}|${Math.abs(amount).toFixed(2)}`;
}

/** Build a looser key for pending→posted matching: just date+amount */
function dateAmountKey(date: string, amount: number): string {
  return `${date}|${Math.abs(amount).toFixed(2)}`;
}

const USER_EDITABLE_FIELDS = [
  "type", "category", "member", "weekly_allowance", "monthly_allowance",
  "unplanned_allowance", "reimbursable", "reimbursed", "forecast_flag",
] as const;

/**
 * Core sync logic shared by both manual sync and webhook.
 * Returns { imported, updated, removed, skipped }.
 */
export async function syncTransactions(item: any, userId: string) {
  const sourceTag = item.account === "amex" ? "amex_plaid" : "plaid_import";

  // Paginate through all pages of /transactions/sync
  let cursor = item.cursor ?? undefined;
  const allAdded: any[] = [];
  const allModified: any[] = [];
  const allRemoved: any[] = [];
  let hasMore = true;

  while (hasMore) {
    const syncData = await plaidPost("/transactions/sync", {
      access_token: item.access_token,
      cursor: cursor,
    });
    allAdded.push(...(syncData.added ?? []));
    allModified.push(...(syncData.modified ?? []));
    allRemoved.push(...(syncData.removed ?? []));
    cursor = syncData.next_cursor;
    hasMore = syncData.has_more === true;
  }

  const allTxns = [...allAdded, ...allModified];

  if (allTxns.length === 0 && allRemoved.length === 0) {
    if (cursor) await admin.from("plaid_items").update({ cursor, sync_started_at: null }).eq("id", item.id);
    return { imported: 0, updated: 0, removed: 0, skipped: 0 };
  }

  // ── Handle removals ──
  const removedIds = (allRemoved ?? []).map((r: any) => r.transaction_id).filter(Boolean);
  if (removedIds.length > 0) {
    for (let i = 0; i < removedIds.length; i += 100) {
      const batch = removedIds.slice(i, i + 100);
      await admin.from("transactions").delete().in("plaid_transaction_id", batch);
    }
  }

  // ── Build lookup of ALL existing rows in date range ──
  const dates = allTxns.map((t: any) => t.date).filter(Boolean).sort();
  const minDate = dates[0];
  const maxDate = dates[dates.length - 1];

  // Maps for dedup
  const existingByPlaidId = new Map<string, any>();
  const existingByComposite = new Map<string, any[]>(); // key → array of rows
  const existingByDateAmount = new Map<string, any[]>(); // key → array of rows

  if (minDate && maxDate) {
    let offset = 0;
    let fetchMore = true;
    while (fetchMore) {
      const { data: rows } = await admin
        .from("transactions")
        .select("id, date, description, amount, source, type, category, member, notes, weekly_allowance, monthly_allowance, unplanned_allowance, reimbursable, reimbursed, forecast_flag, plaid_transaction_id, plaid_pending_transaction_id, plaid_account_id")
        .in("source", [sourceTag, "manual", "bank_import", "seed"])
        .eq("user_id", userId)
        .gte("date", minDate)
        .lte("date", maxDate)
        .range(offset, offset + 999);

      for (const row of rows ?? []) {
        if (row.plaid_transaction_id) {
          existingByPlaidId.set(row.plaid_transaction_id, row);
        }
        const cKey = compositeKey(row.date, row.description, Number(row.amount));
        if (!existingByComposite.has(cKey)) existingByComposite.set(cKey, []);
        existingByComposite.get(cKey)!.push(row);

        const daKey = dateAmountKey(row.date, Number(row.amount));
        if (!existingByDateAmount.has(daKey)) existingByDateAmount.set(daKey, []);
        existingByDateAmount.get(daKey)!.push(row);
      }
      fetchMore = (rows?.length ?? 0) === 1000;
      offset += 1000;
    }
  }

  // ── Process each Plaid transaction ──
  const newRows: any[] = [];
  let updatedCount = 0;
  let skipped = 0;
  const insertedCompositeKeys = new Set<string>();
  const usedExistingIds = new Set<string>(); // track which existing rows we've already matched

  for (const pt of allTxns) {
    const ptId = pt.transaction_id;
    const pendingTxnId = pt.pending_transaction_id ?? null;
    const isPending = pt.pending === true;
    const amount = pt.amount;
    const isIncome = amount < 0;
    const desc = pt.name || pt.merchant_name || "Unknown";
    const absAmount = Math.abs(amount);
    const merchantNote = pt.merchant_name ? `Merchant: ${pt.merchant_name}` : null;
    const plaidType = isIncome ? "income" : "expense";
    const pendingNote = isPending
      ? (merchantNote ? `Pending · ${merchantNote}` : "Pending")
      : merchantNote;

    // === Check 1: Already have this exact plaid_transaction_id? ===
    if (ptId && existingByPlaidId.has(ptId)) {
      skipped++;
      continue;
    }

    // === Check 2: This is a POSTED transaction that replaces a PENDING one ===
    // Plaid gives us pending_transaction_id on posted txns pointing to the pending version
    if (!isPending && pendingTxnId) {
      const pendingRow = existingByPlaidId.get(pendingTxnId);
      if (pendingRow && !usedExistingIds.has(pendingRow.id)) {
        // Update the pending row → posted: new description, new plaid_id, clear pending note
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_pending_transaction_id: pendingTxnId,
          plaid_account_id: pt.account_id ?? null,
          description: desc,
          notes: merchantNote,
          category: pt.personal_finance_category?.primary ?? pt.category?.[0] ?? pendingRow.category,
        };
        await admin.from("transactions").update(patch).eq("id", pendingRow.id);
        usedExistingIds.add(pendingRow.id);
        if (ptId) existingByPlaidId.set(ptId, pendingRow);
        updatedCount++;
        continue;
      }
    }

    // === Check 3: Fuzzy pending→posted match by date+amount when no pending_transaction_id ===
    // Search ±2 days because Plaid often shifts the date when a pending txn posts.
    if (!isPending) {
      const ptDateMs = new Date(pt.date + "T00:00:00Z").getTime();
      const DAY_MS = 86_400_000;
      let pendingMatch: any = null;
      for (let offset = 0; offset <= 2 && !pendingMatch; offset++) {
        for (const sign of [0, -1, 1]) {
          if (offset === 0 && sign !== 0) continue; // only check exact date once
          const checkMs = ptDateMs + (offset * sign * DAY_MS);
          const checkDate = new Date(checkMs).toISOString().slice(0, 10);
          const daKey = dateAmountKey(checkDate, absAmount);
          const candidates = existingByDateAmount.get(daKey) ?? [];
          pendingMatch = candidates.find(
            (r: any) =>
              !usedExistingIds.has(r.id) &&
              r.source === sourceTag &&
              (
                (r.notes && (r.notes as string).startsWith("Pending")) ||
                (r.description && (r.description as string).startsWith("ORIG CO NAME:"))
              )
          );
          if (pendingMatch) break;
        }
      }
      if (pendingMatch) {
        // Merge: keep user edits from pending row, update with posted data
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_pending_transaction_id: pendingMatch.plaid_transaction_id,
          plaid_account_id: pt.account_id ?? null,
          description: desc,
          date: pt.date, // update to the posted date
          notes: merchantNote,
        };
        // Preserve user-edited type if it differs from the default
        // Only update category if the pending row didn't have a user-set one
        if (!pendingMatch.category || pendingMatch.category === pt.personal_finance_category?.primary) {
          patch.category = pt.personal_finance_category?.primary ?? pt.category?.[0] ?? null;
        }
        await admin.from("transactions").update(patch).eq("id", pendingMatch.id);
        usedExistingIds.add(pendingMatch.id);
        if (ptId) existingByPlaidId.set(ptId, pendingMatch);
        updatedCount++;
        continue;
      }
    }

    // === Check 4: Exact composite key match (date+desc+amount) ===
    const cKey = compositeKey(pt.date, desc, absAmount);
    const compositeMatches = existingByComposite.get(cKey) ?? [];
    const compositeMatch = compositeMatches.find((r) => !usedExistingIds.has(r.id));
    if (compositeMatch) {
      if (!compositeMatch.plaid_transaction_id && ptId) {
        const patch: Record<string, unknown> = {
          plaid_transaction_id: ptId,
          plaid_account_id: pt.account_id ?? null,
        };
        if (pendingTxnId) patch.plaid_pending_transaction_id = pendingTxnId;
        if (!compositeMatch.notes && pendingNote) patch.notes = pendingNote;
        await admin.from("transactions").update(patch).eq("id", compositeMatch.id);
        updatedCount++;
      } else {
        skipped++;
      }
      usedExistingIds.add(compositeMatch.id);
      if (ptId) existingByPlaidId.set(ptId, compositeMatch);
      continue;
    }

    // === Check 5: Already queued for insert in this batch? ===
    if (insertedCompositeKeys.has(cKey)) {
      skipped++;
      continue;
    }

    // === New row — insert ===
    newRows.push({
      user_id: userId,
      date: pt.date,
      description: desc,
      type: plaidType,
      category: pt.personal_finance_category?.primary ?? pt.category?.[0] ?? null,
      amount: absAmount,
      notes: pendingNote,
      source: sourceTag,
      plaid_transaction_id: ptId || null,
      plaid_pending_transaction_id: pendingTxnId,
      plaid_account_id: pt.account_id ?? null,
    });

    if (ptId) existingByPlaidId.set(ptId, { plaid_transaction_id: ptId });
    insertedCompositeKeys.add(cKey);
  }

  if (newRows.length > 0) {
    const { data: batch, error: batchErr } = await admin.from("import_batches").insert({
      user_id: userId,
      label: `Plaid sync – ${item.institution_name ?? item.item_id} – ${new Date().toISOString().slice(0, 10)}`,
      row_count: newRows.length,
    }).select("id").single();
    if (batchErr) throw batchErr;

    for (let i = 0; i < newRows.length; i += 500) {
      const chunk = newRows.slice(i, i + 500);
      for (const r of chunk) r.import_batch_id = batch.id;
      // Use upsert with plaid_transaction_id conflict to handle races
      const { error: insertErr } = await admin.from("transactions").upsert(chunk, {
        onConflict: "plaid_transaction_id",
        ignoreDuplicates: true,
      });
      if (insertErr) {
        console.error("Insert error (falling back to individual inserts):", insertErr.message);
        // Fallback: insert one by one, skip conflicts
        for (const row of chunk) {
          await admin.from("transactions").upsert([row], {
            onConflict: "plaid_transaction_id",
            ignoreDuplicates: true,
          });
        }
      }
    }
  }

  // Update cursor
  if (cursor) {
    await admin.from("plaid_items").update({ cursor, sync_started_at: null }).eq("id", item.id);
  } else {
    await admin.from("plaid_items").update({ sync_started_at: null }).eq("id", item.id);
  }

  const pendingCount = allTxns.filter((t: any) => t.pending === true).length;
  console.log(`Plaid sync [${item.institution_name}]: ${newRows.length} new, ${updatedCount} updated, ${skipped} skipped, ${removedIds.length} removed, ${pendingCount} pending`);
  return {
    imported: newRows.length,
    updated: updatedCount,
    removed: removedIds.length,
    skipped,
    pending: pendingCount,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (!PLAID_CLIENT_ID || !PLAID_SECRET) return json({ error: "Plaid credentials not configured" }, 500);
  if (!["sandbox", "development", "production"].includes(PLAID_ENV)) {
    return json({ error: "Plaid environment must be sandbox, development, or production" }, 500);
  }

  const v = await verifyCaller(req);
  if (!v.ok) return json({ error: v.error }, v.status);
  const userId = v.userId;
  const owner = await isOwner(userId);
  if (!owner) return json({ error: "Owner role required" }, 403);

  let action = "";
  let payload: any = {};
  try {
    const body = await req.json();
    action = body?.action ?? "";
    payload = body?.payload ?? {};
  } catch {
    return json({ error: "Invalid request body" }, 400);
  }

  try {
    switch (action) {
      // ─── 1. Create link token ───
      case "create_link_token": {
        const webhookUrl = `${supabaseUrl}/functions/v1/plaid-webhook`;
        const products = payload?.products ?? ["transactions"];
        const data = await plaidPost("/link/token/create", {
          user: { client_user_id: userId },
          client_name: "H2 Budget",
          products,
          ...(products.includes("transactions") ? { transactions: { days_requested: 730 } } : {}),
          country_codes: ["US"],
          language: "en",
          webhook: webhookUrl,
          ...(PLAID_REDIRECT_URI ? { redirect_uri: PLAID_REDIRECT_URI } : {}),
        });
        return json({ link_token: data.link_token });
      }

      // ─── 2. Exchange public token ───
      case "exchange_token": {
        const publicToken = payload?.public_token;
        if (!publicToken) return json({ error: "public_token required" }, 400);
        const acctTag = payload?.account === "amex" ? "amex" : "banking";

        const data = await plaidPost("/item/public_token/exchange", {
          public_token: publicToken,
        });

        let institutionName = payload?.institution_name ?? null;

        const { error } = await admin.from("plaid_items").upsert({
          user_id: userId,
          access_token: data.access_token,
          item_id: data.item_id,
          institution_name: institutionName,
          account: acctTag,
        }, { onConflict: "item_id" });

        if (error) {
          console.error("Insert plaid_items error:", error);
          throw new Error("Failed to save bank connection");
        }

        return json({ success: true, item_id: data.item_id });
      }

      // ─── 3. Sync transactions ───
      case "sync_transactions": {
        const itemId = payload?.item_id;
        if (!itemId) return json({ error: "item_id required" }, 400);

        const { data: items } = await admin
          .from("plaid_items")
          .select("*")
          .eq("item_id", itemId)
          .eq("user_id", userId);

        const item = items?.[0];
        if (!item) return json({ error: "Bank connection not found" }, 404);

        // Acquire sync lock
        const lockAge = item.sync_started_at
          ? Date.now() - new Date(item.sync_started_at).getTime()
          : Infinity;
        if (lockAge < 120_000) {
          return json({ error: "Sync already in progress", skipped: true }, 409);
        }
        await admin.from("plaid_items").update({ sync_started_at: new Date().toISOString() }).eq("id", item.id);

        try {
          const result = await syncTransactions(item, userId);
          return json(result);
        } catch (e) {
          await admin.from("plaid_items").update({ sync_started_at: null }).eq("id", item.id);
          throw e;
        }
      }

      // ─── 4. Reset cursor ───
      case "reset_cursor": {
        const itemId = payload?.item_id;
        if (!itemId) return json({ error: "item_id required" }, 400);
        const { error } = await admin
          .from("plaid_items")
          .update({ cursor: null })
          .eq("item_id", itemId)
          .eq("user_id", userId);
        if (error) throw error;
        return json({ success: true, message: "Cursor reset. Next sync will fetch all transactions." });
      }

      // ─── 5. Repair/dedupe ───
      case "repair_duplicates": {
        const sourceFilter = payload?.source;
        const sources = sourceFilter ? [sourceFilter] : ["plaid_import", "amex_plaid"];

        let totalDeleted = 0;
        let totalMerged = 0;

        for (const src of sources) {
          let allRows: any[] = [];
          let offset = 0;
          let fetchMore = true;
          while (fetchMore) {
            const { data: rows } = await admin
              .from("transactions")
              .select("id, date, description, amount, source, type, category, member, notes, weekly_allowance, monthly_allowance, unplanned_allowance, reimbursable, reimbursed, forecast_flag, plaid_transaction_id, created_at")
              .eq("source", src)
              .eq("user_id", userId)
              .order("created_at", { ascending: true })
              .range(offset, offset + 999);
            allRows.push(...(rows ?? []));
            fetchMore = (rows?.length ?? 0) === 1000;
            offset += 1000;
          }

          // Group by date+amount (looser matching to catch description variations)
          const groups = new Map<string, any[]>();
          for (const row of allRows) {
            const key = dateAmountKey(row.date, Number(row.amount));
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key)!.push(row);
          }

          const allUpdates: Array<{ id: string; patch: Record<string, unknown> }> = [];
          const allDeletes: string[] = [];

          for (const [, group] of groups) {
            if (group.length <= 1) continue;

            // Check if this is a genuine duplicate group or legitimately different transactions
            // Only merge if descriptions share key identifiers (same merchant/payee)
            // For safety, only merge groups where at least one row is pending or has ORIG CO NAME format
            const hasPendingIndicator = group.some(
              (r: any) =>
                (r.notes && (r.notes as string).startsWith("Pending")) ||
                (r.description && (r.description as string).startsWith("ORIG CO NAME:"))
            );
            if (!hasPendingIndicator) continue;

            // Pick the keeper: prefer the one with a non-pending plaid_transaction_id and clean description
            const keeper = { ...(
              group.find((r: any) => r.plaid_transaction_id && !(r.notes ?? "").startsWith("Pending") && !(r.description ?? "").startsWith("ORIG CO NAME:")) ??
              group.find((r: any) => r.plaid_transaction_id) ??
              group[0]
            ) };
            const toDelete: string[] = [];

            for (const row of group) {
              if (row.id === keeper.id) continue;

              for (const field of USER_EDITABLE_FIELDS) {
                const keeperVal = keeper[field];
                const rowVal = row[field];
                if (field === "type") {
                  if (rowVal === "debt_payment" && keeperVal !== "debt_payment") keeper[field] = rowVal;
                } else if (field === "category" || field === "member") {
                  if (rowVal && !keeperVal) keeper[field] = rowVal;
                } else {
                  if (rowVal === true && !keeperVal) keeper[field] = true;
                }
              }
              if (row.notes && !row.notes.startsWith("Pending") && (!keeper.notes || keeper.notes.startsWith("Pending"))) {
                keeper.notes = row.notes;
              }
              toDelete.push(row.id);
            }

            if (toDelete.length > 0) {
              const patch: Record<string, unknown> = {};
              for (const field of USER_EDITABLE_FIELDS) patch[field] = keeper[field];
              if (keeper.notes !== undefined) patch.notes = keeper.notes;
              allUpdates.push({ id: keeper.id, patch });
              allDeletes.push(...toDelete);
              totalMerged++;
            }
          }

          for (let i = 0; i < allUpdates.length; i += 20) {
            const batch = allUpdates.slice(i, i + 20);
            await Promise.all(batch.map((u) => admin.from("transactions").update(u.patch).eq("id", u.id)));
          }
          for (let i = 0; i < allDeletes.length; i += 200) {
            const batch = allDeletes.slice(i, i + 200);
            await admin.from("transactions").delete().in("id", batch);
          }
          totalDeleted += allDeletes.length;
        }

        console.log(`Repair: merged ${totalMerged} groups, deleted ${totalDeleted} duplicate rows`);
        return json({ merged: totalMerged, deleted: totalDeleted });
      }

      // ─── 6. List connected accounts ───
      case "list_items": {
        const acctFilter = payload?.account;
        let q = admin
          .from("plaid_items")
          .select("id, item_id, institution_name, account, created_at")
          .eq("user_id", userId);
        if (acctFilter) q = q.eq("account", acctFilter);
        const { data: items } = await q.order("created_at", { ascending: false });

        return json({ items: items ?? [] });
      }

      // ─── 7. Get accounts for a plaid item ───
      case "get_accounts": {
        const itemId = payload?.item_id;
        if (!itemId) return json({ error: "item_id required" }, 400);

        const { data: items } = await admin
          .from("plaid_items")
          .select("*")
          .eq("item_id", itemId)
          .eq("user_id", userId);
        const item = items?.[0];
        if (!item) return json({ error: "Bank connection not found" }, 404);

        const accountsData = await plaidPost("/accounts/get", {
          access_token: item.access_token,
        });

        // Try to get liabilities for min payment info
        let liabilities: any = null;
        try {
          liabilities = await plaidPost("/liabilities/get", {
            access_token: item.access_token,
          });
        } catch {
          // liabilities product may not be supported for this item
        }

        const creditLiabs = liabilities?.liabilities?.credit ?? [];
        const accounts = (accountsData.accounts ?? []).map((a: any) => {
          const liab = creditLiabs.find((l: any) => l.account_id === a.account_id);
          return {
            account_id: a.account_id,
            name: a.name,
            official_name: a.official_name,
            type: a.type,
            subtype: a.subtype,
            current_balance: a.balances?.current ?? null,
            minimum_payment: liab?.minimum_payment_amount ?? null,
          };
        });

        return json({ accounts });
      }

      // ─── 8. Sync debt balances from Plaid ───
      case "sync_debt_balances": {
        // Get all debts with plaid links
        const { data: debts } = await admin
          .from("debts")
          .select("id, plaid_item_id, plaid_account_id")
          .eq("user_id", userId)
          .not("plaid_item_id", "is", null)
          .not("plaid_account_id", "is", null);

        if (!debts || debts.length === 0) {
          return json({ updated: 0, message: "No debts linked to Plaid" });
        }

        // Group by item_id to minimize API calls
        const byItem = new Map<string, typeof debts>();
        for (const d of debts) {
          const key = d.plaid_item_id!;
          if (!byItem.has(key)) byItem.set(key, []);
          byItem.get(key)!.push(d);
        }

        let updated = 0;
        const errors: string[] = [];

        for (const [itemId, debtGroup] of byItem) {
          const { data: items } = await admin
            .from("plaid_items")
            .select("*")
            .eq("item_id", itemId)
            .eq("user_id", userId);
          const item = items?.[0];
          if (!item) { errors.push(`Item ${itemId} not found`); continue; }

          try {
            const accountsData = await plaidPost("/accounts/get", {
              access_token: item.access_token,
            });

            let liabilities: any = null;
            try {
              liabilities = await plaidPost("/liabilities/get", {
                access_token: item.access_token,
              });
            } catch { /* not supported */ }
            const creditLiabs = liabilities?.liabilities?.credit ?? [];

            for (const debt of debtGroup) {
              const acct = (accountsData.accounts ?? []).find(
                (a: any) => a.account_id === debt.plaid_account_id
              );
              if (!acct) { errors.push(`Account ${debt.plaid_account_id} not found`); continue; }

              const patch: Record<string, unknown> = {
                balance: Math.abs(acct.balances?.current ?? 0),
                last_balance_update: new Date().toISOString(),
              };

              const liab = creditLiabs.find((l: any) => l.account_id === debt.plaid_account_id);
              if (liab?.minimum_payment_amount != null) {
                patch.min_payment = liab.minimum_payment_amount;
              }

              await admin.from("debts").update(patch).eq("id", debt.id);
              updated++;
            }
          } catch (e: any) {
            errors.push(`Item ${itemId}: ${e.message}`);
          }
        }

        return json({ updated, errors: errors.length ? errors : undefined });
      }

      default:
        return json({ error: `Unknown action: ${action}` }, 400);
    }
  } catch (e: any) {
    console.error("plaid-api error:", e);
    return json({ error: e?.message ?? "Internal error" }, 500);
  }
});

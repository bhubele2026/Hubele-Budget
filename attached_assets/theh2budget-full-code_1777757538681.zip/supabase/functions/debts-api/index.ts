// debts-api: server-side cloud endpoint for debts + avalanche settings.
//
// Auth: verifies the caller's JWT locally with the project's JWKS (no network
// round-trip to GoTrue's /user, which has been intermittently failing with
// "Unexpected failure"). Once verified, we use the service role key to talk to
// the database and enforce the owner role ourselves. This means a transient
// auth-server hiccup can no longer take debt access offline.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.9.6/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const issuer = `${supabaseUrl}/auth/v1`;
const JWKS = createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));

const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

type DebtRow = {
  id: string;
  creditor: string;
  apr: number;
  balance: number;
  min_payment: number;
  status: string;
  notes: string | null;
  sort_order: number;
  last_balance_update: string | null;
  statement_day: number | null;
  due_day: number | null;
  plaid_item_id: string | null;
  plaid_account_id: string | null;
};

type SettingsRow = {
  strategy: string;
  extra_source: string;
  manual_extra: number;
  budget_mode: string;
};

const SETTINGS_DEFAULTS: SettingsRow = {
  strategy: "avalanche",
  extra_source: "budget_net",
  manual_extra: 0,
  budget_mode: "budgeted",
};

async function verifyCaller(req: Request): Promise<
  | { ok: true; userId: string }
  | { ok: false; status: number; error: string }
> {
  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.toLowerCase().startsWith("bearer ")
    ? authHeader.slice(7).trim()
    : authHeader.trim();
  if (!token) return { ok: false, status: 401, error: "Not signed in" };
  try {
    const { payload } = await jwtVerify(token, JWKS, {
      issuer,
      audience: "authenticated",
    });
    if (!payload.sub) {
      return { ok: false, status: 401, error: "Token missing user id. Please sign in again." };
    }
    return { ok: true, userId: payload.sub as string };
  } catch (_e) {
    return {
      ok: false,
      status: 401,
      error: "Sign-in session is invalid or expired. Please sign out and back in.",
    };
  }
}

async function isOwner(userId: string): Promise<boolean> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data, error } = await admin.from("user_roles").select("role").eq("user_id", userId);
    if (error) {
      console.error("owner lookup failed", error);
      if (attempt < 2) { await new Promise((r) => setTimeout(r, 500)); continue; }
      return false;
    }
    return (data ?? []).some((r: any) => r.role === "owner");
  }
  return false;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (!supabaseUrl || !serviceKey) {
    return json({ error: "Server misconfigured" }, 500);
  }

  const verified = await verifyCaller(req);
  if (!verified.ok) return json({ error: verified.error }, verified.status);
  const userId = verified.userId;

  // Owner check: both Brad and Hannah are owners and share the household debts.
  // We mirror the household-share semantics of the original RLS policy: any
  // owner can see/edit; non-owners can only touch their own rows.
  const owner = await isOwner(userId);

  let action = "list";
  let payload: any = {};
  if (req.method === "POST") {
    try {
      const body = await req.json();
      action = body?.action ?? "list";
      payload = body?.payload ?? {};
    } catch {
      // empty body → list
    }
  } else {
    const u = new URL(req.url);
    action = u.searchParams.get("action") ?? "list";
  }

  try {
    switch (action) {
      case "list": {
        // Owners read the shared household list; non-owners only their own.
        const debtsQuery = admin
          .from("debts")
          .select(
            "id, creditor, apr, balance, min_payment, status, notes, sort_order, last_balance_update, statement_day, due_day, plaid_item_id, plaid_account_id",
          )
          .order("apr", { ascending: false })
          .order("balance", { ascending: false });
        if (!owner) debtsQuery.eq("user_id", userId);

        const settingsQuery = admin
          .from("avalanche_settings")
          .select("strategy, extra_source, manual_extra, budget_mode")
          .eq("user_id", userId)
          .maybeSingle();

        const [debtsRes, settingsRes] = await Promise.all([
          debtsQuery,
          settingsQuery,
        ]);

        if (debtsRes.error) throw debtsRes.error;

        let settings: SettingsRow = SETTINGS_DEFAULTS;
        if (settingsRes.error && (settingsRes.error as any).code !== "PGRST116") {
          throw settingsRes.error;
        }
        if (settingsRes.data) {
          settings = {
            strategy: settingsRes.data.strategy,
            extra_source: settingsRes.data.extra_source,
            manual_extra: Number(settingsRes.data.manual_extra),
            budget_mode: settingsRes.data.budget_mode,
          };
        } else {
          const { error: insErr } = await admin
            .from("avalanche_settings")
            .insert({ user_id: userId });
          if (insErr && (insErr as any).code !== "23505") {
            console.warn("settings lazy-insert failed", insErr);
          }
        }

        const debts = (debtsRes.data ?? []).map((r: DebtRow) => ({
          id: r.id,
          creditor: r.creditor,
          apr: Number(r.apr),
          balance: Number(r.balance),
          min_payment: Number(r.min_payment),
          status: r.status,
          notes: r.notes,
          sort_order: r.sort_order,
          last_balance_update: r.last_balance_update,
          statement_day: r.statement_day,
          due_day: r.due_day,
          plaid_item_id: r.plaid_item_id,
          plaid_account_id: r.plaid_account_id,
        }));

        return json({ debts, settings });
      }

      case "add_debt": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.creditor) return json({ error: "creditor required" }, 400);
        const { data: existing } = await admin
          .from("debts")
          .select("sort_order")
          .order("sort_order", { ascending: false })
          .limit(1);
        const nextSort = (existing?.[0]?.sort_order ?? 0) + 1;
        const { error } = await admin.from("debts").insert({
          user_id: userId,
          creditor: String(p.creditor),
          apr: Number(p.apr ?? 0),
          balance: Number(p.balance ?? 0),
          min_payment: Number(p.min_payment ?? 0),
          status: String(p.status ?? "active"),
          notes: p.notes ?? null,
          sort_order: p.sort_order ?? nextSort,
        });
        if (error) throw error;
        return json({ ok: true });
      }

      case "update_debt": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const patch: Record<string, unknown> = {};
        if (p.creditor !== undefined) patch.creditor = p.creditor;
        if (p.apr !== undefined) patch.apr = Number(p.apr);
        if (p.balance !== undefined) patch.balance = Number(p.balance);
        if (p.min_payment !== undefined) patch.min_payment = Number(p.min_payment);
        if (p.status !== undefined) patch.status = p.status;
        if (p.notes !== undefined) patch.notes = p.notes ?? null;
        if (p.sort_order !== undefined) patch.sort_order = p.sort_order;
        if (p.last_balance_update !== undefined) {
          patch.last_balance_update = p.last_balance_update;
        }
        if (p.statement_day !== undefined) {
          patch.statement_day = p.statement_day;
        }
        if (p.due_day !== undefined) {
          patch.due_day = p.due_day;
        }
        const { error } = await admin
          .from("debts")
          .update(patch)
          .eq("id", p.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "delete_debt": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const { error } = await admin.from("debts").delete().eq("id", p.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "set_status": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id || !p.status) return json({ error: "id+status required" }, 400);
        const patch: Record<string, unknown> = { status: p.status };
        if (p.status === "paid_off") patch.balance = 0;
        const { error } = await admin
          .from("debts")
          .update(patch)
          .eq("id", p.id);
        if (error) throw error;
        return json({ ok: true });
      }

      case "update_settings": {
        const p = payload ?? {};
        const patch: Record<string, unknown> = {};
        if (p.strategy !== undefined) patch.strategy = p.strategy;
        if (p.extra_source !== undefined) patch.extra_source = p.extra_source;
        if (p.manual_extra !== undefined) patch.manual_extra = Number(p.manual_extra);
        if (p.budget_mode !== undefined) patch.budget_mode = p.budget_mode;
        const { error } = await admin
          .from("avalanche_settings")
          .upsert({ user_id: userId, ...patch }, { onConflict: "user_id" });
        if (error) throw error;
        return json({ ok: true });
      }

      default:
        return json({ error: `unknown action: ${action}` }, 400);
    }
  } catch (e) {
    console.error("debts-api error", e);
    return json({ error: (e as Error).message ?? "Unknown error" }, 500);
  }
});

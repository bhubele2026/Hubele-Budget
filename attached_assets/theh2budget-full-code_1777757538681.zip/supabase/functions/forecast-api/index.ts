// forecast-api: shared household endpoint for recurring cash-forecast items.
// Same local-JWT-verify + service-role pattern as debts-api / ledger-api so
// transient REST schema-cache hiccups can't take the Forecast page offline.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.9.6/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const issuer = `${supabaseUrl}/auth/v1`;
const JWKS = createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));
const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

async function verifyCaller(req: Request) {
  const h = req.headers.get("Authorization") ?? "";
  const token = h.toLowerCase().startsWith("bearer ") ? h.slice(7).trim() : h.trim();
  if (!token) return { ok: false as const, status: 401, error: "Not signed in" };
  try {
    const { payload } = await jwtVerify(token, JWKS, { issuer, audience: "authenticated" });
    if (!payload.sub) return { ok: false as const, status: 401, error: "Token missing user id." };
    return { ok: true as const, userId: payload.sub as string };
  } catch {
    return { ok: false as const, status: 401, error: "Sign-in session is invalid or expired." };
  }
}

async function isOwner(userId: string): Promise<boolean> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const { data, error } = await admin.from("user_roles").select("role").eq("user_id", userId);
    if (error) {
      console.error("owner lookup failed", error);
      if (attempt < 2) { await new Promise((r) => setTimeout(r, 500)); continue; }
      return false;
    }
    return (data ?? []).some((r: any) => r.role === "owner");
  }
  return false;
}

const COLS = "id, kind, label, amount, category, cadence, anchor_date, day_of_month, linked_debt_id, stops_at_payoff, active, notes, sort_order";

// Retry transient PGRST schema-cache / connection errors. The direct REST
// endpoint can flap during instance recovery; admin client uses the same
// connection but inside the edge runtime we control retries cleanly.
async function withRetry<T>(fn: () => Promise<T>, label: string): Promise<T> {
  let lastErr: any;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      return await fn();
    } catch (e: any) {
      lastErr = e;
      const code = e?.code ?? "";
      const msg = (e?.message ?? "").toLowerCase();
      const transient =
        code === "PGRST001" || code === "PGRST002" ||
        msg.includes("schema cache") || msg.includes("no connection") ||
        msg.includes("recovery") || msg.includes("terminated");
      if (!transient) throw e;
      await new Promise((r) => setTimeout(r, 300 * Math.pow(2, attempt)));
    }
  }
  console.error(`forecast-api ${label} gave up`, lastErr);
  throw lastErr;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (!supabaseUrl || !serviceKey) return json({ error: "Server misconfigured" }, 500);

  const v = await verifyCaller(req);
  if (!v.ok) return json({ error: v.error }, v.status);
  const userId = v.userId;
  const owner = await isOwner(userId);

  let action = "list";
  let payload: any = {};
  if (req.method === "POST") {
    try {
      const body = await req.json();
      action = body?.action ?? "list";
      payload = body?.payload ?? {};
    } catch { /* empty body */ }
  } else {
    action = new URL(req.url).searchParams.get("action") ?? "list";
  }

  try {
    switch (action) {
      case "list": {
        const data = await withRetry(async () => {
          const q = admin
            .from("recurring_items")
            .select(COLS)
            .eq("active", true)
            .order("sort_order", { ascending: true });
          if (!owner) q.eq("user_id", userId);
          const r = await q;
          if (r.error) throw r.error;
          return r.data ?? [];
        }, "list");

        const items = data.map((r: any) => ({
          id: r.id,
          kind: r.kind,
          label: r.label,
          amount: Number(r.amount),
          category: r.category,
          cadence: r.cadence,
          anchor_date: r.anchor_date,
          day_of_month: r.day_of_month,
          linked_debt_id: r.linked_debt_id,
          stops_at_payoff: !!r.stops_at_payoff,
          active: !!r.active,
          notes: r.notes,
          sort_order: r.sort_order,
        }));
        return json({ items });
      }

      case "add_item": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        const row = {
          user_id: userId,
          kind: String(p.kind ?? "expense"),
          label: String(p.label ?? "New item"),
          amount: Number(p.amount ?? 0),
          category: p.category ?? null,
          cadence: String(p.cadence ?? "monthly"),
          anchor_date: p.anchor_date ?? new Date().toISOString().slice(0, 10),
          day_of_month: p.day_of_month ?? null,
          linked_debt_id: p.linked_debt_id ?? null,
          stops_at_payoff: p.stops_at_payoff ?? (p.kind === "debt_min"),
          active: p.active ?? true,
          notes: p.notes ?? null,
          sort_order: Number(p.sort_order ?? 100),
        };
        const r = await withRetry(() => admin.from("recurring_items").insert(row).select("id").single(), "add");
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true, id: (r as any).data?.id });
      }

      case "update_item": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.id) return json({ error: "id required" }, 400);
        const patch: Record<string, unknown> = {};
        for (const k of [
          "kind","label","amount","category","cadence","anchor_date",
          "day_of_month","linked_debt_id","stops_at_payoff","active","notes","sort_order",
        ]) {
          if (p[k] !== undefined) {
            patch[k] = (k === "amount" || k === "sort_order") ? Number(p[k]) : p[k];
          }
        }
        const r = await withRetry(() => admin.from("recurring_items").update(patch).eq("id", p.id), "update");
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true });
      }

      case "delete_item": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        if (!payload?.id) return json({ error: "id required" }, 400);
        const r = await withRetry(() => admin.from("recurring_items").delete().eq("id", payload.id), "delete");
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true });
      }

      case "list_resolutions": {
        // Fetch resolutions, then enrich txn-based ones with transaction details
        const q = admin.from("forecast_event_resolutions").select("*");
        if (!owner) q.eq("user_id", userId);
        const r = await withRetry(() => q, "list_resolutions");
        if ((r as any).error) throw (r as any).error;
        const rawResolutions = (r as any).data ?? [];

        // Collect matched_txn_ids to batch-fetch transaction details
        const txnIds = rawResolutions
          .map((res: any) => res.matched_txn_id)
          .filter(Boolean) as string[];

        let txnMap: Record<string, any> = {};
        if (txnIds.length > 0) {
          const txnResult = await admin
            .from("transactions")
            .select("id, date, description, amount, type, forecast_flag")
            .in("id", txnIds);
          if (!txnResult.error && txnResult.data) {
            for (const t of txnResult.data) {
              txnMap[t.id] = t;
            }
          }
        }

        // Enrich resolutions with transaction metadata
        const enriched = rawResolutions.map((res: any) => {
          if (res.matched_txn_id && txnMap[res.matched_txn_id]) {
            const t = txnMap[res.matched_txn_id];
            return {
              ...res,
              txn_date: t.date,
              txn_description: t.description,
              txn_amount: Number(t.amount),
              txn_type: t.type,
              txn_forecast_flag: !!t.forecast_flag,
            };
          }
          return res;
        });

        return json({ resolutions: enriched });
      }

      case "resolve_event": {
        // payload: { recurring_item_id?, occurrence_date?, status, matched_txn_id?, notes? }
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        if (!p.status) return json({ error: "status required" }, 400);
        const row: Record<string, unknown> = {
          user_id: userId,
          recurring_item_id: p.recurring_item_id ?? null,
          occurrence_date: p.occurrence_date ?? null,
          status: String(p.status),
          matched_txn_id: p.matched_txn_id ?? null,
          notes: p.notes ?? null,
        };
        // upsert by (user, item, date) when an event resolution; else by (user, txn).
        let r: any;
        if (row.recurring_item_id) {
          r = await withRetry(
            () => admin
              .from("forecast_event_resolutions")
              .upsert(row, { onConflict: "user_id,recurring_item_id,occurrence_date" })
              .select("id")
              .single(),
            "resolve_event_item",
          );
        } else if (row.matched_txn_id) {
          r = await withRetry(
            () => admin
              .from("forecast_event_resolutions")
              .upsert(row, { onConflict: "user_id,matched_txn_id" })
              .select("id")
              .single(),
            "resolve_event_txn",
          );
        } else {
          return json({ error: "recurring_item_id or matched_txn_id required" }, 400);
        }
        if (r.error) throw r.error;
        return json({ ok: true, id: r.data?.id });
      }

      case "unresolve_event": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const p = payload ?? {};
        let q = admin.from("forecast_event_resolutions").delete().eq("user_id", userId);
        if (p.id) q = q.eq("id", p.id);
        else if (p.recurring_item_id && p.occurrence_date) {
          q = q.eq("recurring_item_id", p.recurring_item_id).eq("occurrence_date", p.occurrence_date);
        } else if (p.matched_txn_id) {
          q = q.eq("matched_txn_id", p.matched_txn_id);
        } else {
          return json({ error: "id or (recurring_item_id+occurrence_date) or matched_txn_id required" }, 400);
        }
        const r = await withRetry(() => q, "unresolve_event");
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true });
      }

      case "list_closeouts": {
        const q = admin.from("forecast_month_closeouts").select("month, closed_at");
        if (!owner) q.eq("user_id", userId);
        const r = await withRetry(() => q, "list_closeouts");
        if ((r as any).error) throw (r as any).error;
        return json({ closeouts: (r as any).data ?? [] });
      }

      case "closeout_month": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const month = String(payload?.month ?? "");
        if (!/^\d{4}-\d{2}$/.test(month)) return json({ error: "month must be YYYY-MM" }, 400);
        const r = await withRetry(
          () => admin
            .from("forecast_month_closeouts")
            .upsert({ user_id: userId, month }, { onConflict: "user_id,month" }),
          "closeout_month",
        );
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true });
      }

      case "reopen_month": {
        if (!owner) return json({ error: "Owner role required" }, 403);
        const month = String(payload?.month ?? "");
        if (!/^\d{4}-\d{2}$/.test(month)) return json({ error: "month must be YYYY-MM" }, 400);
        const r = await withRetry(
          () => admin
            .from("forecast_month_closeouts")
            .delete()
            .eq("user_id", userId)
            .eq("month", month),
          "reopen_month",
        );
        if ((r as any).error) throw (r as any).error;
        return json({ ok: true });
      }

      default:
        return json({ error: `unknown action: ${action}` }, 400);
    }
  } catch (e) {
    console.error("forecast-api error", e);
    return json({ error: (e as Error).message ?? "Unknown error" }, 500);
  }
});

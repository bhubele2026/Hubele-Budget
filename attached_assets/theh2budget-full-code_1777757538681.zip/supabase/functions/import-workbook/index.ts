import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import * as XLSX from "https://esm.sh/xlsx@0.18.5";
import { createRemoteJWKSet, jwtVerify } from "https://deno.land/x/jose@v5.9.6/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

type Row = (string | number | null)[];

const toNum = (v: any): number => {
  if (v === null || v === undefined || v === "" || v === "—") return 0;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/[$,]/g, ""));
  return isNaN(n) ? 0 : n;
};
const toStr = (v: any): string | null =>
  v === null || v === undefined || v === "" ? null : String(v);
const excelDate = (v: any): string | null => {
  if (!v) return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    if (!d) return null;
    return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const d = new Date(v);
  return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
};

// JWKS is cached across requests by jose internally.
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const issuer = `${supabaseUrl}/auth/v1`;
const JWKS = createRemoteJWKSet(new URL(`${issuer}/.well-known/jwks.json`));

async function verifyCaller(req: Request): Promise<
  | { ok: true; userId: string }
  | { ok: false; status: number; error: string }
> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return { ok: false, status: 401, error: "Missing bearer token. Please sign in again." };
  }
  const token = authHeader.replace(/^Bearer\s+/i, "");
  try {
    const { payload } = await jwtVerify(token, JWKS, {
      issuer,
      audience: "authenticated",
    });
    if (!payload.sub) {
      return { ok: false, status: 401, error: "Token missing user id. Please sign in again." };
    }
    return { ok: true, userId: payload.sub as string };
  } catch (_e) {
    return {
      ok: false,
      status: 401,
      error:
        "Your sign-in session could not be verified (invalid or expired token). Please sign out and sign back in.",
    };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const url = new URL(req.url);
    const checkAuthOnly = url.searchParams.get("check") === "auth";

    const verified = await verifyCaller(req);
    if (!verified.ok) return json(verified.status, { error: verified.error });
    const userId = verified.userId;

    const admin = createClient(supabaseUrl, serviceKey);

    // Owner check (use service role so RLS cannot block this verification step)
    const { data: roles, error: roleErr } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (roleErr) return json(500, { error: `Role lookup failed: ${roleErr.message}` });
    const isOwner = (roles ?? []).some((r: any) => r.role === "owner");
    if (!isOwner) return json(403, { error: "Owner role required to run the import." });

    if (checkAuthOnly) {
      return json(200, { ok: true, userId, role: "owner", check: "auth" });
    }

    // Parse uploaded workbook (binary body)
    const buf = new Uint8Array(await req.arrayBuffer());
    if (buf.byteLength === 0) {
      return json(400, { error: "Empty request body. Please attach the workbook file." });
    }

    let wb: XLSX.WorkBook;
    try {
      wb = XLSX.read(buf, { type: "array", cellDates: false });
    } catch (e: any) {
      return json(400, { error: `Could not read workbook: ${e?.message ?? e}` });
    }

    const REQUIRED = [
      "Debt Tracker",
      "Monthly Budget",
      "Recurring Items",
      "Mapping",
      "Payments",
      "Monthly Tracking",
    ];
    const missing = REQUIRED.filter((s) => !wb.Sheets[s]);
    if (missing.length) {
      return json(400, {
        error: `Workbook is missing required sheet(s): ${missing.join(", ")}. Nothing was changed.`,
      });
    }

    const sheet = (name: string): Row[] => {
      const ws = wb.Sheets[name];
      if (!ws) return [];
      return XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, blankrows: false }) as Row[];
    };

    const summary: Record<string, { inserted: number; errors: string[] }> = {};
    const log = (k: string, inserted: number, errors: string[] = []) => {
      summary[k] = { inserted, errors };
    };

    // --- Clear ---
    const ZERO = "00000000-0000-0000-0000-000000000000";
    for (const t of [
      "transactions",
      "budget_lines",
      "budget_months",
      "recurring_items",
      "mapping_rules",
      "monthly_snapshots",
      "debts",
      "budget_categories",
    ]) {
      const { error } = await admin.from(t).delete().neq("id", ZERO);
      if (error) return json(500, { error: `Clear ${t} failed: ${error.message}`, summary });
    }

    // --- Debts ---
    const dt = sheet("Debt Tracker");
    const debts: any[] = [];
    for (let i = 4; i < dt.length; i++) {
      const r = dt[i];
      if (!r || !r[1] || String(r[1]).toUpperCase() === "TOTALS") continue;
      if (!toStr(r[1])) continue;
      debts.push({
        name: String(r[1]),
        type: toStr(r[2]),
        apr: toNum(r[3]),
        balance: toNum(r[4]),
        min_payment: toNum(r[5]),
        auto_paid: String(r[6] ?? "").toLowerCase() === "yes",
        source: toStr(r[7]),
        statement_date: toStr(r[8]),
        notes: toStr(r[9]),
        apr_status: toStr(r[10]),
        effective_balance: toNum(r[11]),
        effective_min_pmt: toNum(r[12]),
        total_paid: toNum(r[13]),
        interest_accrued: toNum(r[14]),
        sort_order: i - 4,
      });
    }
    let insDebts: any[] = [];
    if (debts.length) {
      const { data, error } = await admin.from("debts").insert(debts).select("id,name");
      if (error) return json(500, { error: `Insert debts failed: ${error.message}`, summary });
      insDebts = data ?? [];
    }
    log("debts", insDebts.length);
    const debtByName = new Map(insDebts.map((d: any) => [d.name, d.id]));

    // --- Budget categories ---
    const mb = sheet("Monthly Budget");
    const cats: any[] = [];
    const lines: { name: string; budgeted: number; notes: string | null }[] = [];
    let currentGroup = "";
    let order = 0;
    for (let i = 5; i < mb.length; i++) {
      const r = mb[i];
      if (!r) continue;
      const num = r[0];
      const label = toStr(r[1]);
      if (!label) continue;
      if (num === null && r[2] === null) {
        if (!String(label).toLowerCase().startsWith("subtotal")) currentGroup = String(label);
        continue;
      }
      if (String(label).toLowerCase().startsWith("subtotal")) continue;
      cats.push({
        name: label,
        group_name: currentGroup,
        default_budget: toNum(r[2]),
        sort_order: order++,
        notes: toStr(r[6]),
      });
      lines.push({ name: label, budgeted: toNum(r[2]), notes: toStr(r[6]) });
    }
    let insCats: any[] = [];
    if (cats.length) {
      const { data, error } = await admin
        .from("budget_categories")
        .insert(cats)
        .select("id,name");
      if (error)
        return json(500, { error: `Insert budget_categories failed: ${error.message}`, summary });
      insCats = data ?? [];
    }
    log("budget_categories", insCats.length);
    const catByName = new Map(insCats.map((c: any) => [c.name, c.id]));

    // --- Budget month + lines ---
    const { data: bm, error: bmErr } = await admin
      .from("budget_months")
      .insert({ year: 2026, month: 4 })
      .select("id")
      .single();
    if (bmErr) return json(500, { error: `Insert budget_months failed: ${bmErr.message}`, summary });
    log("budget_months", 1);

    const lineRows = lines
      .filter((l) => catByName.has(l.name))
      .map((l) => ({
        budget_month_id: bm!.id,
        category_id: catByName.get(l.name)!,
        budgeted: l.budgeted,
        notes: l.notes,
      }));
    if (lineRows.length) {
      const { data: il, error: lErr } = await admin
        .from("budget_lines")
        .insert(lineRows)
        .select("id");
      if (lErr) return json(500, { error: `Insert budget_lines failed: ${lErr.message}`, summary });
      log("budget_lines", il?.length ?? 0);
    } else {
      log("budget_lines", 0);
    }

    // --- Recurring items ---
    const ri = sheet("Recurring Items");
    const recRows: any[] = [];
    for (let i = 5; i < ri.length; i++) {
      const r = ri[i];
      if (!r || !toStr(r[1])) continue;
      const name = String(r[1]);
      const kind = String(r[2] ?? "Expense");
      recRows.push({
        name,
        kind,
        amount: toNum(r[3]),
        frequency: toStr(r[4]) ?? "Monthly",
        day_of_month: r[5] ? Number(r[5]) : null,
        anchor_date: excelDate(r[6]),
        active: toStr(r[7]) ?? "Yes",
        debt_id: kind === "Debt" ? debtByName.get(name) ?? null : null,
        category_id: kind === "Expense" ? catByName.get(name) ?? null : null,
        notes: toStr(r[8]),
        sort_order: i - 5,
      });
    }
    let recIns = 0;
    if (recRows.length) {
      const { data, error } = await admin.from("recurring_items").insert(recRows).select("id");
      if (error)
        return json(500, { error: `Insert recurring_items failed: ${error.message}`, summary });
      recIns = data?.length ?? 0;
    }
    log("recurring_items", recIns);

    // --- Mapping rules ---
    const mp = sheet("Mapping");
    const mapRows: any[] = [];
    for (let i = 4; i < mp.length; i++) {
      const r = mp[i];
      if (!r || !toStr(r[0])) continue;
      const creditor = toStr(r[1]);
      mapRows.push({
        keyword: String(r[0]),
        maps_to_creditor: creditor,
        debt_id: creditor && debtByName.get(creditor) ? debtByName.get(creditor) : null,
        category_id: creditor && catByName.get(creditor) ? catByName.get(creditor) : null,
        notes: toStr(r[2]),
      });
    }
    let mapIns = 0;
    if (mapRows.length) {
      const { data, error } = await admin.from("mapping_rules").insert(mapRows).select("id");
      if (error)
        return json(500, { error: `Insert mapping_rules failed: ${error.message}`, summary });
      mapIns = data?.length ?? 0;
    }
    log("mapping_rules", mapIns);

    // --- Transactions ---
    const pay = sheet("Payments");
    const txRows: any[] = [];
    const batchId = crypto.randomUUID();
    for (let i = 5; i < pay.length; i++) {
      const r = pay[i];
      if (!r || !r[1]) continue;
      const date = excelDate(r[1]);
      if (!date) continue;
      const creditor = toStr(r[4]);
      const type = String(r[3] ?? "Expense");
      txRows.push({
        date,
        description: toStr(r[2]),
        type,
        creditor_or_category: creditor,
        category_id: creditor && catByName.get(creditor) ? catByName.get(creditor) : null,
        debt_id: creditor && debtByName.get(creditor) ? debtByName.get(creditor) : null,
        amount: toNum(r[5]),
        notes: toStr(r[7]),
        source: "Import",
        import_batch_id: batchId,
      });
    }
    let txInserted = 0;
    const txErrors: string[] = [];
    const CHUNK = 500;
    for (let i = 0; i < txRows.length; i += CHUNK) {
      const chunk = txRows.slice(i, i + CHUNK);
      const { data, error } = await admin.from("transactions").insert(chunk).select("id");
      if (error) txErrors.push(`Rows ${i + 1}-${i + chunk.length}: ${error.message}`);
      else txInserted += data?.length ?? 0;
    }
    log("transactions", txInserted, txErrors);

    // --- Monthly snapshots ---
    const mt = sheet("Monthly Tracking");
    const headerRow = mt[4] ?? [];
    const months: { col: number; year: number; month: number }[] = [];
    for (let c = 2; c < headerRow.length; c++) {
      const h = headerRow[c];
      if (!h) continue;
      const d = new Date(`1 ${h}`);
      if (!isNaN(d.getTime()))
        months.push({ col: c, year: d.getFullYear(), month: d.getMonth() + 1 });
    }
    const snapRows: any[] = [];
    for (let i = 5; i < mt.length; i++) {
      const r = mt[i];
      const metric = toStr(r?.[1]);
      if (!metric) continue;
      for (const m of months) {
        const v = r[m.col];
        if (v === null || v === undefined || v === "") continue;
        snapRows.push({ year: m.year, month: m.month, metric, value: toNum(v) });
      }
    }
    let snapIns = 0;
    const snapErr: string[] = [];
    for (let i = 0; i < snapRows.length; i += CHUNK) {
      const { data, error } = await admin
        .from("monthly_snapshots")
        .insert(snapRows.slice(i, i + CHUNK))
        .select("id");
      if (error) snapErr.push(`Rows ${i + 1}: ${error.message}`);
      else snapIns += data?.length ?? 0;
    }
    log("monthly_snapshots", snapIns, snapErr);

    // --- Settings ---
    const startingBalance = toNum(pay[1]?.[2]);
    const stmtDate = excelDate(pay[1]?.[6]);
    const { error: setErr } = await admin
      .from("settings")
      .update({
        starting_balance: startingBalance,
        statement_date: stmtDate,
        plan_scenario: "Current Plan",
        available_savings: 23000,
        forecast_view_days: 90,
      })
      .eq("id", 1);
    log("settings", setErr ? 0 : 1, setErr ? [setErr.message] : []);

    return json(200, { ok: true, summary });
  } catch (e: any) {
    return json(500, { error: e?.message ?? String(e) });
  }
});

ALTER TABLE public.transactions
  ADD COLUMN monthly_allowance boolean NOT NULL DEFAULT false,
  ADD COLUMN unplanned_allowance boolean NOT NULL DEFAULT false;

ALTER TABLE public.weekly_allowance_state
  ADD COLUMN monthly_total numeric NOT NULL DEFAULT 0,
  ADD COLUMN unplanned_total numeric NOT NULL DEFAULT 0;
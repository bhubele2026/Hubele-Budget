insert into public.avalanche_settings (user_id)
select ur.user_id from public.user_roles ur
where ur.role = 'owner'
  and not exists (
    select 1 from public.avalanche_settings s where s.user_id = ur.user_id
  );
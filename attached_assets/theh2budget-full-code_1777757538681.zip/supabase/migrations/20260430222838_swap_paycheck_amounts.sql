-- Brad is KFI and makes more; Hannah is Exact and makes less.
-- The labels were corrected in a prior migration, but the amounts stayed on
-- the wrong rows. Swap them so the per-check amounts line up with the people.
UPDATE public.recurring_items SET amount = 3692.31
  WHERE id = 'ef537b8b-6745-486a-8ca3-3bfe4b1584c8'; -- Brad's paycheck (KFI)
UPDATE public.recurring_items SET amount = 2123.08
  WHERE id = '1118114b-bb3e-417d-98b1-991f661ba54a'; -- Hannah's paycheck (Exact)

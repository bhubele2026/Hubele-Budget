ALTER TABLE public.debts
  ADD COLUMN IF NOT EXISTS last_balance_update timestamptz,
  ADD COLUMN IF NOT EXISTS statement_day integer;
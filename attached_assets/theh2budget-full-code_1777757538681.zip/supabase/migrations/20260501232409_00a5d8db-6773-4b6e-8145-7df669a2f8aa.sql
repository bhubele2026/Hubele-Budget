-- Restore execute permission on role-checking functions for authenticated users.
-- These were revoked in an earlier migration, which broke ALL RLS policies
-- that depend on is_owner() / has_role().
GRANT EXECUTE ON FUNCTION public.is_owner() TO authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
CREATE TABLE public.forecast_event_resolutions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  recurring_item_id uuid NULL,
  occurrence_date date NULL,
  status text NOT NULL CHECK (status IN ('matched','dismissed','ignored_unforecasted','unforecasted_added')),
  matched_txn_id uuid NULL,
  notes text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.forecast_event_resolutions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read forecast resolutions"
  ON public.forecast_event_resolutions FOR SELECT TO authenticated
  USING (is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert forecast resolutions"
  ON public.forecast_event_resolutions FOR INSERT TO authenticated
  WITH CHECK (is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update forecast resolutions"
  ON public.forecast_event_resolutions FOR UPDATE TO authenticated
  USING (is_owner());

CREATE POLICY "Owners delete forecast resolutions"
  ON public.forecast_event_resolutions FOR DELETE TO authenticated
  USING (is_owner());

CREATE TRIGGER forecast_event_resolutions_updated_at
  BEFORE UPDATE ON public.forecast_event_resolutions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Prevent duplicate resolutions per (item, date) and per matched txn
CREATE UNIQUE INDEX forecast_resolutions_event_uniq
  ON public.forecast_event_resolutions (user_id, recurring_item_id, occurrence_date)
  WHERE recurring_item_id IS NOT NULL;

CREATE UNIQUE INDEX forecast_resolutions_txn_uniq
  ON public.forecast_event_resolutions (user_id, matched_txn_id)
  WHERE matched_txn_id IS NOT NULL;

CREATE INDEX forecast_resolutions_user_idx
  ON public.forecast_event_resolutions (user_id);
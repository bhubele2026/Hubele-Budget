-- Debts table for the Avalanche page. Owner-scoped via has_role.
create table if not exists public.debts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  creditor text not null,
  apr numeric(6,4) not null default 0,
  balance numeric(12,2) not null default 0,
  min_payment numeric(12,2) not null default 0,
  status text not null default 'active',
  notes text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint debts_status_chk check (status in ('active','paid_off','zero_balance')),
  constraint debts_apr_chk check (apr >= 0 and apr <= 2),
  constraint debts_balance_chk check (balance >= 0),
  constraint debts_min_chk check (min_payment >= 0)
);

create index if not exists debts_user_idx on public.debts(user_id);
create index if not exists debts_user_apr_idx on public.debts(user_id, apr desc);

alter table public.debts enable row level security;

drop policy if exists "Owners read debts" on public.debts;
create policy "Owners read debts"
  on public.debts for select
  to authenticated
  using (public.is_owner() or user_id = auth.uid());

drop policy if exists "Owners insert debts" on public.debts;
create policy "Owners insert debts"
  on public.debts for insert
  to authenticated
  with check (public.is_owner() and user_id = auth.uid());

drop policy if exists "Owners update debts" on public.debts;
create policy "Owners update debts"
  on public.debts for update
  to authenticated
  using (public.is_owner());

drop policy if exists "Owners delete debts" on public.debts;
create policy "Owners delete debts"
  on public.debts for delete
  to authenticated
  using (public.is_owner());

drop trigger if exists debts_set_updated_at on public.debts;
create trigger debts_set_updated_at
  before update on public.debts
  for each row execute function public.set_updated_at();

-- Settings table holds per-user avalanche knobs
create table if not exists public.avalanche_settings (
  user_id uuid primary key,
  strategy text not null default 'avalanche',
  extra_source text not null default 'budget_net',
  manual_extra numeric(12,2) not null default 0,
  budget_mode text not null default 'budgeted',
  updated_at timestamptz not null default now(),
  constraint av_strategy_chk check (strategy in ('avalanche','snowball')),
  constraint av_source_chk check (extra_source in ('budget_net','budget_line','manual')),
  constraint av_mode_chk check (budget_mode in ('budgeted','actual'))
);

alter table public.avalanche_settings enable row level security;

drop policy if exists "Owners read avalanche settings" on public.avalanche_settings;
create policy "Owners read avalanche settings"
  on public.avalanche_settings for select
  to authenticated
  using (public.is_owner() or user_id = auth.uid());

drop policy if exists "Owners insert avalanche settings" on public.avalanche_settings;
create policy "Owners insert avalanche settings"
  on public.avalanche_settings for insert
  to authenticated
  with check (public.is_owner() and user_id = auth.uid());

drop policy if exists "Owners update avalanche settings" on public.avalanche_settings;
create policy "Owners update avalanche settings"
  on public.avalanche_settings for update
  to authenticated
  using (public.is_owner());

drop trigger if exists av_settings_set_updated_at on public.avalanche_settings;
create trigger av_settings_set_updated_at
  before update on public.avalanche_settings
  for each row execute function public.set_updated_at();

-- Seed the 25 debts from Ava.xlsx for every owner without existing debts.
do $$
declare
  owner_id uuid;
begin
  for owner_id in
    select ur.user_id from public.user_roles ur
    where ur.role = 'owner'
      and not exists (select 1 from public.debts d where d.user_id = ur.user_id)
  loop
    insert into public.debts (user_id, creditor, apr, balance, min_payment, sort_order, status) values
      (owner_id, 'Mattress Firm / Synchrony Home',     0.3499, 1254.49,  129.00,  1,  'active'),
      (owner_id, 'Ashley Furniture / Synchrony',       0.3499,  899.82,   33.00,  2,  'active'),
      (owner_id, 'Best Buy / Citi',                    0.2999, 1200.00,   29.00,  3,  'active'),
      (owner_id, 'Capital One Platinum',               0.2874, 5339.94,  200.00,  4,  'active'),
      (owner_id, 'Amex Delta SkyMiles Gold',           0.2849, 5483.50,  205.87,  5,  'active'),
      (owner_id, 'Menards Big Card (Cap One)',         0.2849, 2758.32,   92.00,  6,  'active'),
      (owner_id, 'Amex Platinum (Pay Over Time)',      0.2849, 1106.09,   40.00,  7,  'active'),
      (owner_id, 'Affirm — Best Buy (Dec)',            0.2832, 2869.11,  151.01,  8,  'active'),
      (owner_id, 'Capital One Quicksilver',            0.2824, 1135.64,   72.54,  9,  'active'),
      (owner_id, 'Affirm — Best Buy (Feb)',            0.2817, 1088.08,   38.00,  10, 'active'),
      (owner_id, 'Discover',                           0.2799, 2349.00,   80.00,  11, 'active'),
      (owner_id, 'Credit One Bank',                    0.2799,  291.75,    8.25,  12, 'active'),
      (owner_id, 'PayPal Credit (Hannah) / Synchrony', 0.2749, 3116.13,   99.00,  13, 'active'),
      (owner_id, 'PayPal Credit (Brad) / Synchrony',   0.2749, 1254.15,   44.00,  14, 'active'),
      (owner_id, 'Affirm — Shady Rays',                0.2697,  114.71,   19.11,  15, 'active'),
      (owner_id, 'Amex Blue Cash Preferred',           0.2649, 1015.61,   40.00,  16, 'active'),
      (owner_id, 'Chase Amazon Prime Visa',            0.2649,  220.11,   53.99,  17, 'active'),
      (owner_id, 'Apple Card (Goldman Sachs)',         0.2549, 7250.07,  265.50,  18, 'active'),
      (owner_id, 'Upstart Loan',                       0.1800, 30690.83, 1309.17, 19, 'active'),
      (owner_id, 'Affirm — Tonal',                     0.1500, 4045.32,  139.50,  20, 'active'),
      (owner_id, 'Affirm — Peloton',                   0.1500, 3446.11,  107.75,  21, 'active'),
      (owner_id, 'Affirm — Amazon',                    0.1500, 1002.44,   66.93,  22, 'active'),
      (owner_id, 'Affirm — Ridge',                     0.1500,  812.21,   56.02,  23, 'active'),
      (owner_id, 'Affirm — Target',                    0.0000,  163.09,   20.38,  24, 'active'),
      (owner_id, 'Affirm — Shokz',                     0.0000,  163.92,   18.22,  25, 'active');
  end loop;
end$$;

CREATE TABLE public.forecast_settings (
  user_id uuid PRIMARY KEY,
  bank_balance numeric NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.forecast_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read forecast settings"
  ON public.forecast_settings FOR SELECT TO authenticated
  USING (is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert forecast settings"
  ON public.forecast_settings FOR INSERT TO authenticated
  WITH CHECK (is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update forecast settings"
  ON public.forecast_settings FOR UPDATE TO authenticated
  USING (is_owner());

CREATE TRIGGER set_forecast_settings_updated_at
  BEFORE UPDATE ON public.forecast_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

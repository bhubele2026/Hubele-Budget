-- 1. Add weekly_allowance flag to transactions
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS weekly_allowance boolean NOT NULL DEFAULT false;

-- 2. Create weekly_allowance_state table
CREATE TABLE IF NOT EXISTS public.weekly_allowance_state (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  week_start_date date NOT NULL,
  weekly_total numeric NOT NULL DEFAULT 425,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.weekly_allowance_state ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read weekly allowance state"
  ON public.weekly_allowance_state
  FOR SELECT
  TO authenticated
  USING (public.is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert weekly allowance state"
  ON public.weekly_allowance_state
  FOR INSERT
  TO authenticated
  WITH CHECK (public.is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update weekly allowance state"
  ON public.weekly_allowance_state
  FOR UPDATE
  TO authenticated
  USING (public.is_owner());

CREATE TRIGGER weekly_allowance_state_set_updated_at
  BEFORE UPDATE ON public.weekly_allowance_state
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();
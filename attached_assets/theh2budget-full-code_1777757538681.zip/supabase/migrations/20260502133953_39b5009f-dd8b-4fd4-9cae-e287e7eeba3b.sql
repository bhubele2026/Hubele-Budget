-- Add Plaid identity columns to transactions
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS plaid_account_id text,
  ADD COLUMN IF NOT EXISTS plaid_pending_transaction_id text;

-- Add sync lock to plaid_items
ALTER TABLE public.plaid_items
  ADD COLUMN IF NOT EXISTS sync_started_at timestamptz;
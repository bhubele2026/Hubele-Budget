
-- 1. Add plaid_transaction_id column
ALTER TABLE public.transactions 
  ADD COLUMN IF NOT EXISTS plaid_transaction_id text;

-- 2. Unique partial index (only for rows that have a plaid_transaction_id)
CREATE UNIQUE INDEX IF NOT EXISTS transactions_plaid_txn_id_idx 
  ON public.transactions(plaid_transaction_id) 
  WHERE plaid_transaction_id IS NOT NULL;

-- 3. Clean up existing duplicate rows, keeping earliest created_at
DELETE FROM public.transactions 
WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (
      PARTITION BY date, description, amount, source, user_id 
      ORDER BY created_at ASC
    ) AS rn
    FROM public.transactions
  ) ranked WHERE rn > 1
);

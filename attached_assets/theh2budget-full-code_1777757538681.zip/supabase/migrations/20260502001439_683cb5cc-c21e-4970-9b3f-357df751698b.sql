ALTER TABLE public.transactions
  ADD COLUMN reimbursable boolean NOT NULL DEFAULT false,
  ADD COLUMN reimbursed boolean NOT NULL DEFAULT false;

ALTER TABLE public.plaid_items ADD COLUMN account text NOT NULL DEFAULT 'banking';

-- Tag existing American Express item correctly
UPDATE public.plaid_items SET account = 'amex' WHERE institution_name ILIKE '%american express%' OR institution_name ILIKE '%amex%';

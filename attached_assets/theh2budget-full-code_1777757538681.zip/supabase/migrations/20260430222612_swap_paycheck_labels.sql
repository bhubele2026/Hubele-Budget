-- Brad is KFI, Hannah is Exact (labels were swapped)
UPDATE public.recurring_items SET label = 'Brad''s paycheck (KFI)'
  WHERE id = 'ef537b8b-6745-486a-8ca3-3bfe4b1584c8';
UPDATE public.recurring_items SET label = 'Hannah''s paycheck (Exact)'
  WHERE id = '1118114b-bb3e-417d-98b1-991f661ba54a';

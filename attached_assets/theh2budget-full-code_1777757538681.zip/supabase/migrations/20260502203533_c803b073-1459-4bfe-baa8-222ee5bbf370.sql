
-- Add unique constraints needed for upsert operations in forecast-api
CREATE UNIQUE INDEX uq_fer_user_item_date
  ON public.forecast_event_resolutions (user_id, recurring_item_id, occurrence_date)
  WHERE recurring_item_id IS NOT NULL;

CREATE UNIQUE INDEX uq_fer_user_txn
  ON public.forecast_event_resolutions (user_id, matched_txn_id)
  WHERE matched_txn_id IS NOT NULL;

-- Drop the old status check constraint and replace with one that includes all used statuses
ALTER TABLE public.forecast_event_resolutions
  DROP CONSTRAINT forecast_event_resolutions_status_check;

ALTER TABLE public.forecast_event_resolutions
  ADD CONSTRAINT forecast_event_resolutions_status_check
  CHECK (status IN ('matched', 'dismissed', 'ignored_unforecasted', 'unforecasted_added', 'missed', 'unplanned'));

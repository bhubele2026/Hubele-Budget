CREATE TABLE public.dashboard_budgets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bucket text NOT NULL,  -- 'weekly', 'monthly', 'unplanned'
  period_key text NOT NULL,  -- 'YYYY-MM-DD' for weekly (Sunday), 'YYYY-MM' for monthly
  amount numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, bucket, period_key)
);

ALTER TABLE public.dashboard_budgets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read dashboard budgets"
  ON public.dashboard_budgets FOR SELECT TO authenticated
  USING (is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert dashboard budgets"
  ON public.dashboard_budgets FOR INSERT TO authenticated
  WITH CHECK (is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update dashboard budgets"
  ON public.dashboard_budgets FOR UPDATE TO authenticated
  USING (is_owner());

CREATE POLICY "Owners delete dashboard budgets"
  ON public.dashboard_budgets FOR DELETE TO authenticated
  USING (is_owner());

CREATE TRIGGER dashboard_budgets_set_updated_at
  BEFORE UPDATE ON public.dashboard_budgets
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();
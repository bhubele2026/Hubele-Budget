
CREATE TABLE public.plaid_items (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  access_token text NOT NULL,
  item_id text NOT NULL UNIQUE,
  institution_name text,
  cursor text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.plaid_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read plaid items"
  ON public.plaid_items FOR SELECT TO authenticated
  USING (is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert plaid items"
  ON public.plaid_items FOR INSERT TO authenticated
  WITH CHECK (is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update plaid items"
  ON public.plaid_items FOR UPDATE TO authenticated
  USING (is_owner());

CREATE POLICY "Owners delete plaid items"
  ON public.plaid_items FOR DELETE TO authenticated
  USING (is_owner());

CREATE TRIGGER set_plaid_items_updated_at
  BEFORE UPDATE ON public.plaid_items
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

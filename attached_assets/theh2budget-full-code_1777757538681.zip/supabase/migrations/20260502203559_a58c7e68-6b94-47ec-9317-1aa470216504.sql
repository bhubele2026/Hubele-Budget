
-- Drop the partial indexes that don't work with PostgREST upsert
DROP INDEX IF EXISTS public.uq_fer_user_item_date;
DROP INDEX IF EXISTS public.uq_fer_user_txn;

-- Add regular unique constraints (NULLs are treated as distinct in PG, so this is safe)
ALTER TABLE public.forecast_event_resolutions
  ADD CONSTRAINT uq_fer_user_item_date UNIQUE (user_id, recurring_item_id, occurrence_date);

ALTER TABLE public.forecast_event_resolutions
  ADD CONSTRAINT uq_fer_user_txn UNIQUE (user_id, matched_txn_id);

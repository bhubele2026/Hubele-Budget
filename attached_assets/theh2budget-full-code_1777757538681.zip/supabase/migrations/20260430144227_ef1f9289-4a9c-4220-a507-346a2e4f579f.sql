DROP POLICY IF EXISTS "Owners read roles" ON public.user_roles;

CREATE POLICY "Users read their own roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (user_id = auth.uid());
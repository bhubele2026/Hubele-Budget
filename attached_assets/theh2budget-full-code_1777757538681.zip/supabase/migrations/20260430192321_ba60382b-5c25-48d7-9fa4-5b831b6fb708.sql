-- Recurring items for cash forecast (Banking only)
CREATE TABLE public.recurring_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind text NOT NULL CHECK (kind IN ('income','expense','debt_min')),
  label text NOT NULL,
  amount numeric NOT NULL DEFAULT 0,
  category text,
  cadence text NOT NULL CHECK (cadence IN ('weekly','biweekly','semimonthly','monthly','quarterly','annual','onetime')),
  anchor_date date NOT NULL,
  day_of_month integer,
  linked_debt_id uuid,
  stops_at_payoff boolean NOT NULL DEFAULT false,
  active boolean NOT NULL DEFAULT true,
  notes text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.recurring_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read recurring items"
ON public.recurring_items FOR SELECT TO authenticated
USING (is_owner() OR user_id = auth.uid());

CREATE POLICY "Owners insert recurring items"
ON public.recurring_items FOR INSERT TO authenticated
WITH CHECK (is_owner() AND user_id = auth.uid());

CREATE POLICY "Owners update recurring items"
ON public.recurring_items FOR UPDATE TO authenticated
USING (is_owner());

CREATE POLICY "Owners delete recurring items"
ON public.recurring_items FOR DELETE TO authenticated
USING (is_owner());

CREATE TRIGGER set_recurring_items_updated_at
BEFORE UPDATE ON public.recurring_items
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.recurring_items;
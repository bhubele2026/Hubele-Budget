DROP TABLE IF EXISTS
  public.budget_lines,
  public.budget_months,
  public.budget_categories,
  public.mapping_rules,
  public.monthly_snapshots,
  public.recurring_items,
  public.transactions,
  public.debts,
  public.settings
CASCADE;
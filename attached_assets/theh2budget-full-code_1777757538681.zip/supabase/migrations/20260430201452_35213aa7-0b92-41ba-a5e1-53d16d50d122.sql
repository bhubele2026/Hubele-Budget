CREATE TABLE public.forecast_month_closeouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  month text NOT NULL,
  closed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, month)
);

ALTER TABLE public.forecast_month_closeouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners read month closeouts"
  ON public.forecast_month_closeouts FOR SELECT
  TO authenticated
  USING (is_owner() OR (user_id = auth.uid()));

CREATE POLICY "Owners insert month closeouts"
  ON public.forecast_month_closeouts FOR INSERT
  TO authenticated
  WITH CHECK (is_owner() AND (user_id = auth.uid()));

CREATE POLICY "Owners delete month closeouts"
  ON public.forecast_month_closeouts FOR DELETE
  TO authenticated
  USING (is_owner());
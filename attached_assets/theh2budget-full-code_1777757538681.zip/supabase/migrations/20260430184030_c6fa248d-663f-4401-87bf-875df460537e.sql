
-- transactions ledger
CREATE TABLE public.transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  date date NOT NULL,
  description text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'expense' CHECK (type IN ('income','expense','transfer')),
  category text,
  amount numeric NOT NULL DEFAULT 0,
  running_balance numeric,
  notes text,
  member text,
  source text NOT NULL DEFAULT 'manual',
  import_batch_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX transactions_date_idx ON public.transactions(date);
CREATE INDEX transactions_category_idx ON public.transactions(category);
CREATE INDEX transactions_batch_idx ON public.transactions(import_batch_id);
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read transactions" ON public.transactions FOR SELECT TO authenticated USING (is_owner() OR user_id = auth.uid());
CREATE POLICY "Owners insert transactions" ON public.transactions FOR INSERT TO authenticated WITH CHECK (is_owner() AND user_id = auth.uid());
CREATE POLICY "Owners update transactions" ON public.transactions FOR UPDATE TO authenticated USING (is_owner());
CREATE POLICY "Owners delete transactions" ON public.transactions FOR DELETE TO authenticated USING (is_owner());
CREATE TRIGGER set_updated_at_transactions BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- match rules (keyword -> category)
CREATE TABLE public.match_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  keyword text NOT NULL,
  category text NOT NULL,
  type text CHECK (type IN ('income','expense','transfer')),
  priority integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX match_rules_keyword_idx ON public.match_rules(lower(keyword));
ALTER TABLE public.match_rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read rules" ON public.match_rules FOR SELECT TO authenticated USING (is_owner() OR user_id = auth.uid());
CREATE POLICY "Owners insert rules" ON public.match_rules FOR INSERT TO authenticated WITH CHECK (is_owner() AND user_id = auth.uid());
CREATE POLICY "Owners update rules" ON public.match_rules FOR UPDATE TO authenticated USING (is_owner());
CREATE POLICY "Owners delete rules" ON public.match_rules FOR DELETE TO authenticated USING (is_owner());
CREATE TRIGGER set_updated_at_rules BEFORE UPDATE ON public.match_rules FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- budget lines (shared, persistent)
CREATE TABLE public.budget_lines (
  id text PRIMARY KEY,
  user_id uuid NOT NULL,
  section text NOT NULL,
  label text NOT NULL,
  budgeted numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'editable',
  notes text,
  linked_debt_id text,
  paycheck_id text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.budget_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read budget lines" ON public.budget_lines FOR SELECT TO authenticated USING (is_owner() OR user_id = auth.uid());
CREATE POLICY "Owners insert budget lines" ON public.budget_lines FOR INSERT TO authenticated WITH CHECK (is_owner() AND user_id = auth.uid());
CREATE POLICY "Owners update budget lines" ON public.budget_lines FOR UPDATE TO authenticated USING (is_owner());
CREATE POLICY "Owners delete budget lines" ON public.budget_lines FOR DELETE TO authenticated USING (is_owner());
CREATE TRIGGER set_updated_at_budget_lines BEFORE UPDATE ON public.budget_lines FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- import batches
CREATE TABLE public.import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  label text,
  row_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.import_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read batches" ON public.import_batches FOR SELECT TO authenticated USING (is_owner() OR user_id = auth.uid());
CREATE POLICY "Owners insert batches" ON public.import_batches FOR INSERT TO authenticated WITH CHECK (is_owner() AND user_id = auth.uid());
CREATE POLICY "Owners delete batches" ON public.import_batches FOR DELETE TO authenticated USING (is_owner());

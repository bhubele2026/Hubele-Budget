
-- =============== ROLES & PROFILES ===============
CREATE TYPE public.app_role AS ENUM ('owner');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  member_label TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Security definer function for role check (prevents recursive RLS)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'owner'::public.app_role)
$$;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- =============== DOMAIN TABLES ===============

CREATE TABLE public.debts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT,                       -- Credit Card | Store Card | BNPL | Charge POT | Personal Loan | HELOC | Mortgage | Auto Loan | Lease
  apr NUMERIC(7,4) DEFAULT 0,
  balance NUMERIC(12,2) DEFAULT 0,
  min_payment NUMERIC(12,2) DEFAULT 0,
  auto_paid BOOLEAN DEFAULT false,
  source TEXT,
  statement_date TEXT,
  notes TEXT,
  apr_status TEXT,
  effective_balance NUMERIC(12,2),
  effective_min_pmt NUMERIC(12,2),
  total_paid NUMERIC(12,2) DEFAULT 0,
  interest_accrued NUMERIC(12,2) DEFAULT 0,
  owner_member TEXT,
  archived BOOLEAN NOT NULL DEFAULT false,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.budget_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  group_name TEXT,                 -- Housing, Insurance, Food, Transportation, etc.
  default_budget NUMERIC(12,2) DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  archived BOOLEAN NOT NULL DEFAULT false,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(name)
);

CREATE TABLE public.budget_months (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(year, month)
);

CREATE TABLE public.budget_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  budget_month_id UUID NOT NULL REFERENCES public.budget_months(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES public.budget_categories(id) ON DELETE CASCADE,
  budgeted NUMERIC(12,2) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(budget_month_id, category_id)
);

CREATE TABLE public.recurring_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  kind TEXT NOT NULL,              -- Income | Expense | Debt
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  frequency TEXT NOT NULL,         -- Weekly | Bi-weekly | Monthly | Annual
  day_of_month INTEGER,
  anchor_date DATE,
  active TEXT NOT NULL DEFAULT 'Yes',  -- Yes | No | Auto
  debt_id UUID REFERENCES public.debts(id) ON DELETE SET NULL,
  category_id UUID REFERENCES public.budget_categories(id) ON DELETE SET NULL,
  notes TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  description TEXT,
  type TEXT NOT NULL,              -- Income | Expense | Transfer
  creditor_or_category TEXT,       -- preserved free-text from CSV
  category_id UUID REFERENCES public.budget_categories(id) ON DELETE SET NULL,
  debt_id UUID REFERENCES public.debts(id) ON DELETE SET NULL,
  amount NUMERIC(12,2) NOT NULL,
  notes TEXT,
  source TEXT NOT NULL DEFAULT 'Manual',  -- Manual | CSV | Import
  import_batch_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX transactions_date_idx ON public.transactions(date);
CREATE INDEX transactions_category_idx ON public.transactions(category_id);
CREATE INDEX transactions_debt_idx ON public.transactions(debt_id);

CREATE TABLE public.mapping_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  keyword TEXT NOT NULL,
  maps_to_creditor TEXT,
  debt_id UUID REFERENCES public.debts(id) ON DELETE SET NULL,
  category_id UUID REFERENCES public.budget_categories(id) ON DELETE SET NULL,
  priority INTEGER NOT NULL DEFAULT 100,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.monthly_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  year INTEGER NOT NULL,
  month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  metric TEXT NOT NULL,
  value NUMERIC(14,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(year, month, metric)
);

CREATE TABLE public.settings (
  id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  starting_balance NUMERIC(12,2) DEFAULT 0,
  statement_date DATE,
  plan_scenario TEXT DEFAULT 'Current Plan',
  available_savings NUMERIC(12,2) DEFAULT 0,
  forecast_view_days INTEGER DEFAULT 90,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO public.settings (id) VALUES (1);

-- updated_at triggers
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_debts_updated BEFORE UPDATE ON public.debts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_categories_updated BEFORE UPDATE ON public.budget_categories FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_lines_updated BEFORE UPDATE ON public.budget_lines FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_recurring_updated BEFORE UPDATE ON public.recurring_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_tx_updated BEFORE UPDATE ON public.transactions FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trg_settings_updated BEFORE UPDATE ON public.settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =============== RLS ===============
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.debts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_months ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budget_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recurring_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mapping_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Profiles: owners see all, each user updates own
CREATE POLICY "Owners read profiles" ON public.profiles FOR SELECT TO authenticated USING (public.is_owner() OR id = auth.uid());
CREATE POLICY "User updates own profile" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());
CREATE POLICY "User inserts own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());

-- user_roles: owners can read; nobody can write via API (only via SQL/admin)
CREATE POLICY "Owners read roles" ON public.user_roles FOR SELECT TO authenticated USING (public.is_owner() OR user_id = auth.uid());

-- Owner-only full access for all household tables
DO $$
DECLARE t TEXT;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'debts','budget_categories','budget_months','budget_lines',
    'recurring_items','transactions','mapping_rules','monthly_snapshots','settings'
  ]) LOOP
    EXECUTE format('CREATE POLICY "Owners select %I" ON public.%I FOR SELECT TO authenticated USING (public.is_owner());', t, t);
    EXECUTE format('CREATE POLICY "Owners insert %I" ON public.%I FOR INSERT TO authenticated WITH CHECK (public.is_owner());', t, t);
    EXECUTE format('CREATE POLICY "Owners update %I" ON public.%I FOR UPDATE TO authenticated USING (public.is_owner());', t, t);
    EXECUTE format('CREATE POLICY "Owners delete %I" ON public.%I FOR DELETE TO authenticated USING (public.is_owner());', t, t);
  END LOOP;
END $$;

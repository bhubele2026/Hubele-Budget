import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "./pages/NotFound.tsx";
import Auth from "./pages/Auth.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Avalanche from "./pages/Avalanche.tsx";
import Banking from "./pages/Banking.tsx";
import AmexDaily from "./pages/AmexDaily.tsx";
import Bills from "./pages/Bills.tsx";
import Budget from "./pages/Budget.tsx";
import Forecast from "./pages/Forecast.tsx";
import Reports from "./pages/Reports.tsx";

import AppLayout from "./components/AppLayout.tsx";
import { ProtectedRoute } from "./components/ProtectedRoute.tsx";
import { AuthProvider } from "./hooks/useAuth.tsx";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/debts" element={<Avalanche />} />
              <Route path="/avalanche" element={<Avalanche />} />
              <Route path="/transactions" element={<Navigate to="/banking" replace />} />
              <Route path="/banking" element={<Banking />} />
              <Route path="/amex" element={<AmexDaily />} />
              <Route path="/bills" element={<Bills />} />
              <Route path="/budget" element={<Budget />} />
              <Route path="/forecast" element={<Forecast />} />
              <Route path="/reports" element={<Reports />} />
              
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;

// Debt + Avalanche shared types. The seed data lives in the database
// (see migration 20260430...avalanche). This file also exports a local
// fallback list so the Avalanche board still renders if the backend is
// briefly unavailable, plus a tolerant paste parser for manual entry.

export type DebtStatus = "active" | "paid_off" | "zero_balance";
export type Strategy = "avalanche" | "snowball";
export type ExtraSource = "budget_net" | "budget_line" | "manual";
export type BudgetMode = "budgeted" | "actual";

export type Debt = {
  id: string;
  creditor: string;
  apr: number;          // 0.3499 = 34.99%
  balance: number;      // dollars — last known statement / manually set balance
  minPayment: number;   // dollars
  status: DebtStatus;
  notes?: string;
  sortOrder: number;
  /** ISO timestamp of the last manual balance edit / statement upload. */
  lastBalanceUpdate?: string;
  /** Day-of-month the statement closes (1-31). Optional. */
  statementDay?: number;
  /** Day-of-month the payment is due (1-31). Optional. */
  dueDay?: number;
  /** Plaid item_id this debt is linked to. */
  plaidItemId?: string;
  /** Plaid account_id within the item. */
  plaidAccountId?: string;
};

// Map a Supabase row to the shape used by the simulator.
export function rowToDebt(r: {
  id: string;
  creditor: string;
  apr: number | string;
  balance: number | string;
  min_payment: number | string;
  status: string;
  notes: string | null;
  sort_order: number;
  last_balance_update?: string | null;
  statement_day?: number | null;
  due_day?: number | null;
  plaid_item_id?: string | null;
  plaid_account_id?: string | null;
}): Debt {
  return {
    id: r.id,
    creditor: r.creditor,
    apr: Number(r.apr),
    balance: Number(r.balance),
    minPayment: Number(r.min_payment),
    status: (r.status as DebtStatus) ?? "active",
    notes: r.notes ?? undefined,
    sortOrder: r.sort_order,
    lastBalanceUpdate: r.last_balance_update ?? undefined,
    statementDay: r.statement_day ?? undefined,
    dueDay: r.due_day ?? undefined,
    plaidItemId: r.plaid_item_id ?? undefined,
    plaidAccountId: r.plaid_account_id ?? undefined,
  };
}

// Local fallback: the 25 debts mirrored from the seed migration.
// Used when the backend read fails so the board never gets stranded.
const FALLBACK_RAW: Array<[string, number, number, number]> = [
  ["Mattress Firm / Synchrony Home",     0.3499, 1254.49,  129.00],
  ["Ashley Furniture / Synchrony",       0.3499,  899.82,   33.00],
  ["Best Buy / Citi",                    0.2999, 1200.00,   29.00],
  ["Capital One Platinum",               0.2874, 5339.94,  200.00],
  ["Amex Delta SkyMiles Gold",           0.2849, 5483.50,  205.87],
  ["Menards Big Card (Cap One)",         0.2849, 2758.32,   92.00],
  ["Amex Platinum (Pay Over Time)",      0.2849, 1106.09,   40.00],
  ["Affirm — Best Buy (Dec)",            0.2832, 2869.11,  151.01],
  ["Capital One Quicksilver",            0.2824, 1135.64,   72.54],
  ["Affirm — Best Buy (Feb)",            0.2817, 1088.08,   38.00],
  ["Discover",                           0.2799, 2349.00,   80.00],
  ["Credit One Bank",                    0.2799,  291.75,    8.25],
  ["PayPal Credit (Hannah) / Synchrony", 0.2749, 3116.13,   99.00],
  ["PayPal Credit (Brad) / Synchrony",   0.2749, 1254.15,   44.00],
  ["Affirm — Shady Rays",                0.2697,  114.71,   19.11],
  ["Amex Blue Cash Preferred",           0.2649, 1015.61,   40.00],
  ["Chase Amazon Prime Visa",            0.2649,  220.11,   53.99],
  ["Apple Card (Goldman Sachs)",         0.2549, 7250.07,  265.50],
  ["Upstart Loan",                       0.1800, 30690.83, 1309.17],
  ["Affirm — Tonal",                     0.1500, 4045.32,  139.50],
  ["Affirm — Peloton",                   0.1500, 3446.11,  107.75],
  ["Affirm — Amazon",                    0.1500, 1002.44,   66.93],
  ["Affirm — Ridge",                     0.1500,  812.21,   56.02],
  ["Affirm — Target",                    0.0000,  163.09,   20.38],
  ["Affirm — Shokz",                     0.0000,  163.92,   18.22],
];

export const FALLBACK_DEBTS: Debt[] = FALLBACK_RAW.map(([creditor, apr, balance, minPayment], i) => ({
  id: `local-${i + 1}`,
  creditor,
  apr,
  balance,
  minPayment,
  status: "active",
  sortOrder: i + 1,
}));

// ── Paste parser ──────────────────────────────────────────────────────────
// Accepts CSV/TSV or comma-separated lines. Header row optional.
// Columns expected in order: Creditor, APR, Balance, Min Payment.
// APR can be "28.74%" or "0.2874" or "28.74".
export type ParsedRow = { ok: true; debt: Omit<Debt, "id" | "sortOrder"> }
  | { ok: false; line: string; error: string };

const HEADER_TOKENS = new Set(["creditor", "apr", "balance", "min", "minimum", "payment"]);

function parseMoney(s: string): number {
  const cleaned = s.replace(/[$,\s]/g, "");
  const n = parseFloat(cleaned);
  return isNaN(n) ? NaN : n;
}

function parseApr(s: string): number {
  const t = s.trim();
  const hasPct = t.endsWith("%");
  const n = parseFloat(t.replace(/[%\s]/g, ""));
  if (isNaN(n)) return NaN;
  // Heuristic: "0.28" → 28%; "28" or "28.5%" → 28%
  if (!hasPct && n <= 1) return n;
  return n / 100;
}

export function parsePastedDebts(input: string): ParsedRow[] {
  const lines = input
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  return lines
    .map((line) => {
      // Split on tabs, commas, or runs of 2+ spaces. Avoid splitting names with single spaces.
      const parts = line.split(/\t|,|\s{2,}/).map((p) => p.trim()).filter(Boolean);
      if (parts.length < 4) {
        return { ok: false as const, line, error: "Need 4 fields: creditor, APR, balance, min." };
      }
      // Skip header rows
      const lc = parts.map((p) => p.toLowerCase());
      if (lc.some((p) => HEADER_TOKENS.has(p))) return null;

      // Last 3 parts are numeric; everything before is creditor (commas in name supported via tab/2-space).
      const minPayment = parseMoney(parts[parts.length - 1]);
      const balance = parseMoney(parts[parts.length - 2]);
      const apr = parseApr(parts[parts.length - 3]);
      const creditor = parts.slice(0, parts.length - 3).join(" ").trim();

      if (!creditor) return { ok: false as const, line, error: "Missing creditor name." };
      if (isNaN(apr)) return { ok: false as const, line, error: "Could not read APR." };
      if (isNaN(balance)) return { ok: false as const, line, error: "Could not read balance." };
      if (isNaN(minPayment)) return { ok: false as const, line, error: "Could not read minimum." };

      return {
        ok: true as const,
        debt: { creditor, apr, balance, minPayment, status: "active" as DebtStatus },
      };
    })
    .filter((r): r is ParsedRow => r !== null);
}

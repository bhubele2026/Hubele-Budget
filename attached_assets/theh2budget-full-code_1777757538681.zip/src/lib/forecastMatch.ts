// Pure forecast matcher. No React, no Supabase. NO AUTO-MATCHING.
// Every past planned event is "pending_plan" until the user resolves it.
// Every bank transaction is "pending_bank" until the user resolves it.

import type { CashEvent } from "@/lib/forecast";
import type { Transaction } from "@/lib/ledgerTypes";

export type ResolutionStatus =
  | "matched"            // user matched plan ↔ bank
  | "missed"             // planned item never posted
  | "dismissed"          // legacy alias for missed (kept for compat)
  | "ignored_unforecasted" // bank txn user marked "not forecasted"
  | "unforecasted_added"   // legacy: added to bills from unforecasted
  | "unplanned";           // bank txn with no plan match, user marked unplanned

export type Resolution = {
  id: string;
  recurring_item_id: string | null;
  occurrence_date: string | null;
  status: ResolutionStatus;
  matched_txn_id: string | null;
  // Enriched from backend join — used by buildBucket so it doesn't depend on the capped ledger
  txn_date?: string | null;
  txn_description?: string | null;
  txn_amount?: number | null;
  txn_type?: string | null;
  txn_forecast_flag?: boolean;
};

export type PlanLineStatus =
  | "pending_plan"   // past, awaiting user triage
  | "matched"        // user matched to a bank txn (hidden from active register)
  | "missed"         // user marked missed (hidden from active register)
  | "future";        // future date

export type BankLineStatus =
  | "pending_bank"        // awaiting user triage
  | "matched"             // matched to a plan event (hidden from active register)
  | "ignored_unforecasted"; // user marked "not forecasted" (hidden)

export type PlanLine = {
  kind: "plan";
  date: string;
  itemId: string;
  label: string;
  amount: number;        // signed
  status: PlanLineStatus;
  resolutionId?: string;
  matchedTxnId?: string | null;
};

export type BankLine = {
  kind: "bank";
  date: string;
  txn: Transaction;
  amount: number;        // signed
  status: BankLineStatus;
  resolutionId?: string;
};

export type LineRow = (PlanLine | BankLine) & {
  runningBalance?: number; // only set on bank rows
};

const DAY = 86_400_000;

function parseISO(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d).getTime();
}

export function monthKey(iso: string) {
  return iso.slice(0, 7); // YYYY-MM
}

function txnSigned(t: Transaction) {
  return t.type === "income" ? Math.abs(t.amount) : -Math.abs(t.amount);
}

/**
 * Build the flat line register: one row per planned event AND per bank txn,
 * interleaved by date. Resolutions hide rows from the active register.
 *
 * Closed months (in `closedMonths`) hide ALL their resolved rows from the
 * register too — that's the point of closing out.
 */
export function buildLineRegister(opts: {
  events: CashEvent[];
  txns: Transaction[];
  resolutions: Resolution[];
  closedMonths: Set<string>;
  startBalance: number;
  fromISO: string;
  toISO: string;
  today?: Date;
}): { rows: LineRow[]; allPlan: PlanLine[]; allBank: BankLine[] } {
  const { events, txns, resolutions, closedMonths, startBalance, fromISO, toISO } = opts;
  const today = opts.today ?? new Date();
  const todayMs = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const fromMs = parseISO(fromISO);
  const toMs = parseISO(toISO);

  // Index resolutions
  const byEventKey = new Map<string, Resolution>();
  const byTxn = new Map<string, Resolution>();
  for (const r of resolutions) {
    if (r.recurring_item_id && r.occurrence_date) {
      byEventKey.set(`${r.recurring_item_id}|${r.occurrence_date}`, r);
    }
    if (r.matched_txn_id) byTxn.set(r.matched_txn_id, r);
  }

  // Build plan lines
  const allPlan: PlanLine[] = events.map((ev) => {
    const evMs = parseISO(ev.date);
    const key = `${ev.itemId}|${ev.date}`;
    const stored = byEventKey.get(key);
    let status: PlanLineStatus;
    if (stored?.status === "matched") status = "matched";
    else if (stored?.status === "missed" || stored?.status === "dismissed") status = "missed";
    else if (evMs > todayMs) status = "future";
    else status = "pending_plan";
    return {
      kind: "plan" as const,
      date: ev.date,
      itemId: ev.itemId,
      label: ev.label,
      amount: ev.amount,
      status,
      resolutionId: stored?.id,
      matchedTxnId: stored?.matched_txn_id ?? null,
    };
  });

  // Build bank lines
  const allBank: BankLine[] = txns.map((t) => {
    const stored = byTxn.get(t.id);
    let status: BankLineStatus;
    if (stored?.status === "matched") status = "matched";
    else if (stored?.status === "ignored_unforecasted" || stored?.status === "unplanned") status = "ignored_unforecasted";
    else status = "pending_bank";
    return {
      kind: "bank" as const,
      date: t.date,
      txn: t,
      amount: txnSigned(t),
      status,
      resolutionId: stored?.id,
    };
  });

  // Active rows = NOT resolved AND NOT in a closed month (resolved-in-closed are hidden too)
  const isHiddenByClosedMonth = (iso: string, isResolved: boolean) =>
    isResolved && closedMonths.has(monthKey(iso));

  const activePlan = allPlan.filter(
    (p) =>
      (p.status === "pending_plan" || p.status === "future") &&
      !isHiddenByClosedMonth(p.date, false),
  );
  const activeBank = allBank.filter(
    (b) => b.status === "pending_bank" && !isHiddenByClosedMonth(b.date, false),
  );

  // Window filter
  const inWindow = (iso: string) => {
    const ms = parseISO(iso);
    return ms >= fromMs && ms <= toMs;
  };

  // Compose rows: ALL bank rows in window (even resolved-but-not-closed get
  // suppressed), plus active plan rows in window.
  // For balance we replay every bank txn in window in date order regardless of
  // resolution status — actuals are reality.
  const bankInWindowAll = allBank.filter((b) => inWindow(b.date));
  bankInWindowAll.sort((a, b) =>
    a.date < b.date ? -1 : a.date > b.date ? 1 : a.txn.date.localeCompare(b.txn.date),
  );
  // Running balance over ALL bank rows
  let bal = startBalance;
  const balanceByTxnId = new Map<string, number>();
  for (const b of bankInWindowAll) {
    bal = Math.round((bal + b.amount) * 100) / 100;
    balanceByTxnId.set(b.txn.id, bal);
  }

  // Active rows we actually display in the register
  const visibleBank = activeBank.filter((b) => inWindow(b.date));
  const visiblePlan = activePlan.filter((p) => inWindow(p.date));

  const rows: LineRow[] = [];
  for (const b of visibleBank) {
    rows.push({ ...b, runningBalance: balanceByTxnId.get(b.txn.id) });
  }
  for (const p of visiblePlan) {
    rows.push(p);
  }
  rows.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    // bank before plan on same day
    if (a.kind !== b.kind) return a.kind === "bank" ? -1 : 1;
    return 0;
  });

  // If the window has no bank activity (pure-future forecast), give plan rows
  // a projected running balance starting from `startBalance`. When bank rows
  // exist they remain authoritative for past dates.
  if (bankInWindowAll.length === 0) {
    let proj = startBalance;
    for (const r of rows) {
      proj = Math.round((proj + r.amount) * 100) / 100;
      r.runningBalance = proj;
    }
  }

  return { rows, allPlan, allBank };
}

/** Find counterpart candidates for a row within ±days, opposite kind, same sign. */
export function findCandidates(
  row: LineRow,
  rows: LineRow[],
  days = 7,
): LineRow[] {
  const targetMs = parseISO(row.date);
  const wantSign = Math.sign(row.amount);
  const wantKind = row.kind === "bank" ? "plan" : "bank";
  return rows
    .filter((r) => r.kind === wantKind)
    .filter((r) => {
      // counterpart must be untriaged
      if (r.kind === "plan" && r.status !== "pending_plan" && r.status !== "future") return false;
      if (r.kind === "bank" && r.status !== "pending_bank") return false;
      if (Math.sign(r.amount) !== wantSign) return false;
      const dMs = Math.abs(parseISO(r.date) - targetMs);
      return dMs <= days * DAY;
    })
    .sort((a, b) => {
      const da = Math.abs(parseISO(a.date) - targetMs);
      const db = Math.abs(parseISO(b.date) - targetMs);
      if (da !== db) return da - db;
      const am = Math.abs(Math.abs(a.amount) - Math.abs(row.amount));
      const bm = Math.abs(Math.abs(b.amount) - Math.abs(row.amount));
      return am - bm;
    });
}

/**
 * Suggest the best matching plan row for a bank row (or vice versa).
 * Returns the top candidate if it exceeds a confidence threshold:
 *   - same sign (both inflow or both outflow)
 *   - within ±3 days
 *   - amount within 30% of each other
 * Returns null if no strong candidate exists.
 */
export type MatchSuggestion = {
  candidate: LineRow;
  score: number; // 0–1, higher = better
};

export function suggestMatch(
  row: LineRow,
  allRows: LineRow[],
): MatchSuggestion | null {
  const candidates = findCandidates(row, allRows, 3); // tighter window for suggestions
  if (candidates.length === 0) return null;

  const best = candidates[0];
  const amountDiff = Math.abs(Math.abs(best.amount) - Math.abs(row.amount));
  const maxAmt = Math.max(Math.abs(best.amount), Math.abs(row.amount), 1);
  const amountRatio = amountDiff / maxAmt;

  // Reject if amounts differ by more than 30%
  if (amountRatio > 0.3) return null;

  const dayDiff = Math.abs(
    (parseISOForSuggest(best.date) - parseISOForSuggest(row.date)) / DAY,
  );

  // Score: 1.0 = perfect (same amount, same day), lower = weaker
  const score = Math.max(0, 1 - amountRatio * 1.5 - dayDiff * 0.1);
  if (score < 0.3) return null;

  return { candidate: best, score };
}

function parseISOForSuggest(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d).getTime();
}

/** Bucket entries: month-scoped triaged items. */
export type BucketEntry = {
  id: string;             // resolutionId
  status: "matched" | "missed" | "ignored_unforecasted" | "unplanned";
  date: string;
  label: string;
  amount: number;         // signed
  monthKey: string;
  // for undo:
  recurring_item_id?: string | null;
  occurrence_date?: string | null;
  matched_txn_id?: string | null;
};

export function buildBucket(opts: {
  allPlan: PlanLine[];
  allBank: BankLine[];
  resolutions: Resolution[];
  closedMonths: Set<string>;
  monthFilter: string; // YYYY-MM
}): BucketEntry[] {
  const { allPlan, allBank, resolutions, closedMonths, monthFilter } = opts;
  if (closedMonths.has(monthFilter)) return [];

  const planByKey = new Map(allPlan.map((p) => [`${p.itemId}|${p.date}`, p]));
  const bankById = new Map(allBank.map((b) => [b.txn.id, b]));

  const out: BucketEntry[] = [];
  for (const r of resolutions) {
    let date: string | null = null;
    let label = "";
    let amount = 0;

    if (r.recurring_item_id && r.occurrence_date) {
      const p = planByKey.get(`${r.recurring_item_id}|${r.occurrence_date}`);
      if (p) {
        date = p.date;
        label = p.label;
        amount = p.amount;
      } else {
        date = r.occurrence_date;
      }
    } else if (r.matched_txn_id) {
      const b = bankById.get(r.matched_txn_id);
      if (b) {
        date = b.date;
        label = b.txn.description;
        amount = b.amount;
      } else if (r.txn_date) {
        // Enriched from backend — transaction may be outside the forecast window
        date = r.txn_date;
        label = r.txn_description ?? "";
        amount = r.txn_type === "income"
          ? Math.abs(r.txn_amount ?? 0)
          : -Math.abs(r.txn_amount ?? 0);
      }
    }
    if (!date) continue;
    const mk = monthKey(date);
    if (mk !== monthFilter) continue;

    let status: BucketEntry["status"];
    if (r.status === "matched") status = "matched";
    else if (r.status === "missed" || r.status === "dismissed") status = "missed";
    else if (r.status === "ignored_unforecasted") status = "ignored_unforecasted";
    else if (r.status === "unplanned") status = "unplanned";
    else continue;

    out.push({
      id: r.id,
      status,
      date,
      label,
      amount,
      monthKey: mk,
      recurring_item_id: r.recurring_item_id,
      occurrence_date: r.occurrence_date,
      matched_txn_id: r.matched_txn_id,
    });
  }
  out.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  return out;
}

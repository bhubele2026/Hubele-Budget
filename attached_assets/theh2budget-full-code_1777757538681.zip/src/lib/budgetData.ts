// Budget data extracted from user's Monthly_budget.xlsx (April 2026).
// Mock layer for Phase A. Will swap to a hook/DB in later phases without
// changing the shape consumers depend on.

export type BudgetSource = "editable" | "auto-debt" | "auto-income";

export type BudgetLine = {
  id: string;
  section: string;
  label: string;
  budgeted: number; // dollars
  actual: number; // dollars (0 until transactions land)
  source: BudgetSource;
  notes?: string;
  linkedDebtId?: string; // for auto-debt rows
  paycheckId?: string; // for auto-income rows
};

export type BudgetSection = {
  key: string;
  title: string;
  kind: "income" | "expense";
};

// Sections in the order they appear in the budget. Income first, then expenses.
export const SECTIONS: BudgetSection[] = [
  { key: "income", title: "Income", kind: "income" },
  { key: "housing", title: "Essential — Housing", kind: "expense" },
  { key: "insurance", title: "Essential — Insurance", kind: "expense" },
  { key: "food", title: "Food & Groceries", kind: "expense" },
  { key: "transport", title: "Transportation", kind: "expense" },
  { key: "kids-pets", title: "Kids & Pets", kind: "expense" },
  { key: "debt-min", title: "Debt — Minimum Payments", kind: "expense" },
  { key: "avalanche", title: "Avalanche — Extra to Highest APR", kind: "expense" },
  { key: "tech", title: "Streaming & Tech", kind: "expense" },
  { key: "dining", title: "Dining & Entertainment", kind: "expense" },
  { key: "shopping", title: "Shopping", kind: "expense" },
  { key: "other", title: "Other", kind: "expense" },
  { key: "savings", title: "Savings & Sinking Funds", kind: "expense" },
];

// Per-source income rows (replaces the single "Total Monthly Income" line
// in the Excel — total still adds to $14,168.33).
const incomeRows: BudgetLine[] = [
  { id: "inc-brad-1", section: "income", label: "Brad — Paycheck #1", budgeted: 5000, actual: 0, source: "editable" },
  { id: "inc-brad-2", section: "income", label: "Brad — Paycheck #2", budgeted: 5000, actual: 0, source: "editable" },
  { id: "inc-hannah", section: "income", label: "Hannah — Paycheck", budgeted: 4168.33, actual: 0, source: "editable" },
  { id: "inc-side", section: "income", label: "Side income", budgeted: 0, actual: 0, source: "editable" },
];

const housingRows: BudgetLine[] = [
  { id: "h-mortgage", section: "housing", label: "Mortgage (Lakeview)", budgeted: 1989.81, actual: 0, source: "editable", notes: "Recurring — kept here, not in Debt Tracker" },
  { id: "h-heloc", section: "housing", label: "HELOC (Figure)", budgeted: 677.4, actual: 0, source: "editable", notes: "Recurring — kept here, not in Debt Tracker" },
  { id: "h-mge", section: "housing", label: "Electric & Gas (MGE)", budgeted: 241, actual: 0, source: "editable" },
  { id: "h-water", section: "housing", label: "Water/Sewer (City of Madison)", budgeted: 101.02, actual: 0, source: "editable" },
  { id: "h-internet", section: "housing", label: "Internet/Cable (AT&T Uverse)", budgeted: 90.22, actual: 0, source: "editable" },
  { id: "h-phone", section: "housing", label: "Phone (Verizon)", budgeted: 342, actual: 0, source: "editable", notes: "⚠ HIGH — review plan" },
  { id: "h-maint", section: "housing", label: "Home Maintenance / Repairs", budgeted: 0, actual: 0, source: "editable", notes: "Buffer" },
];

const insuranceRows: BudgetLine[] = [
  { id: "i-auto", section: "insurance", label: "Auto Insurance (State Farm)", budgeted: 128.59, actual: 0, source: "editable" },
  { id: "i-other", section: "insurance", label: "Other Insurance (State Farm 2nd)", budgeted: 121.54, actual: 0, source: "editable" },
  { id: "i-life", section: "insurance", label: "Life Insurance (Trustage)", budgeted: 95, actual: 0, source: "editable" },
  { id: "i-warranty", section: "insurance", label: "Home Warranty (UHP)", budgeted: 53.85, actual: 0, source: "editable" },
  { id: "i-health", section: "insurance", label: "Health Insurance Premium", budgeted: 0, actual: 0, source: "editable", notes: "Fill in if not pre-tax via paycheck" },
];

const foodRows: BudgetLine[] = [
  { id: "f-grocery", section: "food", label: "Groceries ($425/wk × 4.33 wks)", budgeted: 460, actual: 0, source: "editable" },
  { id: "f-costco", section: "food", label: "Costco (warehouse stock-up)", budgeted: 0, actual: 0, source: "editable", notes: "Periodic large hauls" },
];

const transportRows: BudgetLine[] = [
  { id: "t-toyota", section: "transport", label: "Toyota Lease", budgeted: 672.8, actual: 0, source: "editable", notes: "Lease — kept here, not in Debt Tracker" },
  { id: "t-hannah-car", section: "transport", label: "Hannah's Car Payment (UW Credit Union)", budgeted: 651.55, actual: 0, source: "editable", notes: "Auto loan — kept here, not in Debt Tracker" },
  { id: "t-gas", section: "transport", label: "Gasoline (Kwik Trip / Woodmans)", budgeted: 250, actual: 0, source: "editable" },
  { id: "t-maint", section: "transport", label: "Auto Maintenance / Wash", budgeted: 0, actual: 0, source: "editable" },
  { id: "t-parking", section: "transport", label: "Parking (Madison)", budgeted: 0, actual: 0, source: "editable" },
];

const kidsPetsRows: BudgetLine[] = [
  { id: "k-school", section: "kids-pets", label: "Childcare / School Costs", budgeted: 0, actual: 0, source: "editable", notes: "Madison Metro $60 + Monona Grove $50" },
  { id: "k-activities", section: "kids-pets", label: "Kids' Activities", budgeted: 0, actual: 0, source: "editable" },
  { id: "k-boarding", section: "kids-pets", label: "Camp K9 (Pet Boarding)", budgeted: 0, actual: 0, source: "editable", notes: "Use only when traveling" },
  { id: "k-petins", section: "kids-pets", label: "Pet Insurance (Spot)", budgeted: 51.01, actual: 0, source: "editable" },
  { id: "k-petfood", section: "kids-pets", label: "Pet Food (Chewy)", budgeted: 50.24, actual: 0, source: "editable" },
  { id: "k-vet", section: "kids-pets", label: "Vet / Pet Other", budgeted: 0, actual: 0, source: "editable", notes: "Buffer" },
  { id: "k-waste", section: "kids-pets", label: "Pet Waste (Scoop Scoop)", budgeted: 80, actual: 0, source: "editable" },
];

// 22 debt minimums — auto-pulled from Debts page (Phase C). Locked here.
const debtMinRows: BudgetLine[] = [
  ["d-ashley", "Ashley Furniture / Synchrony (34.99%)", 33],
  ["d-mattress", "Mattress Firm / Synchrony Home (34.99%)", 129],
  ["d-bestbuy-citi", "Best Buy / Citi (29.99%)", 29],
  ["d-cap1-plat", "Capital One Platinum (28.74%)", 200],
  ["d-amex-delta", "Amex Delta SkyMiles Gold (28.49%)", 205.87],
  ["d-menards", "Menards Big Card (28.49%)", 92],
  ["d-amex-pot", "Amex Platinum POT (28.49%)", 40],
  ["d-affirm-bb-dec", "Affirm — Best Buy Dec (28.32%)", 151.01],
  ["d-cap1-qs", "Capital One Quicksilver (28.24%)", 72.54],
  ["d-affirm-bb-feb", "Affirm — Best Buy Feb (28.17%)", 38],
  ["d-discover", "Discover (27.99%)", 80],
  ["d-creditone", "Credit One Bank (27.99%)", 8.25],
  ["d-pp-brad", "PayPal Credit — Brad (27.49%)", 44],
  ["d-pp-hannah", "PayPal Credit — Hannah (27.49%)", 99],
  ["d-affirm-shady", "Affirm — Shady Rays (26.97%)", 19.11],
  ["d-amex-bcp", "Amex Blue Cash Preferred (26.49%)", 40],
  ["d-chase-amzn", "Chase Amazon Prime Visa (26.49%)", 53.99],
  ["d-apple", "Apple Card / Goldman Sachs (25.49%)", 265.5],
  ["d-upstart", "Upstart Loan (18.00%)", 1309.17],
  ["d-affirm-tonal", "Affirm — Tonal (15.00% est)", 139.5],
  ["d-affirm-peloton", "Affirm — Peloton (15.00% est)", 107.75],
  ["d-affirm-amzn", "Affirm — Amazon (15.00% est)", 66.93],
  ["d-affirm-ridge", "Affirm — Ridge (15.00% est)", 56.02],
  ["d-affirm-shokz", "Affirm — Shokz (0%)", 18.22],
  ["d-affirm-target", "Affirm — Target (0%)", 20.38],
].map(([id, label, budgeted]) => ({
  id: id as string,
  section: "debt-min",
  label: label as string,
  budgeted: budgeted as number,
  actual: 0,
  source: "auto-debt" as const,
  linkedDebtId: id as string,
  notes: "Live from Debt Tracker",
}));

const avalancheRows: BudgetLine[] = [
  { id: "a-extra", section: "avalanche", label: "Avalanche extra", budgeted: 0, actual: 0, source: "editable", notes: "Tag transactions with category “Avalanche extra” to feed Actual" },
];

const techRows: BudgetLine[] = [
  { id: "tc-stream", section: "tech", label: "Streaming (Netflix, Hulu, Spotify, Peacock)", budgeted: 167.68, actual: 0, source: "editable" },
  { id: "tc-brewers", section: "tech", label: "Brewers F&B / Streaming Sports", budgeted: 0, actual: 0, source: "editable", notes: "MLB Brewers tickets/food avg" },
  { id: "tc-tech-subs", section: "tech", label: "Tech Subscriptions (Boost, Ring, Tonal)", budgeted: 86.78, actual: 0, source: "editable" },
  { id: "tc-other", section: "tech", label: "Other Tech / Software", budgeted: 0, actual: 0, source: "editable", notes: "Buffer for variable subs" },
];

const diningRows: BudgetLine[] = [
  { id: "dn-restaurants", section: "dining", label: "Restaurants & Bars", budgeted: 460, actual: 0, source: "editable" },
  { id: "dn-doordash", section: "dining", label: "DoorDash & Delivery", budgeted: 0, actual: 0, source: "editable", notes: "⚠ HIGH — discipline target" },
  { id: "dn-coffee", section: "dining", label: "Coffee (Starbucks, Dunkin)", budgeted: 0, actual: 0, source: "editable" },
  { id: "dn-fun", section: "dining", label: "Movies / Concerts / Other Fun", budgeted: 0, actual: 0, source: "editable" },
];

const shoppingRows: BudgetLine[] = [
  { id: "s-clothing", section: "shopping", label: "Clothing (Threadbeast/Stitch/Lulu)", budgeted: 0, actual: 0, source: "editable", notes: "⚠ Cancel these subs" },
  { id: "s-amazon", section: "shopping", label: "Amazon (Non-essentials)", budgeted: 0, actual: 0, source: "editable" },
  { id: "s-walmart", section: "shopping", label: "Walmart / Target", budgeted: 0, actual: 0, source: "editable" },
  { id: "s-bestbuy", section: "shopping", label: "Best Buy / Electronics", budgeted: 0, actual: 0, source: "editable" },
  { id: "s-home", section: "shopping", label: "Home & Menards", budgeted: 0, actual: 0, source: "editable" },
];

const otherRows: BudgetLine[] = [
  { id: "o-student", section: "other", label: "Student Loan (Nelnet / Dept of Ed)", budgeted: 237.58, actual: 0, source: "editable", notes: "Federal loan — kept here, not in Debt Tracker" },
  { id: "o-peloton", section: "other", label: "Fitness (Peloton)", budgeted: 52.74, actual: 0, source: "editable" },
  { id: "o-edu", section: "other", label: "Education (Becker, Eastern Univ)", budgeted: 256, actual: 0, source: "editable", notes: "⚠ Verify timeline — temporary?" },
  { id: "o-charity", section: "other", label: "Charitable Giving (Athenaeum)", budgeted: 0, actual: 0, source: "editable" },
  { id: "o-medical", section: "other", label: "Health/Medical Out-of-Pocket", budgeted: 0, actual: 0, source: "editable", notes: "Buffer" },
  { id: "o-news", section: "other", label: "Newspaper Subscription", budgeted: 0, actual: 0, source: "editable", notes: "Cancel candidate" },
  { id: "o-ancestry", section: "other", label: "Ancestry.com", budgeted: 0, actual: 0, source: "editable", notes: "Cancel candidate" },
  { id: "o-ai", section: "other", label: "AI Subscriptions", budgeted: 0, actual: 0, source: "editable" },
  { id: "o-apple", section: "other", label: "Apple Subscriptions", budgeted: 0, actual: 0, source: "editable" },
  { id: "o-gaming", section: "other", label: "Gaming subs", budgeted: 61.16, actual: 0, source: "editable" },
  { id: "o-misc", section: "other", label: "Misc / Buffer", budgeted: 0, actual: 0, source: "editable", notes: "Catch-all small items" },
];

const savingsRows: BudgetLine[] = [
  { id: "sv-emergency", section: "savings", label: "Emergency Fund Contribution", budgeted: 0, actual: 0, source: "editable", notes: "Build $1,000 starter first" },
  { id: "sv-tax", section: "savings", label: "Tax Sinking Fund", budgeted: 0, actual: 0, source: "editable", notes: "Save for next April taxes (~$1,500/yr)" },
  { id: "sv-kids", section: "savings", label: "Kids' Savings / 529", budgeted: 0, actual: 0, source: "editable", notes: "Resume after high-APR debt is gone" },
  { id: "sv-retire", section: "savings", label: "Retirement (extra contributions)", budgeted: 0, actual: 0, source: "editable", notes: "Don't reduce employer match contributions" },
];

// Budget without the hardcoded debt-min rows. Phase B+: the Budget page
// injects live debt-min rows from the `debts` table, and live income rows
// from the `recurring_items` table, for one source of truth.
// Income rows are intentionally excluded here — they're injected at runtime
// from `recurring_items` via `buildLiveBudget`.
export const INITIAL_BUDGET_NO_DEBTS: BudgetLine[] = [
  ...housingRows,
  ...insuranceRows,
  ...foodRows,
  ...transportRows,
  ...kidsPetsRows,
  ...avalancheRows,
  ...techRows,
  ...diningRows,
  ...shoppingRows,
  ...otherRows,
  ...savingsRows,
];

// Backwards-compatible export: still includes the original mock debt-min rows.
// Used only as a fallback when the live debts list hasn't loaded yet.
export const INITIAL_BUDGET: BudgetLine[] = [
  ...incomeRows,
  ...housingRows,
  ...insuranceRows,
  ...foodRows,
  ...transportRows,
  ...kidsPetsRows,
  ...debtMinRows,
  ...avalancheRows,
  ...techRows,
  ...diningRows,
  ...shoppingRows,
  ...otherRows,
  ...savingsRows,
];

// Convert a recurring income item into a monthly-equivalent BudgetLine.
function recurringIncomeToLine(item: {
  id: string;
  label: string;
  amount: number;
  cadence: string;
  active: boolean;
}): BudgetLine {
  let monthly = item.amount;
  switch (item.cadence) {
    case "weekly": monthly = item.amount * 52 / 12; break;
    case "biweekly": monthly = item.amount * 26 / 12; break;
    case "semimonthly": monthly = item.amount * 2; break;
    case "monthly": monthly = item.amount; break;
    case "quarterly": monthly = item.amount / 3; break;
    case "annual": monthly = item.amount / 12; break;
    case "onetime": monthly = 0; break;
  }
  return {
    id: `inc-${item.id}`,
    section: "income",
    label: item.label,
    budgeted: Math.round(monthly * 100) / 100,
    actual: 0,
    source: "auto-income",
    paycheckId: item.id,
    notes: `Auto-pulled from Bills · ${item.cadence}`,
  };
}

// Build the live budget list by injecting debt-min rows derived from the
// live `debts` table, and optionally replacing the hardcoded income rows
// with live rows from `recurring_items`.
export function buildLiveBudget(
  liveDebts: { id: string; creditor: string; apr: number; minPayment: number; status: string }[],
  baseLines: BudgetLine[] = INITIAL_BUDGET_NO_DEBTS,
  liveIncomeItems?: { id: string; label: string; amount: number; cadence: string; active: boolean; kind: string }[],
): BudgetLine[] {
  const debtRows: BudgetLine[] = liveDebts
    .filter((d) => d.status === "active")
    .map((d) => ({
      id: `debt-${d.id}`,
      section: "debt-min",
      label: `${d.creditor} (${(d.apr * 100).toFixed(2)}%)`,
      budgeted: d.minPayment,
      actual: 0,
      source: "auto-debt" as const,
      linkedDebtId: d.id,
      notes: "Live from Avalanche page",
    }));

  // If live income items are provided, replace any income-section rows in baseLines
  let workingBase = baseLines;
  if (liveIncomeItems && liveIncomeItems.length > 0) {
    const liveIncomeRows = liveIncomeItems
      .filter((i) => i.kind === "income" && i.active)
      .map(recurringIncomeToLine);
    workingBase = [
      ...liveIncomeRows,
      ...baseLines.filter((l) => l.section !== "income"),
    ];
  }

  // Insert debt rows in the position the Budget previously had them
  // (right after kids-pets, before avalanche).
  const out: BudgetLine[] = [];
  let inserted = false;
  for (const line of workingBase) {
    if (!inserted && line.section === "avalanche") {
      out.push(...debtRows);
      inserted = true;
    }
    out.push(line);
  }
  if (!inserted) out.push(...debtRows);
  return out;
}

export const fmtMoney = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 });

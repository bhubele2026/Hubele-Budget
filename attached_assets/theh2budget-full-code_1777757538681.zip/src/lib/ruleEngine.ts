import type { MatchRule, TxType } from "./ledgerTypes";

export type Suggestion = {
  category: string | null;
  type: TxType | null;
  ruleKeyword: string | null;
};

// Find best-matching rule by case-insensitive substring with priority then length.
export function suggestCategory(description: string, rules: MatchRule[]): Suggestion {
  const d = description.toLowerCase();
  let best: MatchRule | null = null;
  for (const r of rules) {
    const k = r.keyword.toLowerCase().trim();
    if (!k) continue;
    if (!d.includes(k)) continue;
    if (
      !best ||
      r.priority > best.priority ||
      (r.priority === best.priority && k.length > best.keyword.toLowerCase().length)
    ) {
      best = r;
    }
  }
  if (!best) return { category: null, type: null, ruleKeyword: null };
  return { category: best.category, type: best.type, ruleKeyword: best.keyword };
}

export function buildMatchNote(keyword: string | null, category: string | null) {
  if (!keyword || !category) return null;
  return `${keyword.toUpperCase()} → ${category}`;
}

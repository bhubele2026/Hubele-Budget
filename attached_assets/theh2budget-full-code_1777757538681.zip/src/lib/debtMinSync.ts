// Helpers for treating "debt minimum" recurring items as a live mirror
// of the Debts table. The recurring row stores the linkage and cadence;
// the live amount comes from the linked debt's `min_payment`.

import type { RecurringItem } from "@/lib/forecast";

export type DebtLike = { id: string; minPayment?: number; min_payment?: number };

/**
 * Build a Map<recurring_item_id, live_amount> for every debt_min item
 * whose linked debt currently exists. Items missing a linked debt fall
 * back to their stored amount (no entry in the map).
 */
export function buildDebtMinAmountOverrides(
  items: RecurringItem[],
  debts: DebtLike[],
): Map<string, number> {
  const byId = new Map<string, number>();
  for (const d of debts) {
    const min = Number((d as any).minPayment ?? (d as any).min_payment ?? 0);
    byId.set(d.id, min);
  }
  const out = new Map<string, number>();
  for (const it of items) {
    if (it.kind !== "debt_min" || !it.linked_debt_id) continue;
    const live = byId.get(it.linked_debt_id);
    if (live != null) out.set(it.id, live);
  }
  return out;
}

/** Live monthly outflow for a single debt-min item — `min_payment` if linked, else stored amount. */
export function liveDebtMinAmount(
  item: RecurringItem,
  debts: DebtLike[],
): number {
  if (item.kind !== "debt_min" || !item.linked_debt_id) return Number(item.amount);
  const d = debts.find((x) => x.id === item.linked_debt_id);
  if (!d) return Number(item.amount);
  return Number((d as any).minPayment ?? (d as any).min_payment ?? item.amount);
}

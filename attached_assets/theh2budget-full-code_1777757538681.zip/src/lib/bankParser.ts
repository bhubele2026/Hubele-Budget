// Bank-feed paste parser. Accepts CSV / TSV / pipe-separated rows in any
// common column order from major banks. Returns normalized rows ready for
// rule-matching.

export type ParsedRow = {
  date: string; // YYYY-MM-DD
  description: string;
  amount: number; // signed: expense negative, income positive
  raw: string;
};

const DATE_PATTERNS: Array<(s: string) => string | null> = [
  // 2026-04-15
  (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null,
  // 04/15/2026 or 4/15/26
  (s) => {
    const m = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/);
    if (!m) return null;
    let [, mm, dd, yy] = m;
    if (yy.length === 2) yy = (Number(yy) > 70 ? "19" : "20") + yy;
    return `${yy}-${mm.padStart(2, "0")}-${dd.padStart(2, "0")}`;
  },
  // 2026/04/15
  (s) => {
    const m = s.match(/^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})$/);
    if (!m) return null;
    return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  },
];

function parseDate(s: string): string | null {
  const trimmed = s.trim().replace(/^"|"$/g, "");
  for (const fn of DATE_PATTERNS) {
    const r = fn(trimmed);
    if (r) return r;
  }
  return null;
}

function parseAmount(s: string): number | null {
  if (!s) return null;
  let t = s.trim().replace(/^"|"$/g, "");
  if (!t) return null;
  let neg = false;
  if (/^\(.+\)$/.test(t)) { neg = true; t = t.slice(1, -1); }
  if (t.startsWith("-")) { neg = true; t = t.slice(1); }
  t = t.replace(/[$,\s]/g, "");
  const n = Number(t);
  if (!isFinite(n)) return null;
  return neg ? -n : n;
}

function splitLine(line: string): string[] {
  // Try tab first, then pipe, then comma (with quoted-string awareness).
  if (line.includes("\t")) return line.split("\t");
  if (line.includes("|")) return line.split("|");
  // CSV with quote support
  const out: string[] = [];
  let cur = "";
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { inQ = !inQ; continue; }
    if (c === "," && !inQ) { out.push(cur); cur = ""; continue; }
    cur += c;
  }
  out.push(cur);
  return out;
}

export function parseBankPaste(text: string): { rows: ParsedRow[]; skipped: number } {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const rows: ParsedRow[] = [];
  let skipped = 0;

  for (const line of lines) {
    const cells = splitLine(line).map((c) => c.trim());
    if (cells.length < 2) { skipped++; continue; }

    // Find date column
    let dateIdx = -1;
    let date: string | null = null;
    for (let i = 0; i < cells.length; i++) {
      const d = parseDate(cells[i]);
      if (d) { dateIdx = i; date = d; break; }
    }
    if (!date) { skipped++; continue; }

    // Find amount columns (one signed, or debit + credit pair)
    let amount: number | null = null;
    const amtCandidates: Array<{ idx: number; val: number }> = [];
    for (let i = 0; i < cells.length; i++) {
      if (i === dateIdx) continue;
      const v = parseAmount(cells[i]);
      // Reject very-likely-not-money cells (account numbers etc.) — keep digits with decimals or signs/parens
      if (v === null) continue;
      if (!/[.,()\-$]/.test(cells[i]) && Math.abs(v) > 100000) continue;
      amtCandidates.push({ idx: i, val: v });
    }
    if (amtCandidates.length === 0) { skipped++; continue; }

    // If there are 2 amount columns adjacent (debit/credit style), combine.
    if (amtCandidates.length >= 2) {
      // Check for typical debit/credit headers? We don't have headers — use heuristic:
      // pick the column that is NOT the running balance (largest absolute, last col often balance).
      // Strategy: prefer a single nonzero among the LAST two adjacent numeric cells = debit/credit.
      // Otherwise use the first signed/parenthesized number we found.
      const signed = amtCandidates.find((c) => /[\-()]/.test(cells[c.idx]));
      if (signed) amount = signed.val;
      else {
        // Combine the last two: one is debit (positive expense), one credit. Take whichever is nonzero.
        // But we don't know which is which → assume "first nonzero of the two leftmost numeric after date" is the txn amount.
        // Treat as expense (negative) by default.
        const first = amtCandidates[0];
        amount = -Math.abs(first.val);
      }
    } else {
      amount = amtCandidates[0].val;
    }

    // Description = remaining cells joined
    const usedIdx = new Set<number>([dateIdx, ...amtCandidates.map((c) => c.idx)]);
    // Keep all amount cells out of description; running_balance often ends in a large number
    const descParts = cells
      .map((c, i) => (usedIdx.has(i) ? "" : c))
      .filter(Boolean);
    const description = descParts.join(" ").replace(/\s+/g, " ").trim();
    if (!description) { skipped++; continue; }

    rows.push({ date, description, amount: amount!, raw: line });
  }
  return { rows, skipped };
}

export function inferType(amount: number, description: string): "income" | "expense" | "transfer" {
  const d = description.toLowerCase();
  if (/transfer|xfer/.test(d)) return "transfer";
  return amount > 0 ? "income" : "expense";
}

import type { Transaction } from "@/lib/ledgerTypes";

/**
 * Check if a parsed row (date + description + amount) already exists
 * among the provided transactions. Returns true if duplicate found.
 */
export function isDuplicate(
  date: string,
  description: string,
  amount: number,
  existing: Transaction[],
): boolean {
  const descNorm = description.trim().toLowerCase();
  const absAmt = Math.abs(amount);
  return existing.some(
    (t) =>
      t.date === date &&
      t.description.trim().toLowerCase() === descNorm &&
      Math.abs(Number(t.amount)) === absAmt,
  );
}

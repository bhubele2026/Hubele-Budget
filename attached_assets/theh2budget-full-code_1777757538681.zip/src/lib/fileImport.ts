// Parse CSV or XLSX files into raw text lines for the bank parser.
import * as XLSX from "xlsx";

export async function readFileAsText(file: File): Promise<string> {
  const ext = file.name.split(".").pop()?.toLowerCase();

  if (ext === "xlsx" || ext === "xls") {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf, { type: "array", cellDates: true });
    const ws = wb.Sheets[wb.SheetNames[0]];
    // Convert to CSV text so the existing bank parser can handle it
    return XLSX.utils.sheet_to_csv(ws);
  }

  // CSV / TXT / any text file — read as text
  return file.text();
}

// Pure cash-forecast engine. No React, no Supabase.
//
// Inputs: recurring items, starting balance, date window, and a map of
// debt-id -> kill-date (from avalanche.simulate). Output: dated cash events
// merged into a daily series with running balance.

export type Cadence =
  | "weekly" | "biweekly" | "semimonthly" | "monthly"
  | "quarterly" | "annual" | "onetime";

export type RecurringItem = {
  id: string;
  kind: "income" | "expense" | "debt_min";
  label: string;
  amount: number;
  category: string | null;
  cadence: Cadence;
  anchor_date: string; // YYYY-MM-DD
  day_of_month: number | null;
  linked_debt_id: string | null;
  stops_at_payoff: boolean;
  active: boolean;
  notes?: string | null;
};

export type CashEvent = {
  date: string; // YYYY-MM-DD
  itemId: string;
  label: string;
  kind: RecurringItem["kind"];
  amount: number; // positive = inflow, negative = outflow
};

export type DayBucket = {
  date: string;
  income: number;
  expense: number;
  net: number;
  balance: number;
  events: CashEvent[];
};

const MS_DAY = 86_400_000;

function parseISO(s: string): Date {
  // Treat as local-midnight to keep day-math stable across DST
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}

export function fmtISO(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}

export function addDays(d: Date, n: number): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
}

function addMonths(d: Date, n: number): Date {
  const target = new Date(d.getFullYear(), d.getMonth() + n, 1);
  const lastDay = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  return new Date(target.getFullYear(), target.getMonth(), Math.min(d.getDate(), lastDay));
}

function setSafeDay(year: number, monthIdx: number, day: number): Date {
  const lastDay = new Date(year, monthIdx + 1, 0).getDate();
  return new Date(year, monthIdx, Math.min(day, lastDay));
}

/**
 * Expand a single recurring item into individual dated cash events between
 * `from` and `to` inclusive. Stops emitting after the optional payoff date.
 */
export function expandItem(
  item: RecurringItem,
  from: Date,
  to: Date,
  payoffDate?: Date | null,
  amountOverride?: number,
): CashEvent[] {
  if (!item.active) return [];
  const out: CashEvent[] = [];
  const sign = item.kind === "income" ? 1 : -1;
  const stopAfter = item.stops_at_payoff && payoffDate ? payoffDate : null;
  const anchor = parseISO(item.anchor_date);
  const effectiveAmount = amountOverride != null ? amountOverride : item.amount;

  const push = (d: Date) => {
    if (d < from || d > to) return;
    if (stopAfter && d > stopAfter) return;
    out.push({
      date: fmtISO(d),
      itemId: item.id,
      label: item.label,
      kind: item.kind,
      amount: sign * Math.abs(effectiveAmount),
    });
  };

  switch (item.cadence) {
    case "onetime":
      push(anchor);
      break;
    case "weekly": {
      let cur = anchor;
      // Walk back to before-or-at `from`
      while (cur > from) cur = addDays(cur, -7);
      while (cur < from) cur = addDays(cur, 7);
      while (cur <= to) { push(cur); cur = addDays(cur, 7); }
      break;
    }
    case "biweekly": {
      let cur = anchor;
      while (cur > from) cur = addDays(cur, -14);
      while (cur < from) cur = addDays(cur, 14);
      while (cur <= to) { push(cur); cur = addDays(cur, 14); }
      break;
    }
    case "monthly": {
      const day = item.day_of_month ?? anchor.getDate();
      // Start from the month of `from`
      let y = from.getFullYear(), m = from.getMonth();
      // If anchor is later than `from`, jump to anchor first month
      const anchorFirst = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
      const fromFirst = new Date(from.getFullYear(), from.getMonth(), 1);
      if (anchorFirst > fromFirst) { y = anchor.getFullYear(); m = anchor.getMonth(); }
      let cur = setSafeDay(y, m, day);
      // back up if needed
      while (cur < from) {
        m += 1; if (m > 11) { m = 0; y += 1; }
        cur = setSafeDay(y, m, day);
      }
      while (cur <= to) {
        push(cur);
        m += 1; if (m > 11) { m = 0; y += 1; }
        cur = setSafeDay(y, m, day);
      }
      break;
    }
    case "semimonthly": {
      // Two anchors per month: anchor.day and anchor.day + 14 (clamped)
      const d1 = item.day_of_month ?? anchor.getDate();
      const d2 = ((d1 + 14 - 1) % 30) + 1;
      let y = from.getFullYear(), m = from.getMonth();
      const days = [Math.min(d1, d2), Math.max(d1, d2)];
      while (true) {
        const a = setSafeDay(y, m, days[0]);
        const b = setSafeDay(y, m, days[1]);
        if (a > to && b > to) break;
        push(a); push(b);
        m += 1; if (m > 11) { m = 0; y += 1; }
      }
      break;
    }
    case "quarterly": {
      let cur = anchor;
      while (cur > from) cur = addMonths(cur, -3);
      while (cur < from) cur = addMonths(cur, 3);
      while (cur <= to) { push(cur); cur = addMonths(cur, 3); }
      break;
    }
    case "annual": {
      let cur = anchor;
      while (cur > from) cur = addMonths(cur, -12);
      while (cur < from) cur = addMonths(cur, 12);
      while (cur <= to) { push(cur); cur = addMonths(cur, 12); }
      break;
    }
  }
  return out;
}

/** Expand all items, accounting for per-debt payoff dates and optional per-item amount overrides. */
export function expandAll(
  items: RecurringItem[],
  from: Date,
  to: Date,
  killDates: Map<string, Date>, // debt id -> kill date
  amountOverrides?: Map<string, number>, // recurring item id -> live amount
): CashEvent[] {
  const events: CashEvent[] = [];
  for (const item of items) {
    const payoff = item.linked_debt_id ? killDates.get(item.linked_debt_id) ?? null : null;
    const override = amountOverrides?.get(item.id);
    events.push(...expandItem(item, from, to, payoff, override));
  }
  events.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  return events;
}

/** Build daily buckets with rolling balance over the entire window. */
export function buildDaily(
  events: CashEvent[],
  startBalance: number,
  from: Date,
  to: Date,
): DayBucket[] {
  const byDate = new Map<string, CashEvent[]>();
  for (const e of events) {
    const arr = byDate.get(e.date) ?? [];
    arr.push(e);
    byDate.set(e.date, arr);
  }
  const days: DayBucket[] = [];
  let bal = startBalance;
  const totalDays = Math.round((to.getTime() - from.getTime()) / MS_DAY) + 1;
  for (let i = 0; i < totalDays; i++) {
    const d = addDays(from, i);
    const key = fmtISO(d);
    const evs = byDate.get(key) ?? [];
    let income = 0, expense = 0;
    for (const e of evs) {
      if (e.amount > 0) income += e.amount; else expense += -e.amount;
    }
    const net = income - expense;
    bal = Math.round((bal + net) * 100) / 100;
    days.push({ date: key, income, expense, net, balance: bal, events: evs });
  }
  return days;
}

export type ForecastSummary = {
  startBalance: number;
  endBalance: number;
  income: number;
  expense: number;
  net: number;
  lowest: { date: string; balance: number };
  highest: { date: string; balance: number };
  belowZeroDays: number;
};

export function summarize(days: DayBucket[], startBalance: number): ForecastSummary {
  if (days.length === 0) {
    return {
      startBalance, endBalance: startBalance, income: 0, expense: 0, net: 0,
      lowest: { date: "", balance: startBalance },
      highest: { date: "", balance: startBalance },
      belowZeroDays: 0,
    };
  }
  let income = 0, expense = 0, low = days[0], high = days[0], below = 0;
  for (const d of days) {
    income += d.income; expense += d.expense;
    if (d.balance < low.balance) low = d;
    if (d.balance > high.balance) high = d;
    if (d.balance < 0) below++;
  }
  return {
    startBalance,
    endBalance: days[days.length - 1].balance,
    income, expense, net: income - expense,
    lowest: { date: low.date, balance: low.balance },
    highest: { date: high.date, balance: high.balance },
    belowZeroDays: below,
  };
}

/** Aggregate daily buckets into weekly or monthly buckets for long ranges. */
export function aggregateMonthly(days: DayBucket[]): DayBucket[] {
  const buckets = new Map<string, DayBucket>();
  const order: string[] = [];
  for (const d of days) {
    const key = d.date.slice(0, 7) + "-01"; // first of month
    if (!buckets.has(key)) {
      buckets.set(key, { date: key, income: 0, expense: 0, net: 0, balance: d.balance, events: [] });
      order.push(key);
    }
    const b = buckets.get(key)!;
    b.income += d.income;
    b.expense += d.expense;
    b.net += d.net;
    b.balance = d.balance; // last day's balance becomes the bucket balance
    b.events.push(...d.events);
  }
  return order.map((k) => buckets.get(k)!);
}

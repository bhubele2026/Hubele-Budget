export type TxType = "income" | "expense" | "transfer" | "debt_payment";

export type Transaction = {
  id: string;
  date: string; // YYYY-MM-DD
  description: string;
  type: TxType;
  category: string | null;
  amount: number;
  running_balance: number | null;
  notes: string | null;
  member: string | null;
  source: string;
  import_batch_id: string | null;
  weekly_allowance?: boolean;
  monthly_allowance?: boolean;
  unplanned_allowance?: boolean;
  reimbursable?: boolean;
  reimbursed?: boolean;
  forecast_flag?: boolean;
  plaid_transaction_id?: string | null;
};

export type MatchRule = {
  id: string;
  keyword: string;
  category: string;
  type: TxType | null;
  priority: number;
};

export type BudgetLineRow = {
  id: string;
  section: string;
  label: string;
  budgeted: number;
  source: string;
  notes: string | null;
  linked_debt_id: string | null;
  paycheck_id: string | null;
  sort_order: number;
};

export type Account = "banking" | "amex";

export const BANKING_SOURCES = ["manual", "bank_import", "seed", "plaid_import"] as const;
export const AMEX_SOURCES = ["amex_manual", "amex_import", "amex_plaid"] as const;

export function accountOf(source: string | null | undefined): Account {
  if (source && (AMEX_SOURCES as readonly string[]).includes(source)) return "amex";
  return "banking";
}

export const fmtMoney = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(n);

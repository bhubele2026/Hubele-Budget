// Auto-decrement debt balances using ledger payments since the last
// statement / manual update. The simulator and avalanche math should always
// run against the *applied* balance — the last known balance minus payments
// the user has made since then. New charges are not tracked (we only see
// payments out of bank/credit accounts in the ledger).
//
// Matching strategy:
//   1. transaction.category === debt.creditor (case-insensitive match)
//   2. transaction.description contains a strong creditor token (≥4 chars)
//
// Payments to a card are typically credits to the card account, but in the
// ledger they show up as expenses out of bank/Amex/etc. with a description
// like "Capital One PMT" or "AUTOPAY APPLECARD". So we look at any non-income
// transaction whose category/description points at the creditor.

import type { Debt } from "@/lib/debtData";
import type { Transaction } from "@/lib/ledgerTypes";

const STOPWORDS = new Set([
  "card", "credit", "bank", "loan", "store", "the", "and", "for", "pay",
  "payment", "pmt", "autopay", "auto", "online", "of", "co", "inc",
  "synchrony", "citi", "goldman", "sachs", "platinum", "gold", "preferred",
  "blue", "cash", "amazon", "prime", "visa",
]);

/** Tokens from a creditor name we consider strong enough to match against
 * transaction text. Returns lowercase tokens of length ≥ 4 minus stopwords. */
export function creditorTokens(name: string): string[] {
  return name
    .toLowerCase()
    .replace(/[\/\-—()]+/g, " ")
    .split(/\s+/)
    .map((t) => t.replace(/[^a-z0-9]/g, ""))
    .filter((t) => t.length >= 4 && !STOPWORDS.has(t));
}

function txnMatchesDebt(t: Transaction, debt: Debt, tokens: string[]): boolean {
  const cat = (t.category ?? "").toLowerCase().trim();
  const creditorLc = debt.creditor.toLowerCase().trim();
  if (cat && (cat === creditorLc || creditorLc.includes(cat) || cat.includes(creditorLc))) {
    return true;
  }
  if (tokens.length === 0) return false;
  const hay = `${t.description ?? ""} ${t.category ?? ""}`.toLowerCase();
  // Require all tokens (or the single token if only one) to appear.
  // Most creditor names produce 1-2 tokens after stopword filtering.
  return tokens.every((tok) => hay.includes(tok));
}

/** Sum of payments made against a debt since `since` (inclusive). */
export function paymentsSince(
  debt: Debt,
  txns: Transaction[],
  since: Date,
): number {
  const tokens = creditorTokens(debt.creditor);
  if (tokens.length === 0) return 0;
  const sinceMs = since.getTime();
  let total = 0;
  for (const t of txns) {
    if (t.type === "income" || t.type === "transfer") continue;
    const d = new Date(t.date).getTime();
    if (isNaN(d) || d < sinceMs) continue;
    if (!txnMatchesDebt(t, debt, tokens)) continue;
    total += Math.abs(Number(t.amount));
  }
  return total;
}

export type AppliedDebt = Debt & {
  /** Balance after subtracting payments made since last update. */
  appliedBalance: number;
  /** Sum of payments matched against this debt since the window start. */
  paymentsApplied: number;
  /** Window start used for matching (last_balance_update or fallback). */
  windowStart: Date;
  /** Days since the last manual/statement update. */
  daysSinceUpdate: number | null;
};

/** Default lookback when a debt has never been manually updated. */
const DEFAULT_LOOKBACK_DAYS = 35;

/**
 * Returns each debt with `balance` overridden by the applied balance
 * (last known minus payments since last update). The original `balance` is
 * preserved on `lastKnownBalance` for display.
 */
export function applyPaymentsToDebts(
  debts: Debt[],
  txns: Transaction[],
  now: Date = new Date(),
): AppliedDebt[] {
  return debts.map((d) => {
    const last = d.lastBalanceUpdate ? new Date(d.lastBalanceUpdate) : null;
    const fallback = new Date(now);
    fallback.setDate(fallback.getDate() - DEFAULT_LOOKBACK_DAYS);
    const windowStart = last && !isNaN(last.getTime()) ? last : fallback;

    const paymentsApplied = paymentsSince(d, txns, windowStart);
    const appliedBalance = Math.max(0, d.balance - paymentsApplied);
    const daysSinceUpdate = last
      ? Math.max(0, Math.floor((now.getTime() - last.getTime()) / 86400000))
      : null;

    return {
      ...d,
      balance: appliedBalance,
      appliedBalance,
      paymentsApplied,
      windowStart,
      daysSinceUpdate,
    };
  });
}

/** True if the last balance update is older than a typical statement cycle. */
export function isBalanceStale(
  debt: Pick<Debt, "lastBalanceUpdate">,
  staleDays = 35,
  now: Date = new Date(),
): boolean {
  if (!debt.lastBalanceUpdate) return true;
  const last = new Date(debt.lastBalanceUpdate).getTime();
  if (isNaN(last)) return true;
  return now.getTime() - last > staleDays * 86400000;
}

// Single source of truth for "extra per month" used by Avalanche + Dashboard.
//
// One axis drives the number: budgetMode.
//   - "budgeted" → settings.manualExtra (the same value edited from the
//     Budget page's "Avalanche extra" row and the Avalanche slider).
//   - "actual"   → sum of current-month transactions categorized as
//     "Avalanche extra" in the ledger (avalancheActual).

export type BudgetMode = "budgeted" | "actual";

// Kept for backwards-compat with persisted settings rows. Not used to switch
// behavior anymore — the resolver only looks at budgetMode + manualExtra.
export type ExtraSource = "budget_net" | "budget_line" | "manual";

export type SettingsLike = {
  extraSource: ExtraSource;
  budgetMode: BudgetMode;
  manualExtra: number;
};

/**
 * Live month-to-date snapshot from the ledger.
 *  - incomeReceived: sum of `type === "income"` for the month
 *  - expenseActual:  non-debt categories
 *  - debtMinsPaid:   actual outflows against debt categories (cap at sum of mins)
 *  - debtExtraPaid:  actual outflows against debt categories ABOVE sum of mins
 *  - avalancheActual: sum of transactions categorized as "Avalanche extra"
 */
export type ActualsMTD = {
  incomeReceived: number;
  expenseActual: number;
  debtMinsPaid: number;
  debtExtraPaid: number;
  avalancheActual: number;
};

export function resolveExtra(
  settings: SettingsLike,
  avalancheActual: number,
): number {
  return settings.budgetMode === "actual"
    ? Math.max(0, avalancheActual)
    : Math.max(0, settings.manualExtra);
}

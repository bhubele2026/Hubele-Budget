// Single source of placeholder data. Delete this file once real tables are wired.

export type Member = "alex" | "sam";

export const members: Record<Member, { label: string; initials: string }> = {
  alex: { label: "Alex", initials: "A" },
  sam: { label: "Sam", initials: "S" },
};

export interface Debt {
  id: string;
  name: string;
  type: "credit_card" | "loan" | "auto" | "student";
  balance: number;
  apr: number;
  minPayment: number;
  owner: Member | "joint";
}

export const debts: Debt[] = [
  { id: "d1", name: "Chase Sapphire", type: "credit_card", balance: 8420, apr: 24.99, minPayment: 215, owner: "alex" },
  { id: "d2", name: "Citi Double Cash", type: "credit_card", balance: 4180, apr: 22.49, minPayment: 110, owner: "sam" },
  { id: "d3", name: "Discover It", type: "credit_card", balance: 2950, apr: 19.99, minPayment: 78, owner: "alex" },
  { id: "d4", name: "Auto Loan — Subaru", type: "auto", balance: 14200, apr: 6.4, minPayment: 385, owner: "joint" },
  { id: "d5", name: "Sallie Mae", type: "student", balance: 18650, apr: 5.8, minPayment: 220, owner: "sam" },
  { id: "d6", name: "Personal Loan — SoFi", type: "loan", balance: 6300, apr: 11.25, minPayment: 175, owner: "joint" },
];

export interface Transaction {
  id: string;
  date: string;
  who: Member;
  description: string;
  category: string;
  debtId?: string;
  amount: number; // negative = spend, positive = income/payment to debt
}

export const transactions: Transaction[] = [
  { id: "t1", date: "2026-04-29", who: "alex", description: "Whole Foods", category: "Groceries", amount: -84.22 },
  { id: "t2", date: "2026-04-29", who: "sam", description: "Chase payment", category: "Debt", debtId: "d1", amount: -450 },
  { id: "t3", date: "2026-04-28", who: "alex", description: "Shell gas", category: "Transport", amount: -52.10 },
  { id: "t4", date: "2026-04-28", who: "sam", description: "Paycheck", category: "Income", amount: 3200 },
  { id: "t5", date: "2026-04-27", who: "alex", description: "Netflix", category: "Subscriptions", amount: -15.49 },
  { id: "t6", date: "2026-04-26", who: "alex", description: "Trader Joe's", category: "Groceries", amount: -62.33 },
  { id: "t7", date: "2026-04-25", who: "sam", description: "Sallie Mae auto-pay", category: "Debt", debtId: "d5", amount: -220 },
  { id: "t8", date: "2026-04-24", who: "alex", description: "Coffee", category: "Dining", amount: -6.75 },
  { id: "t9", date: "2026-04-23", who: "sam", description: "Electric bill", category: "Utilities", amount: -118.40 },
  { id: "t10", date: "2026-04-22", who: "alex", description: "Paycheck", category: "Income", amount: 3450 },
];

export interface Bill {
  id: string;
  name: string;
  amount: number;
  frequency: "monthly" | "weekly" | "yearly";
  dayOfMonth: number;
  payer: Member;
  category: string;
}

export const bills: Bill[] = [
  { id: "b1", name: "Rent", amount: 2150, frequency: "monthly", dayOfMonth: 1, payer: "alex", category: "Housing" },
  { id: "b2", name: "Electric", amount: 130, frequency: "monthly", dayOfMonth: 8, payer: "sam", category: "Utilities" },
  { id: "b3", name: "Internet", amount: 75, frequency: "monthly", dayOfMonth: 12, payer: "alex", category: "Utilities" },
  { id: "b4", name: "Auto Loan", amount: 385, frequency: "monthly", dayOfMonth: 15, payer: "sam", category: "Debt" },
  { id: "b5", name: "Car Insurance", amount: 168, frequency: "monthly", dayOfMonth: 20, payer: "alex", category: "Insurance" },
  { id: "b6", name: "Spotify Family", amount: 17, frequency: "monthly", dayOfMonth: 22, payer: "sam", category: "Subscriptions" },
  { id: "b7", name: "Gym", amount: 45, frequency: "monthly", dayOfMonth: 5, payer: "alex", category: "Health" },
];

export interface BudgetLine {
  group: "Fixed" | "Variable" | "Debt" | "Savings";
  category: string;
  budgeted: number;
  spent: number;
}

export const budget: BudgetLine[] = [
  { group: "Fixed", category: "Housing", budgeted: 2150, spent: 2150 },
  { group: "Fixed", category: "Utilities", budgeted: 250, spent: 248 },
  { group: "Fixed", category: "Insurance", budgeted: 168, spent: 168 },
  { group: "Variable", category: "Groceries", budgeted: 700, spent: 542 },
  { group: "Variable", category: "Dining", budgeted: 200, spent: 168 },
  { group: "Variable", category: "Transport", budgeted: 250, spent: 187 },
  { group: "Variable", category: "Subscriptions", budgeted: 80, spent: 77 },
  { group: "Debt", category: "Avalanche target (Chase)", budgeted: 800, spent: 450 },
  { group: "Debt", category: "Min payments", budgeted: 1180, spent: 1180 },
  { group: "Savings", category: "Emergency fund", budgeted: 400, spent: 400 },
];

export const monthlyIncome = { alex: 6900, sam: 6400 };

export const payoffTimeline = [
  { month: "May '26", balance: 54700 },
  { month: "Jul '26", balance: 51200 },
  { month: "Sep '26", balance: 47400 },
  { month: "Nov '26", balance: 43100 },
  { month: "Jan '27", balance: 38600 },
  { month: "Mar '27", balance: 33800 },
  { month: "May '27", balance: 28500 },
  { month: "Jul '27", balance: 22800 },
  { month: "Sep '27", balance: 16700 },
  { month: "Nov '27", balance: 10100 },
  { month: "Jan '28", balance: 3200 },
  { month: "Feb '28", balance: 0 },
];

export const spendingByMonth = [
  { month: "Nov", Housing: 2150, Food: 820, Transport: 240, Other: 380 },
  { month: "Dec", Housing: 2150, Food: 940, Transport: 290, Other: 510 },
  { month: "Jan", Housing: 2150, Food: 760, Transport: 220, Other: 340 },
  { month: "Feb", Housing: 2150, Food: 710, Transport: 205, Other: 360 },
  { month: "Mar", Housing: 2150, Food: 780, Transport: 250, Other: 410 },
  { month: "Apr", Housing: 2150, Food: 710, Transport: 187, Other: 322 },
];

export const cashFlowByMonth = [
  { month: "Nov", net: 1240 },
  { month: "Dec", net: -380 },
  { month: "Jan", net: 1620 },
  { month: "Feb", net: 1880 },
  { month: "Mar", net: 1340 },
  { month: "Apr", net: 1710 },
];

export const totalOwed = debts.reduce((s, d) => s + d.balance, 0);
export const totalMinPayments = debts.reduce((s, d) => s + d.minPayment, 0);
export const avalancheTarget = [...debts].sort((a, b) => b.apr - a.apr)[0];

export function fmtMoney(n: number, opts: { sign?: boolean } = {}) {
  const abs = Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  if (opts.sign) return `${n < 0 ? "−" : "+"}$${abs}`;
  return `$${abs}`;
}

export function fmtMoneyCents(n: number) {
  const abs = Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${n < 0 ? "−" : ""}$${abs}`;
}

import type { Transaction } from "@/lib/ledgerTypes";
import { accountOf } from "@/lib/ledgerTypes";
import type { BudgetLine } from "@/lib/budgetData";
import type { RecurringItem } from "@/lib/forecast";

const stripPct = (label: string) =>
  label.replace(/\s*\([^)]*%\)\s*$/, "").toLowerCase().trim();

/**
 * Returns the signed contribution of an expense-row transaction to the
 * budget "actual spent" total. The sign is derived from the AMOUNT and
 * the ACCOUNT — never from fuzzy description text (otherwise vendors
 * like "UW Credit Union" get mis-flagged as credits).
 *
 * Convention used in this app:
 *  - Banking expenses are stored as POSITIVE = money out (a cost). A
 *    NEGATIVE banking expense is a refund/return into the account, so
 *    it offsets spending and contributes negative.
 *  - Amex expenses are stored as POSITIVE = a card charge (a cost). A
 *    NEGATIVE amex expense is a statement credit / refund and offsets
 *    spending.
 *
 * In both cases the sign of the stored amount already encodes
 * cost-vs-credit correctly, so we just return it as-is.
 */
export function signedExpenseAmount(t: Transaction): number {
  const amt = Number(t.amount);
  if (!isFinite(amt)) return 0;
  // accountOf is referenced so future per-account adjustments can hook
  // in here without touching every call site.
  void accountOf(t.source);
  return amt;
}

export function isCredit(t: Transaction): boolean {
  return signedExpenseAmount(t) < 0;
}

/**
 * Returns the ledger transactions that contributed to a budget line's "actual"
 * for the currently loaded month. Mirrors the logic in Budget.tsx's
 * actualsByCategory / incomeActualsByLabel memos so the drilldown sheet and
 * the summed cell always agree.
 */
export function getMatchingTransactions(
  line: BudgetLine,
  transactions: Transaction[],
  recurringItems: RecurringItem[],
): Transaction[] {
  const labelKey = line.label.toLowerCase().trim();
  const debtKey = line.section === "debt-min" ? stripPct(line.label) : null;

  // Income rows: prefer strict category match, fall back to a payroll-source
  // token from the label's parenthesised suffix (e.g. "KFI", "Exact"). Never
  // match on the person's first name — it would cross-match the wrong paycheck.
  if (line.section === "income" && line.paycheckId) {
    const item = recurringItems.find((r) => r.id === line.paycheckId);
    const sourceLabel = (item?.label ?? line.label).toLowerCase().trim();
    const sourceMatch = (item?.label ?? line.label).match(/\(([^)]+)\)/);
    const sourceToken = sourceMatch ? sourceMatch[1].toLowerCase().trim() : null;
    return transactions.filter((t) => {
      if (t.type !== "income") return false;
      if (Number(t.amount) <= 0) return false;
      const cat = (t.category ?? "").toLowerCase().trim();
      const desc = (t.description ?? "").toLowerCase();
      if (cat === sourceLabel) return true;
      if (sourceToken && (desc.includes(sourceToken) || cat.includes(`(${sourceToken})`))) return true;
      return false;
    });
  }

  // Expense / debt-min: strict category match.
  return transactions.filter((t) => {
    if (t.type === "transfer") return false;
    const cat = (t.category ?? "").toLowerCase().trim();
    if (!cat) return false;
    if (cat === labelKey) return true;
    if (debtKey && cat === debtKey) return true;
    return false;
  });
}

/**
 * Net total for a budget line: charges minus credits/refunds for expense
 * rows, plain positive sum for income rows.
 */
export function sumTransactions(
  txns: Transaction[],
  kind: "income" | "expense" = "expense",
): number {
  if (kind === "income") {
    return txns.reduce((s, t) => s + Math.abs(Number(t.amount)), 0);
  }
  return txns.reduce((s, t) => s + signedExpenseAmount(t), 0);
}

// Compute the same numbers the Budget page shows, but with the debt-min rows
// replaced by the live rows from the `debts` table and (optionally) the income
// rows replaced by live rows from `recurring_items`. This is the single source
// of truth for "Net surplus" used by the Avalanche page, and it must mirror
// what the Budget page displays so the two pages never disagree.

import { INITIAL_BUDGET_NO_DEBTS, type BudgetLine } from "@/lib/budgetData";
import type { Debt } from "@/lib/debtData";

export type BudgetSnapshot = {
  income: number;
  expenses: number;
  net: number;
  avalancheLine: number;       // value of the explicit "Avalanche" budget row
  debtMinTotal: number;        // sum of active debt minimums
};

type IncomeItemLike = {
  id: string;
  kind: string;
  label: string;
  amount: number;
  cadence: string;
  active: boolean;
};

function monthlyEquivalent(amount: number, cadence: string): number {
  switch (cadence) {
    case "weekly": return amount * 52 / 12;
    case "biweekly": return amount * 26 / 12;
    case "semimonthly": return amount * 2;
    case "monthly": return amount;
    case "quarterly": return amount / 3;
    case "annual": return amount / 12;
    case "onetime": return 0;
    default: return amount;
  }
}

export function buildBudgetSnapshot(
  liveDebts: Debt[],
  liveIncomeItems?: IncomeItemLike[],
  avalancheExtra: number = 0,
): BudgetSnapshot {
  // Base = static expense rows (no debt-mins, no income — those are injected live).
  const base = INITIAL_BUDGET_NO_DEBTS;

  const debtMinTotal = liveDebts
    .filter((d) => d.status === "active")
    .reduce((s, d) => s + d.minPayment, 0);

  // Live income from recurring_items, monthly-equivalent. This mirrors the
  // Budget page's `buildLiveBudget`. If no live items, income is 0 (the user
  // hasn't entered any paychecks yet).
  const income = (liveIncomeItems ?? [])
    .filter((i) => i.kind === "income" && i.active)
    .reduce((s, i) => s + monthlyEquivalent(i.amount, i.cadence), 0);

  // Sum static expense rows EXCEPT the avalanche section — that's driven by
  // `avalancheExtra` (persisted in avalanche_settings.manual_extra) so the
  // Budget page edit, the Avalanche pill, and the slider all read/write the
  // same value.
  const otherExpenses = base
    .filter((l) => l.section !== "income" && l.section !== "avalanche")
    .reduce((s, l) => s + l.budgeted, 0);

  const expenses = otherExpenses + debtMinTotal + Math.max(0, avalancheExtra);
  const net = income - expenses;

  return { income, expenses, net, avalancheLine: Math.max(0, avalancheExtra), debtMinTotal };
}


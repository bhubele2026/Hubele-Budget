import { supabase } from "@/integrations/supabase/client";

export async function plaidAction(action: string, payload: Record<string, unknown> = {}) {
  console.log(`[Plaid] calling ${action}`, payload);
  const { data, error } = await supabase.functions.invoke("plaid-api", {
    body: { action, payload },
  });
  if (error) {
    console.error(`[Plaid] invoke error for ${action}:`, error);
    const response = (error as any).context;
    if (response instanceof Response) {
      try {
        const body = await response.clone().json();
        if (body?.error) throw new Error(body.error);
      } catch (bodyError: any) {
        if (bodyError?.message) throw bodyError;
      }
    }
    throw new Error(error.message ?? "Plaid request failed");
  }
  if (data?.error) {
    console.error(`[Plaid] response error for ${action}:`, data.error);
    throw new Error(data.error);
  }
  console.log(`[Plaid] ${action} success:`, data);
  return data;
}

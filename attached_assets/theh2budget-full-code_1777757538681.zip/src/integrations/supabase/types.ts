export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      avalanche_settings: {
        Row: {
          budget_mode: string
          extra_source: string
          manual_extra: number
          strategy: string
          updated_at: string
          user_id: string
        }
        Insert: {
          budget_mode?: string
          extra_source?: string
          manual_extra?: number
          strategy?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          budget_mode?: string
          extra_source?: string
          manual_extra?: number
          strategy?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      budget_lines: {
        Row: {
          budgeted: number
          created_at: string
          id: string
          label: string
          linked_debt_id: string | null
          notes: string | null
          paycheck_id: string | null
          section: string
          sort_order: number
          source: string
          updated_at: string
          user_id: string
        }
        Insert: {
          budgeted?: number
          created_at?: string
          id: string
          label: string
          linked_debt_id?: string | null
          notes?: string | null
          paycheck_id?: string | null
          section: string
          sort_order?: number
          source?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          budgeted?: number
          created_at?: string
          id?: string
          label?: string
          linked_debt_id?: string | null
          notes?: string | null
          paycheck_id?: string | null
          section?: string
          sort_order?: number
          source?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      dashboard_budgets: {
        Row: {
          amount: number
          bucket: string
          created_at: string
          id: string
          period_key: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount?: number
          bucket: string
          created_at?: string
          id?: string
          period_key: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          bucket?: string
          created_at?: string
          id?: string
          period_key?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      debts: {
        Row: {
          apr: number
          balance: number
          created_at: string
          creditor: string
          due_day: number | null
          id: string
          last_balance_update: string | null
          min_payment: number
          notes: string | null
          plaid_account_id: string | null
          plaid_item_id: string | null
          sort_order: number
          statement_day: number | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          apr?: number
          balance?: number
          created_at?: string
          creditor: string
          due_day?: number | null
          id?: string
          last_balance_update?: string | null
          min_payment?: number
          notes?: string | null
          plaid_account_id?: string | null
          plaid_item_id?: string | null
          sort_order?: number
          statement_day?: number | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          apr?: number
          balance?: number
          created_at?: string
          creditor?: string
          due_day?: number | null
          id?: string
          last_balance_update?: string | null
          min_payment?: number
          notes?: string | null
          plaid_account_id?: string | null
          plaid_item_id?: string | null
          sort_order?: number
          statement_day?: number | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      forecast_event_resolutions: {
        Row: {
          created_at: string
          id: string
          matched_txn_id: string | null
          notes: string | null
          occurrence_date: string | null
          recurring_item_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          matched_txn_id?: string | null
          notes?: string | null
          occurrence_date?: string | null
          recurring_item_id?: string | null
          status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          matched_txn_id?: string | null
          notes?: string | null
          occurrence_date?: string | null
          recurring_item_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      forecast_month_closeouts: {
        Row: {
          closed_at: string
          id: string
          month: string
          user_id: string
        }
        Insert: {
          closed_at?: string
          id?: string
          month: string
          user_id: string
        }
        Update: {
          closed_at?: string
          id?: string
          month?: string
          user_id?: string
        }
        Relationships: []
      }
      forecast_settings: {
        Row: {
          bank_balance: number
          updated_at: string
          user_id: string
        }
        Insert: {
          bank_balance?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          bank_balance?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      import_batches: {
        Row: {
          created_at: string
          id: string
          label: string | null
          row_count: number
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          label?: string | null
          row_count?: number
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          label?: string | null
          row_count?: number
          user_id?: string
        }
        Relationships: []
      }
      match_rules: {
        Row: {
          category: string
          created_at: string
          id: string
          keyword: string
          priority: number
          type: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          category: string
          created_at?: string
          id?: string
          keyword: string
          priority?: number
          type?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          id?: string
          keyword?: string
          priority?: number
          type?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      plaid_items: {
        Row: {
          access_token: string
          account: string
          created_at: string
          cursor: string | null
          id: string
          institution_name: string | null
          item_id: string
          sync_started_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token: string
          account?: string
          created_at?: string
          cursor?: string | null
          id?: string
          institution_name?: string | null
          item_id: string
          sync_started_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string
          account?: string
          created_at?: string
          cursor?: string | null
          id?: string
          institution_name?: string | null
          item_id?: string
          sync_started_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          id: string
          member_label: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id: string
          member_label?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          id?: string
          member_label?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      recurring_items: {
        Row: {
          active: boolean
          amount: number
          anchor_date: string
          cadence: string
          category: string | null
          created_at: string
          day_of_month: number | null
          id: string
          kind: string
          label: string
          linked_debt_id: string | null
          notes: string | null
          sort_order: number
          stops_at_payoff: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          active?: boolean
          amount?: number
          anchor_date: string
          cadence: string
          category?: string | null
          created_at?: string
          day_of_month?: number | null
          id?: string
          kind: string
          label: string
          linked_debt_id?: string | null
          notes?: string | null
          sort_order?: number
          stops_at_payoff?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          active?: boolean
          amount?: number
          anchor_date?: string
          cadence?: string
          category?: string | null
          created_at?: string
          day_of_month?: number | null
          id?: string
          kind?: string
          label?: string
          linked_debt_id?: string | null
          notes?: string | null
          sort_order?: number
          stops_at_payoff?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          category: string | null
          created_at: string
          date: string
          description: string
          forecast_flag: boolean
          id: string
          import_batch_id: string | null
          member: string | null
          monthly_allowance: boolean
          notes: string | null
          plaid_account_id: string | null
          plaid_pending_transaction_id: string | null
          plaid_transaction_id: string | null
          reimbursable: boolean
          reimbursed: boolean
          running_balance: number | null
          source: string
          type: string
          unplanned_allowance: boolean
          updated_at: string
          user_id: string
          weekly_allowance: boolean
        }
        Insert: {
          amount?: number
          category?: string | null
          created_at?: string
          date: string
          description?: string
          forecast_flag?: boolean
          id?: string
          import_batch_id?: string | null
          member?: string | null
          monthly_allowance?: boolean
          notes?: string | null
          plaid_account_id?: string | null
          plaid_pending_transaction_id?: string | null
          plaid_transaction_id?: string | null
          reimbursable?: boolean
          reimbursed?: boolean
          running_balance?: number | null
          source?: string
          type?: string
          unplanned_allowance?: boolean
          updated_at?: string
          user_id: string
          weekly_allowance?: boolean
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string
          date?: string
          description?: string
          forecast_flag?: boolean
          id?: string
          import_batch_id?: string | null
          member?: string | null
          monthly_allowance?: boolean
          notes?: string | null
          plaid_account_id?: string | null
          plaid_pending_transaction_id?: string | null
          plaid_transaction_id?: string | null
          reimbursable?: boolean
          reimbursed?: boolean
          running_balance?: number | null
          source?: string
          type?: string
          unplanned_allowance?: boolean
          updated_at?: string
          user_id?: string
          weekly_allowance?: boolean
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      weekly_allowance_state: {
        Row: {
          monthly_total: number
          unplanned_total: number
          updated_at: string
          user_id: string
          week_start_date: string
          weekly_total: number
        }
        Insert: {
          monthly_total?: number
          unplanned_total?: number
          updated_at?: string
          user_id: string
          week_start_date: string
          weekly_total?: number
        }
        Update: {
          monthly_total?: number
          unplanned_total?: number
          updated_at?: string
          user_id?: string
          week_start_date?: string
          weekly_total?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_owner: { Args: never; Returns: boolean }
    }
    Enums: {
      app_role: "owner"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner"],
    },
  },
} as const

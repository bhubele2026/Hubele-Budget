import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Lock,
  Pencil,
  Plus,
  X,
} from "lucide-react";
import {
  INITIAL_BUDGET_NO_DEBTS,
  buildLiveBudget,
  SECTIONS,
  fmtMoney,
  type BudgetLine,
} from "@/lib/budgetData";
import { useDebts } from "@/hooks/useDebts";
import { useLedger } from "@/hooks/useLedger";
import { useRecurring } from "@/hooks/useRecurring";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { cn } from "@/lib/utils";
import { BudgetActualDrilldown } from "@/components/BudgetActualDrilldown";
import { signedExpenseAmount } from "@/lib/budgetActualMatching";
import { toast } from "@/hooks/use-toast";
import type { BudgetLineRow } from "@/lib/ledgerTypes";

const MONTH_LABELS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

// Auto-managed sections — these rows are rebuilt from live sources each render
// (debts, recurring income, avalanche settings) and never live in budget_lines.
const AUTO_SECTIONS = new Set(["debt-min", "income", "avalanche"]);

export default function Budget() {
  const { debts } = useDebts();
  const { items: recurringItems, update: updateRecurring } = useRecurring();
  const { settings, update: updateSettings } = useAvalancheSettings();

  const [monthIdx, setMonthIdx] = useState(new Date().getMonth());
  const [year, setYear] = useState(new Date().getFullYear());
  const [drilldownLine, setDrilldownLine] = useState<BudgetLine | null>(null);

  const {
    data: ledger,
    upsertBudgetLine,
    deleteBudgetLine,
    seedBudgetLines,
  } = useLedger({ month: monthIdx + 1, year });

  // First-time seed: if the user has no saved budget rows yet, push the
  // starter list into the database so subsequent edits have something to
  // upsert against. Idempotent on the server (skips if rows already exist).
  const seededRef = useRef(false);
  useEffect(() => {
    if (seededRef.current) return;
    if (ledger.budget_lines.length > 0) {
      seededRef.current = true;
      return;
    }
    const t = setTimeout(() => {
      if (seededRef.current || ledger.budget_lines.length > 0) {
        seededRef.current = true;
        return;
      }
      seededRef.current = true;
      const seed = INITIAL_BUDGET_NO_DEBTS
        .filter((l) => !AUTO_SECTIONS.has(l.section))
        .map((l, i) => ({
          id: l.id,
          section: l.section,
          label: l.label,
          budgeted: l.budgeted,
          source: "editable",
          notes: l.notes ?? null,
          sort_order: i,
        }));
      if (seed.length) seedBudgetLines.mutate(seed as any);
    }, 800);
    return () => clearTimeout(t);
  }, [ledger.budget_lines.length, seedBudgetLines]);

  // Auto rows (debt-min from debts, income from recurring) come from live sources.
  const liveAutoRows = useMemo(() => {
    const all = buildLiveBudget(debts, INITIAL_BUDGET_NO_DEBTS, recurringItems);
    return all.filter((l) => AUTO_SECTIONS.has(l.section));
  }, [debts, recurringItems]);

  // Editable rows come from the saved budget_lines table.
  const savedEditableRows: BudgetLine[] = useMemo(() => {
    return (ledger.budget_lines ?? [])
      .filter((r: BudgetLineRow) => !AUTO_SECTIONS.has(r.section))
      .map((r: BudgetLineRow) => ({
        id: r.id,
        section: r.section,
        label: r.label,
        budgeted: Number(r.budgeted),
        actual: 0,
        source: (r.source as any) ?? "editable",
        notes: r.notes ?? undefined,
      }));
  }, [ledger.budget_lines]);

  const actualsByCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of ledger.transactions) {
      if (t.type === "transfer") continue;
      const key = (t.category ?? "").toLowerCase().trim();
      if (!key) continue;
      const contrib = t.type === "income"
        ? Math.abs(Number(t.amount))
        : signedExpenseAmount(t);
      map.set(key, (map.get(key) ?? 0) + contrib);
    }
    return map;
  }, [ledger.transactions]);

  const incomeActualsByLabel = useMemo(() => {
    const map = new Map<string, number>();
    const incomeTxns = ledger.transactions.filter(
      (t) => t.type === "income" && Number(t.amount) > 0,
    );
    for (const item of recurringItems) {
      if (item.kind !== "income" || !item.active) continue;
      const labelKey = item.label.toLowerCase().trim();
      const sourceMatch = item.label.match(/\(([^)]+)\)/);
      const sourceToken = sourceMatch ? sourceMatch[1].toLowerCase().trim() : null;
      let total = 0;
      for (const t of incomeTxns) {
        const cat = (t.category ?? "").toLowerCase().trim();
        const desc = (t.description ?? "").toLowerCase();
        if (cat === labelKey) {
          total += Math.abs(Number(t.amount));
        } else if (sourceToken && (desc.includes(sourceToken) || cat.includes(`(${sourceToken})`))) {
          total += Math.abs(Number(t.amount));
        }
      }
      map.set(item.id, total);
    }
    return map;
  }, [ledger.transactions, recurringItems]);

  const lines = useMemo(() => {
    const bySection = new Map<string, BudgetLine[]>();
    for (const l of savedEditableRows) {
      if (!bySection.has(l.section)) bySection.set(l.section, []);
      bySection.get(l.section)!.push(l);
    }
    for (const l of liveAutoRows) {
      if (!bySection.has(l.section)) bySection.set(l.section, []);
      bySection.get(l.section)!.push(l);
    }
    const ordered: BudgetLine[] = [];
    for (const sec of SECTIONS) {
      const rows = bySection.get(sec.key) ?? [];
      ordered.push(...rows);
    }
    return ordered.map((l) => {
      const merged = { ...l };
      if (l.id === "a-extra") {
        merged.budgeted = settings.manualExtra;
        merged.source = "editable";
      }
      const labelKey = merged.label.toLowerCase().trim();
      let actual = actualsByCategory.get(labelKey) ?? 0;
      if (!actual && merged.section === "debt-min") {
        const noPct = merged.label.replace(/\s*\([^)]*%\)\s*$/, "").toLowerCase().trim();
        actual = actualsByCategory.get(noPct) ?? 0;
      }
      if (!actual && merged.section === "income" && merged.paycheckId) {
        actual = incomeActualsByLabel.get(merged.paycheckId) ?? 0;
      }
      return { ...merged, actual };
    });
  }, [savedEditableRows, liveAutoRows, actualsByCategory, incomeActualsByLabel, settings.manualExtra]);


  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({
    "debt-min": true,
  });

  const incomeTotal = useMemo(
    () => lines.filter((l) => l.section === "income").reduce((s, l) => s + l.budgeted, 0),
    [lines],
  );
  const expenseTotal = useMemo(
    () => lines.filter((l) => l.section !== "income").reduce((s, l) => s + l.budgeted, 0),
    [lines],
  );
  const actualIncomeTotal = useMemo(
    () => lines.filter((l) => l.section === "income").reduce((s, l) => s + l.actual, 0),
    [lines],
  );
  const actualExpenseTotal = useMemo(
    () => lines.filter((l) => l.section !== "income").reduce((s, l) => s + l.actual, 0),
    [lines],
  );
  const net = incomeTotal - expenseTotal;
  const actualNet = actualIncomeTotal - actualExpenseTotal;
  const pctUsed = incomeTotal > 0 ? (expenseTotal / incomeTotal) * 100 : 0;
  const actualPctUsed = actualIncomeTotal > 0 ? (actualExpenseTotal / actualIncomeTotal) * 100 : 0;

  const onSaveError = (e: unknown) => {
    toast({
      title: "Couldn't save",
      description: (e as Error)?.message ?? "Try again in a moment.",
      variant: "destructive",
    });
  };

  const updateBudgeted = (id: string, value: number) => {
    const safe = isNaN(value) ? 0 : value;
    if (id === "a-extra") {
      updateSettings.mutate({ manualExtra: Math.max(0, Math.round(safe * 100) / 100) });
      return;
    }
    if (id.startsWith("inc-")) {
      const recurringId = id.slice(4);
      const item = recurringItems.find((r) => r.id === recurringId);
      if (item) {
        let nativeAmount = safe;
        switch (item.cadence) {
          case "weekly": nativeAmount = safe * 12 / 52; break;
          case "biweekly": nativeAmount = safe * 12 / 26; break;
          case "semimonthly": nativeAmount = safe / 2; break;
          case "monthly": nativeAmount = safe; break;
          case "quarterly": nativeAmount = safe * 3; break;
          case "annual": nativeAmount = safe * 12; break;
          case "onetime": nativeAmount = safe; break;
        }
        nativeAmount = Math.round(nativeAmount * 100) / 100;
        updateRecurring.mutate({ id: recurringId, amount: nativeAmount });
        return;
      }
    }
    const existing = lines.find((l) => l.id === id);
    if (!existing) return;
    upsertBudgetLine.mutate(
      {
        id,
        section: existing.section,
        label: existing.label,
        budgeted: Math.round(safe * 100) / 100,
        source: "editable",
        notes: existing.notes ?? null,
      } as any,
      { onError: onSaveError },
    );
  };

  const updateLabel = (id: string, label: string) => {
    const trimmed = label.trim();
    if (!trimmed) return;
    const existing = lines.find((l) => l.id === id);
    if (!existing) return;
    upsertBudgetLine.mutate(
      {
        id,
        section: existing.section,
        label: trimmed,
        budgeted: existing.budgeted,
        source: "editable",
        notes: existing.notes ?? null,
      } as any,
      { onError: onSaveError },
    );
  };

  const removeLine = (id: string) => {
    deleteBudgetLine.mutate(id, { onError: onSaveError });
  };

  const addLine = (sectionKey: string) => {
    const id = `${sectionKey}-custom-${Date.now()}`;
    upsertBudgetLine.mutate(
      {
        id,
        section: sectionKey,
        label: "New category",
        budgeted: 0,
        source: "editable",
        notes: null,
      } as any,
      { onError: onSaveError },
    );
    setCollapsed((p) => ({ ...p, [sectionKey]: false }));
  };

  const stepMonth = (delta: number) => {
    let m = monthIdx + delta;
    let y = year;
    if (m < 0) { m = 11; y -= 1; }
    if (m > 11) { m = 0; y += 1; }
    setMonthIdx(m);
    setYear(y);
  };

  return (
    <TooltipProvider delayDuration={150}>
      <div className="mx-auto max-w-6xl px-6 md:px-10 py-8">
        {/* Header */}
        <div className="border-b-2 border-foreground pb-4 mb-6 flex items-end justify-between gap-4 flex-wrap">
          <div>
            <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Section V
            </div>
            <h1 className="font-display text-5xl font-bold leading-none mt-1">Budget</h1>
            <p className="font-display italic text-muted-foreground mt-2">
              A plan for every dollar this month.
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => stepMonth(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="font-display font-semibold px-3 min-w-[140px] text-center">
              {MONTH_LABELS[monthIdx]} {year}
            </div>
            <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => stepMonth(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-2 mb-6 text-[11px] uppercase tracking-wider">
          <LegendChip color="bg-foreground" label="Editable" />
          <LegendChip color="bg-accent" label="Auto-pulled from Debts" />
          <LegendChip color="bg-positive" label="Auto-pulled from Income" />
        </div>

        {/* Summary — Budget vs Actual */}
        <div className="grid grid-cols-2 md:grid-cols-4 border-y border-foreground/30 mb-10">
          <DualStat
            label="Income"
            budget={fmtMoney(incomeTotal)}
            actual={fmtMoney(actualIncomeTotal)}
            actualTone={actualIncomeTotal >= incomeTotal ? "positive" : "muted"}
          />
          <DualStat
            label="Expenses"
            budget={fmtMoney(expenseTotal)}
            actual={fmtMoney(actualExpenseTotal)}
            actualTone={actualExpenseTotal > expenseTotal ? "negative" : "muted"}
          />
          <DualStat
            label="Net"
            budget={fmtMoney(net)}
            actual={fmtMoney(actualNet)}
            budgetTone={net >= 0 ? "positive" : "negative"}
            actualTone={actualNet >= 0 ? "positive" : "negative"}
          />
          <DualStat
            label="% Spent"
            budget={`${pctUsed.toFixed(1)}%`}
            actual={`${actualPctUsed.toFixed(1)}%`}
            actualTone={actualPctUsed > 100 ? "negative" : actualPctUsed > 80 ? "warn" : "muted"}
            last
          />
        </div>

        {/* Sections */}
        <div className="space-y-8">
          {SECTIONS.map((sec) => {
            const sectionLines = lines.filter((l) => l.section === sec.key);
            if (!sectionLines.length) return null;
            const budgetedSum = sectionLines.reduce((s, l) => s + l.budgeted, 0);
            const actualSum = sectionLines.reduce((s, l) => s + l.actual, 0);
            const isOpen = !collapsed[sec.key];
            const diff = sec.kind === "income" ? actualSum - budgetedSum : budgetedSum - actualSum;

            return (
              <section key={sec.key} className="border border-border bg-card rounded-2xl">
                <button
                  className="w-full flex items-baseline justify-between gap-4 px-5 py-4 border-b border-border bg-secondary/40 hover:bg-secondary/70 transition-colors text-left"
                  onClick={() =>
                    setCollapsed((p) => ({ ...p, [sec.key]: !p[sec.key] }))
                  }
                >
                  <div className="flex items-center gap-3">
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 transition-transform",
                        !isOpen && "-rotate-90",
                      )}
                    />
                    <h2 className="font-display text-xl font-semibold">{sec.title}</h2>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      {sectionLines.length} {sectionLines.length === 1 ? "line" : "lines"}
                    </span>
                  </div>
                  <div className="font-mono-num text-sm text-muted-foreground flex gap-6">
                    <span>
                      Budget{" "}
                      <span className="text-foreground font-semibold">
                        {fmtMoney(budgetedSum)}
                      </span>
                    </span>
                    <span>
                      Actual{" "}
                      <span className="text-foreground font-semibold">
                        {fmtMoney(actualSum)}
                      </span>
                    </span>
                    <span className="hidden md:inline">
                      Δ{" "}
                      <span
                        className={cn(
                          "font-semibold",
                          diff >= 0 ? "text-positive" : "text-negative",
                        )}
                      >
                        {fmtMoney(diff)}
                      </span>
                    </span>
                  </div>
                </button>

                {isOpen && (
                  <div>
                    {/* Header row */}
                    <div className="hidden md:grid grid-cols-[1fr,120px,120px,120px,140px,32px] gap-4 px-5 py-2 border-b border-border text-[10px] uppercase tracking-wider text-muted-foreground">
                      <div>Category</div>
                      <div className="text-right">Budgeted</div>
                      <div className="text-right">Actual</div>
                      <div className="text-right">Difference</div>
                      <div>% Spent</div>
                      <div></div>
                    </div>
                    <ul>
                      {sectionLines.map((line) => (
                        <BudgetRow
                          key={line.id}
                          line={line}
                          kind={sec.kind}
                          onChangeBudget={(v) => updateBudgeted(line.id, v)}
                          onChangeLabel={(v) => updateLabel(line.id, v)}
                          onRemove={() => removeLine(line.id)}
                          onActualClick={() => setDrilldownLine(line)}
                        />
                      ))}
                    </ul>
                    <div className="px-5 py-3 border-t border-border bg-secondary/20">
                      <button
                        onClick={() => addLine(sec.key)}
                        className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground hover:text-accent transition-colors"
                      >
                        <Plus className="h-3 w-3" />
                        Add line
                      </button>
                    </div>
                  </div>
                )}
              </section>
            );
          })}
        </div>

        <div className="mt-12 text-xs text-muted-foreground italic">
          Edits save automatically and sync across both of you.
        </div>
      </div>
      <BudgetActualDrilldown
        open={drilldownLine !== null}
        onOpenChange={(v) => { if (!v) setDrilldownLine(null); }}
        line={drilldownLine}
        monthLabel={`${MONTH_LABELS[monthIdx]} ${year}`}
        transactions={ledger.transactions}
        recurringItems={recurringItems}
      />
    </TooltipProvider>
  );
}

function BudgetRow({
  line,
  kind,
  onChangeBudget,
  onChangeLabel,
  onRemove,
  onActualClick,
}: {
  line: BudgetLine;
  kind: "income" | "expense";
  onChangeBudget: (v: number) => void;
  onChangeLabel: (v: string) => void;
  onRemove: () => void;
  onActualClick: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(line.budgeted.toString());
  const [editingLabel, setEditingLabel] = useState(false);
  const [labelDraft, setLabelDraft] = useState(line.label);

  const diff = kind === "income" ? line.actual - line.budgeted : line.budgeted - line.actual;
  const pct = line.budgeted > 0 ? (line.actual / line.budgeted) * 100 : 0;
  const over = kind === "expense" && line.actual > line.budgeted;
  const warn = kind === "expense" && pct > 80 && pct <= 100;

  const sourceColor =
    line.source === "auto-debt" ? "bg-accent"
      : line.source === "auto-income" ? "bg-positive"
        : "bg-foreground";

  const isLocked = line.source !== "editable";
  // Income rows (auto-income) sync back to recurring_items, so allow amount edits
  // but keep the label locked (rename happens on the Bills page).
  const amountLocked = isLocked && line.source !== "auto-income";

  const commit = () => {
    setEditing(false);
    const n = parseFloat(draft.replace(/[^0-9.\-]/g, ""));
    onChangeBudget(isNaN(n) ? 0 : n);
  };

  const commitLabel = () => {
    setEditingLabel(false);
    onChangeLabel(labelDraft);
  };

  return (
    <li className="group grid grid-cols-[1fr,120px,32px] md:grid-cols-[1fr,120px,120px,120px,140px,32px] gap-4 px-5 py-3 border-b border-border last:border-b-0 items-center">
      {/* Category */}
      <div className="flex items-start gap-3 min-w-0">
        <span className={cn("mt-1.5 h-2 w-2 rounded-full shrink-0", sourceColor)} />
        <div className="min-w-0 flex-1">
          {editingLabel && !isLocked ? (
            <Input
              autoFocus
              value={labelDraft}
              onChange={(e) => setLabelDraft(e.target.value)}
              onBlur={commitLabel}
              onKeyDown={(e) => {
                if (e.key === "Enter") commitLabel();
                if (e.key === "Escape") { setEditingLabel(false); setLabelDraft(line.label); }
              }}
              className="h-8 text-sm font-medium"
            />
          ) : isLocked ? (
            <div className="text-sm font-medium truncate">{line.label}</div>
          ) : (
            <button
              onClick={() => { setLabelDraft(line.label); setEditingLabel(true); }}
              className="text-sm font-medium truncate hover:text-accent transition-colors text-left w-full inline-flex items-center gap-1.5"
            >
              <span className="truncate">{line.label}</span>
              <Pencil className="h-3 w-3 opacity-0 group-hover:opacity-60 shrink-0" />
            </button>
          )}
          {line.notes && (
            <div className="text-xs text-muted-foreground truncate">{line.notes}</div>
          )}
        </div>
      </div>

      {/* Budgeted */}
      <div className="text-right">
        {editing && !amountLocked ? (
          <Input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === "Enter") commit();
              if (e.key === "Escape") { setEditing(false); setDraft(line.budgeted.toString()); }
            }}
            className="h-8 text-right font-mono-num"
          />
        ) : amountLocked ? (
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="font-mono-num text-sm flex items-center justify-end gap-1 text-muted-foreground cursor-help">
                <Lock className="h-3 w-3" />
                {fmtMoney(line.budgeted)}
              </div>
            </TooltipTrigger>
            <TooltipContent>
              {line.source === "auto-debt"
                ? "Edit on Debts page"
                : "Edit on Bills page"}
            </TooltipContent>
          </Tooltip>
        ) : (
          <button
            onClick={() => { setDraft(line.budgeted.toString()); setEditing(true); }}
            className="font-mono-num text-sm font-semibold flex items-center justify-end gap-1 hover:text-accent transition-colors w-full"
          >
            {fmtMoney(line.budgeted)}
            <Pencil className="h-3 w-3 opacity-0 group-hover:opacity-60" />
          </button>
        )}
      </div>

      {/* Actual */}
      <div className="hidden md:block text-right">
        <button
          onClick={onActualClick}
          className="font-mono-num text-sm text-muted-foreground hover:text-foreground hover:underline underline-offset-4 decoration-dotted transition-colors"
          title="View transactions"
        >
          {fmtMoney(line.actual)}
        </button>
      </div>

      {/* Difference */}
      <div
        className={cn(
          "hidden md:block text-right font-mono-num text-sm font-semibold",
          diff >= 0 ? "text-positive" : "text-negative",
        )}
      >
        {fmtMoney(diff)}
      </div>

      {/* % Spent */}
      <div className="hidden md:block">
        <div className="flex items-center justify-between gap-2 mb-1">
          <div className="h-1 bg-secondary flex-1 overflow-hidden">
            <div
              className={cn(
                "h-full transition-all",
                over ? "bg-negative" : warn ? "bg-accent" : "bg-foreground",
              )}
              style={{ width: `${Math.min(100, pct)}%` }}
            />
          </div>
          <span className="font-mono-num text-[11px] text-muted-foreground w-10 text-right">
            {line.budgeted > 0 ? `${pct.toFixed(0)}%` : "—"}
          </span>
        </div>
      </div>

      {/* Delete */}
      <div className="flex justify-end">
        {isLocked ? (
          <span className="h-6 w-6" />
        ) : (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onRemove}
                className="h-6 w-6 inline-flex items-center justify-center text-muted-foreground hover:text-negative hover:bg-secondary transition-colors opacity-0 group-hover:opacity-100"
                aria-label={`Remove ${line.label}`}
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Remove line</TooltipContent>
          </Tooltip>
        )}
      </div>
    </li>
  );
}

function LegendChip({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-1 border border-border bg-card rounded-2xl">
      <span className={cn("h-2 w-2 rounded-full", color)} />
      <span className="text-muted-foreground">{label}</span>
    </span>
  );
}

function Stat({
  label,
  value,
  tone,
  last,
}: {
  label: string;
  value: string;
  tone?: "positive" | "negative";
  last?: boolean;
}) {
  const color =
    tone === "positive" ? "text-positive"
      : tone === "negative" ? "text-negative"
        : "text-foreground";
  return (
    <div className={cn("px-5 py-5", !last && "md:border-r border-border")}>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
        {label}
      </div>
      <div className={cn("font-display text-3xl font-bold tabular", color)}>
        {value}
      </div>
    </div>
  );
}

function DualStat({
  label,
  budget,
  actual,
  budgetTone,
  actualTone,
  last,
}: {
  label: string;
  budget: string;
  actual: string;
  budgetTone?: "positive" | "negative" | "muted" | "warn";
  actualTone?: "positive" | "negative" | "muted" | "warn";
  last?: boolean;
}) {
  const tone = (t?: string) =>
    t === "positive" ? "text-positive"
      : t === "negative" ? "text-negative"
        : t === "warn" ? "text-yellow-600 dark:text-yellow-500"
          : "text-foreground";
  return (
    <div className={cn("px-5 py-4", !last && "md:border-r border-border")}>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
        {label}
      </div>
      <div className="space-y-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Budget</span>
          <span className={cn("font-display text-xl font-semibold tabular", tone(budgetTone))}>
            {budget}
          </span>
        </div>
        <div className="flex items-baseline justify-between gap-2 border-t border-border/60 pt-1">
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Actual</span>
          <span className={cn("font-display text-xl font-semibold tabular", tone(actualTone))}>
            {actual}
          </span>
        </div>
      </div>
    </div>
  );
}

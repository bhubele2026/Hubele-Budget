import { useMemo, useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertTriangle, ArrowRight, PartyPopper } from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis,
} from "recharts";
import { toast } from "sonner";
import confetti from "canvas-confetti";
import { useRecurring } from "@/hooks/useRecurring";
import { useDebts } from "@/hooks/useDebts";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { useLedger } from "@/hooks/useLedger";
import { useForecastResolutions } from "@/hooks/useForecastResolutions";
import { simulate } from "@/lib/avalanche";
import {
  addDays, buildDaily, expandAll, fmtISO, summarize,
} from "@/lib/forecast";
import {
  buildLineRegister, buildBucket, monthKey,
  type LineRow, type PlanLine, type BankLine, type BucketEntry,
} from "@/lib/forecastMatch";
import { fmtMoney } from "@/lib/budgetData";
import { cn } from "@/lib/utils";
import { PlanRegister } from "@/components/PlanRegister";
import { ForecastToMatch } from "@/components/ForecastToMatch";
import { ReviewBucket } from "@/components/ReviewBucket";
import { RecurringDialog } from "@/components/RecurringDialog";
import { buildDebtMinAmountOverrides } from "@/lib/debtMinSync";
import type { Transaction } from "@/lib/ledgerTypes";

type RangeKey = "30d" | "60d" | "90d" | "6mo" | "1yr";
const RANGES: { key: RangeKey; label: string; days: number }[] = [
  { key: "30d", label: "30 days", days: 30 },
  { key: "60d", label: "60 days", days: 60 },
  { key: "90d", label: "90 days", days: 90 },
  { key: "6mo", label: "6 months", days: 183 },
  { key: "1yr", label: "1 year", days: 365 },
];

type BalanceTxn = { type: string; amount: number; running_balance?: number | null };

function signedAmount(t: { type: string; amount: number }): number {
  const a = Math.abs(Number(t.amount));
  return t.type === "income" ? a : -a;
}

function roundMoney(n: number): number {
  const rounded = Math.round(n * 100) / 100;
  return Math.abs(rounded) < 0.005 ? 0 : rounded;
}

function computeRunningBalances(transactions: BalanceTxn[], startingBalance: number): number[] {
  let balance = startingBalance;
  return transactions.map((t) => {
    const imported = t.running_balance == null ? null : Number(t.running_balance);
    balance = Number.isFinite(imported) ? imported : roundMoney(balance + signedAmount(t));
    return roundMoney(balance);
  });
}


export default function Forecast() {
  const { items, isLoading, error: recurringError, refetch: refetchRecurring, add } = useRecurring();
  const { debts } = useDebts();
  const { settings } = useAvalancheSettings();
  const { data: ledger } = useLedger({ account: "banking" });
  const {
    resolutions, closedMonths, resolve, unresolve, closeoutMonth, reopenMonth,
  } = useForecastResolutions();

  // Load prior month (April) and current month (May) banking data
  const now = useMemo(() => new Date(), []);
  const currentMonth = now.getMonth() + 1; // 1-based
  const currentYear = now.getFullYear();
  const priorMonth = currentMonth === 1 ? 12 : currentMonth - 1;
  const priorYear = currentMonth === 1 ? currentYear - 1 : currentYear;

  const { data: priorMonthData } = useLedger({ month: priorMonth, year: priorYear, account: "banking" });
  const { data: currentMonthData } = useLedger({ month: currentMonth, year: currentYear, account: "banking" });

  // Bank tab truth: the Forecast starts from the running balance at the end of April.
  // If transactions carry an imported running_balance, use that exact displayed value.
  // Otherwise, derive the same carry-forward balance from May's bank activity so that
  // replaying May transactions lands on the current Bank ending balance.
  const priorMonthEndBalance = useMemo(() => {
    const lastImported = [...priorMonthData.transactions]
      .reverse()
      .find((t) => t.running_balance != null)?.running_balance;
    if (lastImported != null) return roundMoney(Number(lastImported));

    const currentNet = currentMonthData.transactions.reduce((sum, t) => sum + signedAmount(t), 0);
    return roundMoney(-currentNet);
  }, [priorMonthData.transactions, currentMonthData.transactions]);

  const currentBankEndBalance = useMemo(() => {
    const currentBalances = computeRunningBalances(currentMonthData.transactions, priorMonthEndBalance);
    return currentBalances[currentBalances.length - 1] ?? priorMonthEndBalance;
  }, [currentMonthData.transactions, priorMonthEndBalance]);

  const [range, setRange] = useState<RangeKey>("30d");
  const today = useMemo(() => new Date(), []);
  const [startDate, setStartDate] = useState<string>(fmtISO(today));
  const [bucketMonth, setBucketMonth] = useState<string>(monthKey(fmtISO(today)));

  const killDates = useMemo(() => {
    const map = new Map<string, Date>();
    if (debts.length === 0) return map;
    const today = new Date(startDate);
    // Pre-seed already paid-off / zero-balance debts so their minimums stop now
    for (const d of debts) {
      if (d.status === "paid_off" || (d.balance ?? 0) <= 0) {
        map.set(d.id, today);
      }
    }
    const activeDebts = debts.filter((d) => d.status !== "paid_off" && (d.balance ?? 0) > 0);
    if (activeDebts.length > 0) {
      const extra = settings?.extraSource === "manual" ? Number(settings.manualExtra ?? 0) : 0;
      const sim = simulate({
        debts: activeDebts, extraPerMonth: extra,
        strategy: settings?.strategy ?? "avalanche",
        startDate: today,
      });
      for (const k of sim.killedOrder) map.set(k.id, k.date);
    }
    return map;
  }, [debts, settings, startDate]);

  const rangeMeta = RANGES.find((r) => r.key === range)!;
  const fromD = useMemo(() => new Date(startDate), [startDate]);
  const toD = useMemo(() => addDays(fromD, rangeMeta.days - 1), [fromD, rangeMeta.days]);

  const debtMinOverrides = useMemo(
    () => buildDebtMinAmountOverrides(items, debts),
    [items, debts],
  );

  const events = useMemo(
    () => expandAll(items, fromD, toD, killDates, debtMinOverrides),
    [items, fromD, toD, killDates, debtMinOverrides],
  );

  const forecastTxns = useMemo(() => {
    const byId = new Map<string, Transaction>();
    for (const t of [...priorMonthData.transactions, ...currentMonthData.transactions, ...ledger.transactions]) {
      byId.set(t.id, t);
    }
    return [...byId.values()].sort((a, b) => a.date.localeCompare(b.date));
  }, [priorMonthData.transactions, currentMonthData.transactions, ledger.transactions]);

  const txnsInWindow = useMemo(() => {
    const fromMs = fromD.getTime();
    const toMs = toD.getTime();
    return forecastTxns.filter((t) => {
      const m = new Date(t.date).getTime();
      return m >= fromMs && m <= toMs;
    });
  }, [forecastTxns, fromD, toD]);

  const startBalance = useMemo(() => {
    const startISO = fmtISO(fromD);
    const latestKnownDate = forecastTxns.reduce<string | null>(
      (latest, t) => (!latest || t.date > latest ? t.date : latest),
      null,
    );
    if (!latestKnownDate || startISO > latestKnownDate) return currentBankEndBalance;

    const netFromStartThroughLatest = forecastTxns.reduce((sum, t) => {
      if (t.date < startISO || t.date > latestKnownDate) return sum;
      return sum + signedAmount(t);
    }, 0);
    return roundMoney(currentBankEndBalance - netFromStartThroughLatest);
  }, [forecastTxns, fromD, currentBankEndBalance]);

  const selectedBankEndBalance = useMemo(() => {
    const netInWindow = txnsInWindow.reduce((sum, t) => sum + signedAmount(t), 0);
    return roundMoney(startBalance + netInWindow);
  }, [txnsInWindow, startBalance]);

  const startBalanceLabel = fmtISO(fromD) === fmtISO(today)
    ? "Starting bank balance"
    : `Bank balance before ${fmtISO(fromD)}`;
  const targetBalanceLabel = `Target bank balance through ${fmtISO(toD)}`;

  // Filter out resolutions linked to transactions that are NOT forecast-checked.
  // This prevents stale resolutions (e.g. user unchecked the Fc box) from polluting
  // the forecast register and review bucket.
  const activeResolutions = useMemo(() => {
    return resolutions.filter((r) => {
      // Plan-based resolutions (recurring_item_id) are always valid
      if (r.recurring_item_id) return true;
      // Transaction-based resolutions: only keep if the linked txn is forecast-flagged
      if (r.matched_txn_id && r.txn_forecast_flag === false) return false;
      return true;
    });
  }, [resolutions]);

  const { rows, allPlan, allBank } = useMemo(
    () => buildLineRegister({
      events, txns: txnsInWindow, resolutions: activeResolutions, closedMonths,
      startBalance, fromISO: fmtISO(fromD), toISO: fmtISO(toD), today,
    }),
    [events, txnsInWindow, activeResolutions, closedMonths, startBalance, fromD, toD, today],
  );

  // Headline summary based on future plan events from the projection portion
  const projectedDays = useMemo(
    () => buildDaily(
      allPlan
        .filter((e) => e.status === "future")
        .map((e) => ({ date: e.date, itemId: e.itemId, label: e.label, kind: "expense" as const, amount: e.amount })),
      // anchor from latest bank running balance in window (if any)
      rows.filter((r) => r.kind === "bank" && r.runningBalance != null).pop()?.runningBalance ?? startBalance,
      today,
      toD,
    ),
    [allPlan, rows, startBalance, today, toD],
  );
  const summary = useMemo(
    () => summarize(projectedDays, projectedDays[0]?.balance ?? startBalance),
    [projectedDays, startBalance],
  );

  const bucket = useMemo(
    () => buildBucket({ allPlan, allBank, resolutions: activeResolutions, closedMonths, monthFilter: bucketMonth }),
    [allPlan, allBank, activeResolutions, closedMonths, bucketMonth],
  );

  // Reconciliation strip
  const untriagedBank = rows.filter((r) => r.kind === "bank").length;
  const untriagedPlan = rows.filter((r) => r.kind === "plan" && r.status === "pending_plan").length;

  // Flagged transactions for the selected forecast window.
  const flaggedTxns = useMemo(
    () => txnsInWindow.filter((t) => t.forecast_flag),
    [txnsInWindow],
  );
  const resolvedTxnIds = useMemo(() => {
    const ids = new Set<string>();
    for (const r of activeResolutions) {
      if (r.matched_txn_id) ids.add(r.matched_txn_id);
    }
    return ids;
  }, [activeResolutions]);
  const pendingFlagged = flaggedTxns.filter((t) => !resolvedTxnIds.has(t.id));

  // Live forecast balance: starts at the balance before the selected start date,
  // applies resolved FC'd transactions, should reach the bank balance at window end.
  const forecastBalance = useMemo(() => {
    let bal = startBalance;
    for (const t of flaggedTxns) {
      if (t.date >= fmtISO(fromD) && t.date <= fmtISO(toD) && resolvedTxnIds.has(t.id)) {
        const signed = t.type === "income" ? Math.abs(Number(t.amount)) : -Math.abs(Number(t.amount));
        bal += signed;
      }
    }
    return Math.round(bal * 100) / 100;
  }, [startBalance, flaggedTxns, resolvedTxnIds, fromD, toD]);

  const reconciled = untriagedBank === 0 && untriagedPlan === 0 && pendingFlagged.length === 0;
  const balanceMatchesBank = Math.abs(forecastBalance - selectedBankEndBalance) < 0.01;
  const fullyReconciled = reconciled && balanceMatchesBank;

  // Confetti celebration when fully reconciled (balance hits $0)
  const prevReconciled = useRef(false);
  useEffect(() => {
    if (fullyReconciled && !prevReconciled.current) {
      // Multi-burst orange & purple celebration
      const fire = (opts: any) => confetti({ ...opts, colors: ["#f97316", "#fb923c", "#a855f7", "#c084fc"] });
      fire({ particleCount: 100, spread: 70, origin: { y: 0.65, x: 0.3 } });
      setTimeout(() => fire({ particleCount: 100, spread: 70, origin: { y: 0.65, x: 0.7 } }), 250);
      setTimeout(() => fire({ particleCount: 200, spread: 100, origin: { y: 0.5 } }), 500);
      setTimeout(() => fire({ particleCount: 150, spread: 90, origin: { y: 0.4 } }), 800);
    }
    prevReconciled.current = fullyReconciled;
  }, [fullyReconciled]);

  // ---- Action handlers ----
  const handleMatch = async (a: LineRow, b: LineRow) => {
    const plan = (a.kind === "plan" ? a : b) as PlanLine;
    const bank = (a.kind === "bank" ? a : b) as BankLine;
    try {
      await resolve.mutateAsync({
        recurring_item_id: plan.itemId,
        occurrence_date: plan.date,
        status: "matched",
        matched_txn_id: bank.txn.id,
      });
      toast.success("Matched");
    } catch (err: any) { toast.error(err?.message ?? "Failed to match"); }
  };

  // Drop a flagged txn onto a plan row
  const handleDropMatch = async (txnId: string, planRow: PlanLine) => {
    const txn = ledger.transactions.find((t) => t.id === txnId);
    if (!txn) return;
    const bankLine: BankLine = {
      kind: "bank",
      date: txn.date,
      txn,
      amount: txn.type === "income" ? Math.abs(txn.amount) : -Math.abs(txn.amount),
      status: "pending_bank",
    };
    await handleMatch(bankLine, planRow);
  };

  const handleMissed = async (plan: PlanLine) => {
    try {
      await resolve.mutateAsync({
        recurring_item_id: plan.itemId,
        occurrence_date: plan.date,
        status: "missed",
      });
      toast.success("Marked missed");
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };

  const handleNotForecasted = async (bank: BankLine) => {
    try {
      await resolve.mutateAsync({
        matched_txn_id: bank.txn.id,
        status: "ignored_unforecasted",
      });
      toast.success("Marked not forecasted");
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };

  const handleUnplanned = async (bank: BankLine) => {
    try {
      await resolve.mutateAsync({
        matched_txn_id: bank.txn.id,
        status: "unplanned",
      });
      toast.success("Marked as unplanned");
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };

  const handleUndo = async (e: BucketEntry) => {
    try {
      await unresolve.mutateAsync({ id: e.id });
      toast.success("Restored to register");
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };

  const handleCloseMonth = async () => {
    try {
      await closeoutMonth.mutateAsync(bucketMonth);
      toast.success(`Closed out ${bucketMonth}`);
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };
  const handleReopenMonth = async () => {
    try {
      await reopenMonth.mutateAsync(bucketMonth);
      toast.success(`Reopened ${bucketMonth}`);
    } catch (err: any) { toast.error(err?.message ?? "Failed"); }
  };

  // Add-from-bucket dialog state
  const [prefill, setPrefill] = useState<Partial<import("@/lib/forecast").RecurringItem> | null>(null);
  const handleAddToBills = (e: BucketEntry) => {
    setPrefill({
      kind: e.amount > 0 ? "income" : "expense",
      label: e.label || "Bank item",
      amount: Math.abs(e.amount),
      cadence: "monthly",
      anchor_date: e.date,
    });
  };

  const isClosed = closedMonths.has(bucketMonth);

  return (
    <div className="mx-auto max-w-7xl px-6 md:px-10 py-8">
      {/* Header */}
      <div className="border-b-2 border-foreground pb-4 mb-6 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Section IV</div>
          <h1 className="font-display text-5xl font-bold leading-none mt-1">Forecast</h1>
          <p className="font-display italic text-muted-foreground mt-2">
            Plan register — you decide every match.
          </p>
        </div>
        <div className="flex items-end gap-3 flex-wrap">
          <div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">Forecast from</div>
            <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-44 h-9" />
          </div>
          <Link
            to="/bills"
            className="inline-flex items-center gap-2 px-3 h-9 border border-foreground text-sm font-semibold hover:bg-foreground hover:text-background transition-colors"
          >
            Manage in Bills <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>

      {/* Range tabs */}
      <div className="flex items-center gap-1 mb-6 border border-border bg-card rounded-2xl w-fit p-1">
        {RANGES.map((r) => (
          <button
            key={r.key}
            onClick={() => setRange(r.key)}
            className={cn(
              "px-4 py-1.5 text-xs uppercase tracking-wider font-semibold transition-colors",
              range === r.key ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {r.label}
          </button>
        ))}
      </div>

      {/* Live Forecast Balance */}
      <div className={cn(
        "mb-6 px-6 py-5 rounded-2xl border-2 transition-all duration-500",
        fullyReconciled
          ? "border-orange-300 bg-gradient-to-r from-orange-50 via-purple-50 to-orange-50 animate-in fade-in zoom-in-95"
          : "border-border bg-card",
      )}>
        {fullyReconciled ? (
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <PartyPopper className="h-8 w-8 text-orange-500 animate-bounce" />
            <div className="text-center">
              <div className="font-display text-4xl font-bold bg-gradient-to-r from-orange-500 via-purple-500 to-orange-500 bg-clip-text text-transparent animate-pulse">
                🎉 Forecast Matches Bank! 🎉
              </div>
              <div className="text-sm text-muted-foreground mt-2">
                {startBalanceLabel} <span className="font-mono-num font-semibold text-foreground">{fmtMoney(startBalance)}</span> → {targetBalanceLabel.toLowerCase()} <span className="font-mono-num font-semibold text-positive">{fmtMoney(selectedBankEndBalance)}</span>
              </div>
            </div>
            <PartyPopper className="h-8 w-8 text-purple-500 animate-bounce" style={{ animationDelay: "0.15s" }} />
          </div>
        ) : (
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-6 flex-wrap">
              <div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Current Forecast Balance</div>
                <div className={cn(
                  "font-mono-num text-3xl font-bold mt-1 transition-colors",
                  forecastBalance > 0 ? "text-foreground" : forecastBalance === 0 ? "text-positive" : "text-destructive",
                )}>
                  {fmtMoney(forecastBalance)}
                </div>
              </div>
              <div className="text-xs text-muted-foreground space-y-0.5">
                <div>{startBalanceLabel}: <span className="font-mono-num font-semibold text-foreground">{fmtMoney(startBalance)}</span></div>
                <div>Accepted / matched impact: <span className="font-mono-num font-semibold text-foreground">{fmtMoney(forecastBalance - startBalance)}</span></div>
                <div>{targetBalanceLabel}: <span className="font-mono-num font-semibold text-foreground">{fmtMoney(selectedBankEndBalance)}</span></div>
              </div>
            </div>
            <div className="flex items-center gap-4 flex-wrap text-sm">
              <span className="text-muted-foreground">
                <strong className="text-foreground">{pendingFlagged.length}</strong> flagged ·{" "}
                <strong className="text-foreground">{untriagedPlan}</strong> plan ·{" "}
                <strong className="text-foreground">{untriagedBank}</strong> bank
              </span>
              <span className="text-xs text-muted-foreground">
                {bucket.filter((e) => e.status === "matched").length} matched ·{" "}
                {bucket.filter((e) => e.status === "unplanned").length} unplanned
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Headline stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 border-y border-foreground/30 mb-6">
        <Stat label="Lowest point" value={fmtMoney(summary.lowest.balance)} sub={summary.lowest.date}
              tone={summary.lowest.balance < 0 ? "negative" : summary.lowest.balance < 500 ? "warn" : undefined} />
        <Stat label="Ending balance" value={fmtMoney(summary.endBalance)} sub={projectedDays[projectedDays.length - 1]?.date ?? ""} />
        <Stat label="Projected income" value={fmtMoney(summary.income)} tone="positive" />
        <Stat label="Projected expenses" value={fmtMoney(summary.expense)} last />
      </div>

      {summary.belowZeroDays > 0 && (
        <div className="mb-6 flex items-center gap-2 px-4 py-3 border border-destructive/40 bg-destructive/10 text-sm">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <span><strong>{summary.belowZeroDays}</strong> projected day{summary.belowZeroDays > 1 ? "s" : ""} below $0 — adjust timing or add a buffer.</span>
        </div>
      )}

      {/* Chart */}
      <div className="border border-border bg-card rounded-2xl mb-6 p-4">
        <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Projected balance</div>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={projectedDays.map((d) => ({ date: d.date, balance: d.balance }))}>
            <defs>
              <linearGradient id="forecastFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--accent))" stopOpacity={0.4} />
                <stop offset="100%" stopColor="hsl(var(--accent))" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(v) => v.slice(5)} />
            <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
            <RTooltip
              contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", fontSize: 12 }}
              formatter={(v: number) => fmtMoney(v)}
            />
            <ReferenceLine y={0} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
            <Area type="monotone" dataKey="balance" stroke="hsl(var(--accent))" strokeWidth={2} fill="url(#forecastFill)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* To Match tray — flagged banking transactions */}
      <ForecastToMatch
        flaggedTxns={flaggedTxns}
        planRows={rows}
        resolvedTxnIds={resolvedTxnIds}
        onMatch={(bankRow, planRow) => handleMatch(bankRow, planRow)}
        onUnplanned={(bankRow) => handleUnplanned(bankRow)}
      />

      {/* Plan register (line-by-line) */}
      <PlanRegister
        rows={rows}
        actions={{
          onMatch: handleMatch,
          onMissed: (p) => handleMissed(p),
          onNotForecasted: (b) => handleNotForecasted(b),
        }}
        onDropMatch={handleDropMatch}
      />

      {/* Review bucket */}
      <ReviewBucket
        entries={bucket}
        monthKey={bucketMonth}
        onMonthChange={setBucketMonth}
        isClosed={isClosed}
        onCloseMonth={handleCloseMonth}
        onReopenMonth={handleReopenMonth}
        onUndo={handleUndo}
        onAddToBills={handleAddToBills}
      />

      {/* Loading / error fallback for recurring data */}
      {isLoading && items.length === 0 && (
        <div className="border border-border bg-card rounded-2xl px-4 py-6 text-sm text-muted-foreground">Loading recurring items…</div>
      )}
      {recurringError && items.length === 0 && (
        <div className="border border-destructive/40 bg-destructive/10 px-4 py-4 space-y-3">
          <div className="text-sm text-destructive">
            Couldn't reach the backend. {recurringError?.message ? `(${recurringError.message})` : ""}
          </div>
          <Button size="sm" variant="outline" onClick={() => refetchRecurring()}>Retry</Button>
        </div>
      )}

      {/* Hidden controlled dialog for prefill flows */}
      {prefill && (
        <RecurringDialog
          mode="add"
          debts={debts}
          hideTrigger
          open={!!prefill}
          onOpenChange={(v) => { if (!v) setPrefill(null); }}
          prefill={prefill}
          onSubmit={async (p) => {
            try {
              await add.mutateAsync(p);
              toast.success("Added to Bills");
              setPrefill(null);
            } catch (err: any) {
              toast.error(err?.message ?? "Failed to add");
            }
          }}
        />
      )}
    </div>
  );
}

function Stat({ label, value, sub, tone, last }: {
  label: string; value: string; sub?: string;
  tone?: "positive" | "negative" | "warn"; last?: boolean;
}) {
  const color =
    tone === "positive" ? "text-positive"
      : tone === "negative" ? "text-destructive"
      : tone === "warn" ? "text-amber-500" : "";
  return (
    <div className={cn("px-5 py-4", !last && "border-r border-border")}>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={cn("font-mono-num text-2xl font-bold mt-1", color)}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

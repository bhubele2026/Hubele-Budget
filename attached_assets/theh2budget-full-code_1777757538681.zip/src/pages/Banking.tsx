import { useMemo, useState, useRef, useId } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Plus, Search, Upload, Trash2, ChevronLeft, ChevronRight, ChevronsUpDown, Check } from "lucide-react";
import PlaidConnect from "@/components/PlaidConnect";
import PlaidSync from "@/components/PlaidSync";
import { toast } from "sonner";
import { useLedger } from "@/hooks/useLedger";
import { useDebts } from "@/hooks/useDebts";
import { INITIAL_BUDGET_NO_DEBTS, fmtMoney } from "@/lib/budgetData";
import { parseBankPaste, inferType, type ParsedRow } from "@/lib/bankParser";
import { suggestCategory, buildMatchNote } from "@/lib/ruleEngine";
import type { Transaction, TxType } from "@/lib/ledgerTypes";
import { cn } from "@/lib/utils";
import { isDuplicate } from "@/lib/duplicateDetect";
import { readFileAsText } from "@/lib/fileImport";

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const TYPE_OPTIONS: TxType[] = ["expense","income","transfer","debt_payment"];
const TYPE_LABELS: Record<TxType, string> = { expense: "expense", income: "income", transfer: "transfer", debt_payment: "debt payment" };

export default function Banking() {
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [monthIdx, setMonthIdx] = useState(today.getMonth()); // 0-based
  const { data, isLoading, addTransaction, updateTransaction, deleteTransaction, importBatch } =
    useLedger({ month: monthIdx + 1, year, account: "banking" });
  const { debts } = useDebts();

  const categoryOptions = useMemo(() => {
    // Pull from live budget_lines in DB so new budget items auto-appear
    const fromBudget = (data.budget_lines ?? []).map((b: any) => b.label as string);
    // Fallback to hardcoded list if DB hasn't loaded yet
    const fallback = fromBudget.length > 0 ? fromBudget : INITIAL_BUDGET_NO_DEBTS.map((b) => b.label);
    const fromDebts = debts.map((d) => d.creditor);
    return Array.from(new Set([...fallback, ...fromDebts])).sort();
  }, [debts, data.budget_lines]);

  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TxType>("all");

  const filtered = useMemo(() => {
    return data.transactions.filter((t) => {
      if (typeFilter !== "all" && t.type !== typeFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!t.description.toLowerCase().includes(q) && !(t.category ?? "").toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [data.transactions, search, typeFilter]);

  // Compute running balances client-side, anchoring the selected month to end at $0.
  const runningBalances = useMemo(() => {
    const map = new Map<string, number>();
    const netChange = data.transactions.reduce((sum, t) => {
      const a = Math.abs(Number(t.amount));
      return sum + (t.type === "income" ? a : -a);
    }, 0);
    let balance = -netChange;
    for (const t of data.transactions) {
      const a = Math.abs(Number(t.amount));
      if (t.type === "income") balance += a;
      else balance -= a;
      map.set(t.id, Math.abs(balance) < 0.005 ? 0 : balance);
    }
    return map;
  }, [data.transactions]);

  const totals = useMemo(() => {
    let income = 0, expense = 0, debtPayments = 0;
    for (const t of data.transactions) {
      const a = Math.abs(Number(t.amount));
      if (t.type === "income") income += a;
      else if (t.type === "expense") expense += a;
      else if (t.type === "debt_payment") debtPayments += a;
    }
    return { income, expense, debtPayments, net: income - expense - debtPayments };
  }, [data.transactions]);

  // Show Forecast checkbox column for May 2026 onward
  const showFc = year > 2026 || (year === 2026 && monthIdx >= 4);

  return (
    <div className="mx-auto max-w-7xl px-6 md:px-10 py-8">
      <div className="border-b-2 border-foreground pb-4 mb-6 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Section III</div>
          <h1 className="font-display text-5xl font-bold leading-none mt-1">Banking</h1>
          <p className="font-display italic text-muted-foreground mt-2">Checking account — every dollar in and out, auto-coded to your budget.</p>
        </div>
        <div className="flex items-center gap-2">
          <PlaidSync />
          <PlaidConnect />
          <ImportDialog
            categoryOptions={categoryOptions}
            existingRules={data.rules}
            existingTransactions={data.transactions}
            onImport={async (rows, newRules) => {
              await importBatch.mutateAsync({ rows, new_rules: newRules, label: `Bank paste ${new Date().toISOString().slice(0,10)}` });
              toast.success(`Imported ${rows.length} transactions`);
            }}
          />
          <AddTxnDialog
            categoryOptions={categoryOptions}
            onAdd={async (p) => { await addTransaction.mutateAsync(p); toast.success("Added"); }}
          />
        </div>
      </div>

      {/* Month nav + summary */}
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => {
            if (monthIdx === 0) { setMonthIdx(11); setYear(year - 1); } else setMonthIdx(monthIdx - 1);
          }}><ChevronLeft className="h-4 w-4" /></Button>
          <div className="font-display text-xl font-semibold w-32 text-center">{MONTHS[monthIdx]} {year}</div>
          <Button variant="outline" size="icon" onClick={() => {
            if (monthIdx === 11) { setMonthIdx(0); setYear(year + 1); } else setMonthIdx(monthIdx + 1);
          }}><ChevronRight className="h-4 w-4" /></Button>
        </div>
        <div className="grid grid-cols-5 gap-4 text-sm">
          <SummaryStat label="Ending Balance" value={data.transactions.length ? (runningBalances.get(data.transactions[data.transactions.length - 1].id) ?? 0) : 0} className="font-bold" />
          <SummaryStat label="Income" value={totals.income} className="text-positive" />
          <SummaryStat label="Expenses" value={totals.expense} />
          <SummaryStat label="Debt Payments" value={totals.debtPayments} className="text-primary" />
          <SummaryStat label="Net" value={totals.net} className={totals.net >= 0 ? "text-positive" : "text-destructive"} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search description or category" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-9" />
        </div>
        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as any)}>
          <SelectTrigger className="h-9 w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            <SelectItem value="income">Income</SelectItem>
            <SelectItem value="expense">Expense</SelectItem>
            <SelectItem value="transfer">Transfer</SelectItem>
            <SelectItem value="debt_payment">Debt Payment</SelectItem>
          </SelectContent>
        </Select>
        <div className="text-xs text-muted-foreground ml-auto">{filtered.length} of {data.transactions.length} rows</div>
      </div>

      <div className="border-y border-foreground/30 overflow-auto max-h-[calc(100vh-280px)]">
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-background">
            <tr className="text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border">
              <th className="text-left py-3 pr-3 w-10">#</th>
              <th className="text-left py-3 pr-3">Date</th>
              <th className="text-left py-3 pr-3 min-w-[260px]">Description</th>
              <th className="text-left py-3 pr-3">Type</th>
              <th className="text-left py-3 pr-3 min-w-[200px]">Category</th>
              {showFc && <th className="text-center py-3 pr-1 w-10" title="Send to Forecast">Fc</th>}
              <th className="text-right py-3 pr-3">Amount</th>
              <th className="text-right py-3 pr-3">Running</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={showFc ? 9 : 8} className="py-10 text-center text-muted-foreground">Loading transactions…</td></tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr><td colSpan={showFc ? 9 : 8} className="py-10 text-center text-muted-foreground">
                No transactions for {MONTHS[monthIdx]} {year}. Click <strong>Paste bank feed</strong> to import.
              </td></tr>
            )}
            {filtered.map((t, idx) => (
              <TxnRow
                key={t.id}
                num={idx + 1}
                txn={t}
                showFc={showFc}
                runningBalance={runningBalances.get(t.id) ?? null}
                categoryOptions={categoryOptions}
                debtOptions={debts}
                onUpdate={(patch) => updateTransaction.mutate({ id: t.id, ...patch })}
                onDelete={() => { if (confirm("Delete this transaction?")) deleteTransaction.mutate(t.id); }}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SummaryStat({ label, value, className }: { label: string; value: number; className?: string }) {
  return (
    <div className="text-right">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={cn("font-mono-num font-semibold text-base", className)}>{fmtMoney(value)}</div>
    </div>
  );
}

function TxnRow({ num, txn, showFc, runningBalance, categoryOptions, debtOptions, onUpdate, onDelete }: {
  num: number;
  txn: Transaction;
  showFc: boolean;
  runningBalance: number | null;
  categoryOptions: string[];
  debtOptions: import("@/lib/debtData").Debt[];
  onUpdate: (p: Partial<Transaction>) => void;
  onDelete: () => void;
}) {
  const isDebtPayment = txn.type === "debt_payment";
  const displayFc = txn.forecast_flag ?? false;
  return (
    <tr className={cn("border-b border-border hover:bg-secondary/40 transition-colors",
      isDebtPayment && "bg-accent/5")}>
      <td className="py-2 pr-3 text-muted-foreground font-mono-num text-xs">{num}</td>
      <td className="py-2 pr-3 text-muted-foreground font-mono-num text-xs whitespace-nowrap">{txn.date}</td>
      <td className="py-2 pr-3">
        <div className="font-medium truncate max-w-[360px]" title={txn.description}>{txn.description}</div>
        {txn.notes && <div className="text-[11px] text-muted-foreground truncate" title={txn.notes}>{txn.notes}</div>}
      </td>
      <td className="py-2 pr-3">
        <Select value={txn.type} onValueChange={(v) => {
          const newType = v as TxType;
          onUpdate({ type: newType });
        }}>
          <SelectTrigger className={cn("h-7 text-xs w-32", isDebtPayment && "border-primary/40 text-primary font-medium")}><SelectValue /></SelectTrigger>
          <SelectContent>
            {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{TYPE_LABELS[t]}</SelectItem>)}
          </SelectContent>
        </Select>
      </td>
      <td className="py-2 pr-3">
        {isDebtPayment ? (
          <Select value={txn.category ?? ""} onValueChange={(v) => onUpdate({ category: v })}>
            <SelectTrigger className="h-7 text-xs w-56 border-primary/40">
              <SelectValue placeholder="Select card/debt…" />
            </SelectTrigger>
            <SelectContent>
              {debtOptions.map((d) => (
                <SelectItem key={d.id} value={d.creditor}>
                  <span className="font-medium">{d.creditor}</span>
                  <span className="text-muted-foreground ml-2 text-[10px]">{fmtMoney(d.balance)}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ) : (
          <CategoryPicker value={txn.category ?? ""} options={categoryOptions} onChange={(v) => onUpdate({ category: v })} />
        )}
      </td>
      {showFc && (
        <td className="py-2 pr-1 text-center">
          <Checkbox
            checked={displayFc}
            onCheckedChange={() => onUpdate({ forecast_flag: !displayFc })}
            className="border-orange-400 data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
            aria-label="Send to Forecast"
          />
        </td>
      )}
      <td className={cn("py-2 pr-3 text-right font-mono-num font-medium",
        txn.type === "income" ? "text-positive" : txn.type === "transfer" ? "text-muted-foreground" : isDebtPayment ? "text-primary" : "")}>
        {fmtMoney(Math.abs(txn.amount))}
      </td>
      <td className="py-2 pr-3 text-right font-mono-num text-xs text-muted-foreground">
        {runningBalance == null ? "—" : fmtMoney(runningBalance)}
      </td>
      <td className="py-2 pr-1">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onDelete}>
          <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
        </Button>
      </td>
    </tr>
  );
}

function CategoryPicker({ value, options, onChange }: {
  value: string; options: string[]; onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" aria-expanded={open}
          className="h-7 text-xs w-56 justify-between font-normal truncate">
          <span className="truncate">{value || "Uncategorized"}</span>
          <ChevronsUpDown className="ml-1 h-3 w-3 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-0" align="start">
        <Command>
          <CommandInput placeholder="Search or type…" className="h-8 text-xs" />
          <CommandList>
            <CommandEmpty className="py-2 text-center text-xs text-muted-foreground">
              No match — press Enter to use typed value
            </CommandEmpty>
            <CommandGroup>
              {options.map((o) => (
                <CommandItem key={o} value={o} onSelect={(v) => { onChange(v); setOpen(false); }}
                  className="text-xs">
                  <Check className={cn("mr-2 h-3 w-3", value === o ? "opacity-100" : "opacity-0")} />
                  {o}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function AddTxnDialog({ categoryOptions, onAdd }: {
  categoryOptions: string[];
  onAdd: (p: Partial<Transaction>) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [desc, setDesc] = useState("");
  const [type, setType] = useState<TxType>("expense");
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const reset = () => { setDate(new Date().toISOString().slice(0,10)); setDesc(""); setType("expense"); setCategory(""); setAmount(""); };
  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild><Button className="gap-2"><Plus className="h-4 w-4" /> Add</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Add transaction</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs">Date<Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label className="text-xs">Type
            <Select value={type} onValueChange={(v) => setType(v as TxType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </label>
          <label className="text-xs col-span-2">Description<Input value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
          <label className="text-xs col-span-2">Category
            <Input list="cat-options" value={category} onChange={(e) => setCategory(e.target.value)} />
            <datalist id="cat-options">{categoryOptions.map((o) => <option key={o} value={o} />)}</datalist>
          </label>
          <label className="text-xs col-span-2">Amount (positive number)
            <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={async () => {
            const a = Number(amount);
            if (!date || !desc || !a) { toast.error("Fill date, description, amount"); return; }
            await onAdd({
              date, description: desc, type, category: category || null,
              amount: type === "income" ? Math.abs(a) : type === "transfer" ? -Math.abs(a) : Math.abs(a),
            });
            setOpen(false); reset();
          }}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

type StagedRow = ParsedRow & {
  type: TxType;
  category: string;
  matchKeyword: string | null;
  saveRule: boolean;
  ruleKeyword: string;
  include: boolean;
  isDuplicate: boolean;
};

function ImportDialog({ categoryOptions, existingRules, existingTransactions, onImport }: {
  categoryOptions: string[];
  existingRules: { keyword: string; category: string; type: TxType | null; priority: number; id: string }[];
  existingTransactions: Transaction[];
  onImport: (rows: any[], newRules: any[]) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [staged, setStaged] = useState<StagedRow[]>([]);
  const [fileName, setFileName] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    try {
      const content = await readFileAsText(file);
      setText(content);
      setFileName(file.name);
      toast.success(`Loaded ${file.name}`);
    } catch {
      toast.error("Could not read file");
    }
  };

  const parse = () => {
    const { rows, skipped } = parseBankPaste(text);
    const next: StagedRow[] = rows.map((r) => {
      const sug = suggestCategory(r.description, existingRules as any);
      const t = sug.type ?? inferType(r.amount, r.description);
      // Default suggested rule keyword = first 1-2 distinctive words
      const words = r.description.toUpperCase().replace(/[^A-Z0-9 ]+/g, " ").split(/\s+/).filter(Boolean);
      const ruleKw = sug.ruleKeyword ?? (words[0] ?? "");
      const dupe = isDuplicate(r.date, r.description, r.amount, existingTransactions);
      return {
        ...r, type: t, category: sug.category ?? "",
        matchKeyword: sug.ruleKeyword,
        saveRule: false, ruleKeyword: ruleKw, include: !dupe, isDuplicate: dupe,
      };
    });
    setStaged(next);
    const dupeCount = next.filter((r) => r.isDuplicate).length;
    if (skipped > 0) toast.message(`Parsed ${rows.length}, skipped ${skipped} unreadable lines`);
    else if (dupeCount > 0) toast.warning(`Parsed ${rows.length} rows — ${dupeCount} duplicate(s) auto-excluded`);
    else toast.success(`Parsed ${rows.length} rows`);
  };

  const reset = () => { setText(""); setStaged([]); setFileName(""); };

  const submit = async () => {
    const rows = staged.filter((r) => r.include).map((r) => ({
      date: r.date,
      description: r.description,
      type: r.type,
      category: r.category || null,
      amount: r.type === "income" ? Math.abs(r.amount) : -Math.abs(r.amount),
      notes: buildMatchNote(r.matchKeyword ?? r.ruleKeyword, r.category),
      source: "bank_import",
    }));
    if (rows.length === 0) { toast.error("Nothing to import"); return; }
    const newRules = staged
      .filter((r) => r.include && r.saveRule && r.ruleKeyword.trim() && r.category.trim())
      .map((r) => ({ keyword: r.ruleKeyword.trim(), category: r.category.trim(), type: r.type, priority: 10 }));
    await onImport(rows, newRules);
    setOpen(false); reset();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2"><Upload className="h-4 w-4" /> Import</Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl">
        <DialogHeader>
          <DialogTitle>Import bank transactions</DialogTitle>
        </DialogHeader>
        {staged.length === 0 ? (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Upload a CSV or Excel file from your bank, or paste rows directly.
            </p>
            <div
              className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-accent/50 transition-colors"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
              onDrop={(e) => { e.preventDefault(); e.stopPropagation(); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.xlsx,.xls,.txt"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              {fileName ? (
                <p className="text-sm font-medium text-accent">{fileName}</p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Drop a <span className="font-semibold">.csv</span> or <span className="font-semibold">.xlsx</span> file here, or click to browse
                </p>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground">or paste</span></div>
            </div>
            <Textarea
              value={text} onChange={(e) => { setText(e.target.value); setFileName(""); }}
              placeholder={"04/15/2026, APPLECARD GSBANK PAYMENT, -227.50\n2026-04-16,KFI STAFFING PAYROLL,3909.80"}
              className="font-mono text-xs min-h-[120px]"
            />
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={parse} disabled={!text.trim()}>Parse</Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground">
              Review {staged.length} rows. Edit Type/Category as needed. Tick <Badge variant="outline">Save rule</Badge> to remember the keyword for future imports.
              {staged.some((r) => r.isDuplicate) && (
                <span className="ml-2 text-amber-600 font-semibold">
                  ⚠ {staged.filter((r) => r.isDuplicate).length} duplicate(s) found &amp; auto-excluded
                </span>
              )}
            </div>
            <div className="max-h-[420px] overflow-auto border rounded-md">
              <table className="w-full text-xs">
                <thead className="bg-secondary/50 sticky top-0">
                  <tr>
                    <th className="text-left p-2 w-8"></th>
                    <th className="text-left p-2">Date</th>
                    <th className="text-left p-2">Description</th>
                    <th className="text-left p-2">Type</th>
                    <th className="text-left p-2">Category</th>
                    <th className="text-right p-2">Amount</th>
                    <th className="text-left p-2">Save rule (keyword)</th>
                  </tr>
                </thead>
                <tbody>
                  {staged.map((r, i) => (
                    <tr key={i} className="border-t border-border">
                      <td className="p-2"><Checkbox checked={r.include} onCheckedChange={(v) => {
                        const c = [...staged]; c[i].include = !!v; setStaged(c);
                      }} /></td>
                      <td className="p-2 font-mono-num">{r.date}</td>
                      <td className="p-2 max-w-[280px] truncate" title={r.description}>
                        {r.description}
                        {r.isDuplicate && <Badge variant="outline" className="ml-1 text-[10px] border-amber-500 text-amber-600">Duplicate</Badge>}
                      </td>
                      <td className="p-2">
                        <Select value={r.type} onValueChange={(v) => {
                          const c = [...staged]; c[i].type = v as TxType; setStaged(c);
                        }}>
                          <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-2">
                        <Input list="import-cat-options" value={r.category} onChange={(e) => {
                          const c = [...staged]; c[i].category = e.target.value; setStaged(c);
                        }} className={cn("h-7 text-xs w-48", !r.category && "border-amber-500/60")} placeholder="—" />
                      </td>
                      <td className={cn("p-2 text-right font-mono-num",
                        r.type === "income" ? "text-positive" : "")}>{fmtMoney(Math.abs(r.amount))}</td>
                      <td className="p-2">
                        <div className="flex items-center gap-1">
                          <Checkbox checked={r.saveRule} onCheckedChange={(v) => {
                            const c = [...staged]; c[i].saveRule = !!v; setStaged(c);
                          }} />
                          <Input value={r.ruleKeyword} onChange={(e) => {
                            const c = [...staged]; c[i].ruleKeyword = e.target.value; setStaged(c);
                          }} className="h-7 text-xs w-32" disabled={!r.saveRule} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <datalist id="import-cat-options">
                {categoryOptions.map((o) => <option key={o} value={o} />)}
              </datalist>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStaged([])}>Back</Button>
              <Button onClick={submit}>Import {staged.filter((r) => r.include).length}</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

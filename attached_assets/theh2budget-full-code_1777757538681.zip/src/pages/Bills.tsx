import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Trash2, TrendingUp, TrendingDown, ArrowRight, Lock } from "lucide-react";
import { toast } from "sonner";
import { useRecurring } from "@/hooks/useRecurring";
import { useDebts } from "@/hooks/useDebts";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { RecurringDialog } from "@/components/RecurringDialog";
import { fmtMoney } from "@/lib/budgetData";
import { addDays, expandAll, fmtISO, type Cadence, type RecurringItem } from "@/lib/forecast";
import { simulate } from "@/lib/avalanche";
import { cn } from "@/lib/utils";
import { buildDebtMinAmountOverrides, liveDebtMinAmount } from "@/lib/debtMinSync";

// Normalize any cadence to an approximate monthly amount for the summary card.
function monthly(amount: number, cadence: Cadence): number {
  switch (cadence) {
    case "weekly": return amount * 52 / 12;
    case "biweekly": return amount * 26 / 12;
    case "semimonthly": return amount * 2;
    case "monthly": return amount;
    case "quarterly": return amount / 3;
    case "annual": return amount / 12;
    case "onetime": return 0;
  }
}

export default function Bills() {
  const { items, isLoading, isFetching, error, refetch, add, update, remove } = useRecurring();
  const { debts } = useDebts();
  const { settings } = useAvalancheSettings();

  // Compute next occurrence for each item over the next 365 days,
  // honoring debt payoff dates so paid-off minimums stop appearing.
  const today = useMemo(() => new Date(), []);

  const killDates = useMemo(() => {
    const map = new Map<string, Date>();
    // Pre-seed already paid-off / zero-balance debts with today
    for (const d of debts) {
      if (d.status === "paid_off" || (d.balance ?? 0) <= 0) {
        map.set(d.id, today);
      }
    }
    const activeDebts = debts.filter((d) => d.status !== "paid_off" && (d.balance ?? 0) > 0);
    if (activeDebts.length > 0) {
      const extra = settings?.extraSource === "manual" ? Number(settings.manualExtra ?? 0) : 0;
      const sim = simulate({
        debts: activeDebts,
        extraPerMonth: extra,
        strategy: settings?.strategy ?? "avalanche",
        startDate: today,
      });
      for (const k of sim.killedOrder) map.set(k.id, k.date);
    }
    return map;
  }, [debts, settings, today]);

  const paidOffIds = useMemo(() => {
    const s = new Set<string>();
    for (const d of debts) {
      if (d.status === "paid_off" || (d.balance ?? 0) <= 0) s.add(d.id);
    }
    return s;
  }, [debts]);

  const debtMinOverrides = useMemo(
    () => buildDebtMinAmountOverrides(items, debts),
    [items, debts],
  );

  const nextDates = useMemo(() => {
    const map = new Map<string, string>();
    const events = expandAll(items, today, addDays(today, 365), killDates, debtMinOverrides);
    for (const ev of events) {
      if (!map.has(ev.itemId)) map.set(ev.itemId, ev.date);
    }
    return map;
  }, [items, today, killDates, debtMinOverrides]);

  const groups = useMemo(() => {
    const sortByNext = (arr: RecurringItem[]) =>
      [...arr].sort((a, b) => {
        const da = nextDates.get(a.id) ?? "9999";
        const db = nextDates.get(b.id) ?? "9999";
        return da.localeCompare(db);
      });
    return {
      income: sortByNext(items.filter((i) => i.kind === "income" && i.cadence !== "onetime")),
      expense: sortByNext(items.filter((i) => i.kind === "expense" && i.cadence !== "onetime")),
      debt_min: sortByNext(items.filter((i) => i.kind === "debt_min")),
      oneoff: sortByNext(items.filter((i) => i.cadence === "onetime")),
    };
  }, [items, nextDates]);

  const totals = useMemo(() => {
    let income = 0, expense = 0, debt = 0;
    for (const it of items) {
      const live = it.kind === "debt_min" ? liveDebtMinAmount(it, debts) : Number(it.amount);
      const m = monthly(live, it.cadence);
      if (it.kind === "income") income += m;
      else if (it.kind === "expense") expense += m;
      else debt += m;
    }
    return { income, expense, debt, outflow: expense + debt, net: income - expense - debt };
  }, [items, debts]);

  const handleDelete = (id: string, label: string) => {
    if (confirm(`Remove "${label}"?`)) {
      remove.mutate(id, {
        onSuccess: () => toast.success("Removed"),
        onError: (e: any) => toast.error(e?.message ?? "Failed to remove"),
      });
    }
  };

  const showLoading = isLoading && items.length === 0 && !error;
  const showError = !!error && items.length === 0;

  return (
    <div className="mx-auto max-w-7xl px-6 md:px-10 py-8">
      <div className="border-b-2 border-foreground pb-4 mb-8 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Section IV</div>
          <h1 className="font-display text-5xl font-bold leading-none mt-1">Bills</h1>
          <p className="font-display italic text-muted-foreground mt-2">
            Every recurring dollar in and out. Edits here flow into the Forecast.
          </p>
        </div>
        <div className="flex items-center gap-3">
          {isFetching && items.length > 0 && (
            <span className="text-[10px] uppercase tracking-widest text-muted-foreground">refreshing…</span>
          )}
          <RecurringDialog
            mode="add"
            debts={debts}
            triggerLabel="Add income or bill"
            onSubmit={async (p) => {
              await add.mutateAsync(p);
              toast.success("Added");
            }}
          />
        </div>
      </div>

      {showLoading && (
        <div className="border border-border bg-card rounded-2xl px-4 py-6 text-sm text-muted-foreground">Loading…</div>
      )}
      {showError && (
        <div className="border border-destructive/40 bg-destructive/10 px-4 py-4 space-y-3">
          <div className="text-sm text-destructive">
            Couldn't reach the backend. {error?.message ? `(${error.message})` : ""}
          </div>
          <Button size="sm" variant="outline" onClick={() => refetch()}>Retry</Button>
        </div>
      )}

      {!showLoading && !showError && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-8">
            <Group
              title="Income"
              sub="Paychecks and inflows"
              icon={<TrendingUp className="h-3.5 w-3.5 text-positive" />}
              items={groups.income}
              debts={debts}
              nextDates={nextDates}
              paidOffIds={paidOffIds}
              onUpdate={(p) => update.mutate(p)}
              onDelete={handleDelete}
            />
            <Group
              title="Bills & Expenses"
              sub="Rent, utilities, subscriptions, etc."
              icon={<TrendingDown className="h-3.5 w-3.5 text-destructive" />}
              items={groups.expense}
              debts={debts}
              nextDates={nextDates}
              paidOffIds={paidOffIds}
              onUpdate={(p) => update.mutate(p)}
              onDelete={handleDelete}
            />
            <Group
              title="Debt minimums"
              sub="Synced from Debts — edit balance & minimum payment on the Avalanche page."
              icon={<Lock className="h-3.5 w-3.5 text-accent" />}
              items={groups.debt_min}
              debts={debts}
              nextDates={nextDates}
              paidOffIds={paidOffIds}
              onUpdate={(p) => update.mutate(p)}
              onDelete={handleDelete}
              readOnly
            />
            <Group
              title="Single / one-off"
              sub="One-time bills or income — won't repeat"
              icon={<TrendingDown className="h-3.5 w-3.5 text-muted-foreground" />}
              items={groups.oneoff}
              debts={debts}
              nextDates={nextDates}
              paidOffIds={paidOffIds}
              onUpdate={(p) => update.mutate(p)}
              onDelete={handleDelete}
            />

            {items.length === 0 && (
              <div className="border border-border bg-card rounded-2xl px-4 py-8 text-sm text-muted-foreground text-center">
                No recurring items yet. Click "Add income or bill" to start.
              </div>
            )}
          </div>

          <aside className="space-y-6">
            <div className="border border-foreground p-5 bg-card">
              <div className="text-[10px] uppercase tracking-[0.25em] text-accent mb-2">Summary</div>
              <h2 className="font-display text-2xl font-semibold mb-4">Per month</h2>
              <Row label="Income" value={fmtMoney(totals.income)} tone="positive" />
              <Row label="Bills" value={fmtMoney(totals.expense)} />
              <Row label="Debt minimums" value={fmtMoney(totals.debt)} />
              <div className="border-t border-border my-3" />
              <Row label="Total outflow" value={fmtMoney(totals.outflow)} />
              <Row
                label="Net"
                value={fmtMoney(totals.net)}
                tone={totals.net >= 0 ? "positive" : "negative"}
                bold
              />
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mt-4">
                {items.length} active item{items.length === 1 ? "" : "s"}
              </div>
            </div>

            <Link
              to="/forecast"
              className="block border border-border bg-card rounded-2xl px-5 py-4 hover:bg-secondary/40 transition-colors"
            >
              <div className="text-[10px] uppercase tracking-[0.25em] text-accent mb-1">Next</div>
              <div className="flex items-center justify-between">
                <span className="font-display text-lg font-semibold">See cash forecast</span>
                <ArrowRight className="h-4 w-4" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Day-by-day balance based on these items.
              </p>
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
}

function Group({
  title, sub, icon, items, debts, nextDates, paidOffIds, onUpdate, onDelete, readOnly,
}: {
  title: string;
  sub: string;
  icon: React.ReactNode;
  items: RecurringItem[];
  debts: { id: string; creditor: string; minPayment?: number }[];
  nextDates: Map<string, string>;
  paidOffIds: Set<string>;
  onUpdate: (p: Partial<RecurringItem> & { id: string }) => void;
  onDelete: (id: string, label: string) => void;
  readOnly?: boolean;
}) {
  const subtotal = items.reduce((s, it) => {
    const live = it.kind === "debt_min" ? liveDebtMinAmount(it, debts as any) : Number(it.amount);
    return s + monthly(live, it.cadence);
  }, 0);
  return (
    <section className="border border-border bg-card rounded-2xl">
      <div className="px-4 py-3 border-b border-border bg-secondary/40 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          {icon}
          <h2 className="font-display text-lg font-semibold">{title}</h2>
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground">· {items.length}</span>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Per month</div>
          <div className="font-mono-num font-semibold">{fmtMoney(subtotal)}</div>
        </div>
      </div>
      <div className="px-4 py-2 text-[11px] text-muted-foreground border-b border-border">{sub}</div>
      {items.length === 0 ? (
        <div className="px-4 py-5 text-sm text-muted-foreground italic">None yet.</div>
      ) : (
        <ul className="divide-y divide-border">
          {items.map((it) => {
            const next = nextDates.get(it.id);
            const isPaidOff = !!(it.linked_debt_id && paidOffIds.has(it.linked_debt_id));
            const linkedDebt = it.linked_debt_id ? debts.find((d) => d.id === it.linked_debt_id) : undefined;
            const displayAmount = it.kind === "debt_min" ? liveDebtMinAmount(it, debts as any) : Number(it.amount);
            const isUnlinked = it.kind === "debt_min" && !linkedDebt;
            return (
              <li
                key={it.id}
                className={cn(
                  "px-4 py-3 flex items-center gap-3 group hover:bg-secondary/30",
                  isPaidOff && "opacity-50",
                )}
              >
                <div className="w-16 text-center border border-foreground/40 py-1 shrink-0 rounded-md">
                  {next && !isPaidOff ? (
                    <>
                      <div className="text-[10px] uppercase text-muted-foreground">
                        {new Date(next).toLocaleDateString("en-US", { month: "short" })}
                      </div>
                      <div className="font-display font-bold text-lg leading-none">
                        {new Date(next).getDate()}
                      </div>
                    </>
                  ) : (
                    <div className="text-[10px] text-muted-foreground py-1">—</div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium truncate flex items-center gap-2">
                    <span className={cn(isPaidOff && "line-through")}>{it.label}</span>
                    {isPaidOff && (
                      <span className="text-[10px] uppercase tracking-wide px-1.5 py-0.5 border border-positive/50 text-positive rounded-sm">
                        Paid off
                      </span>
                    )}
                    {isUnlinked && (
                      <span className="text-[10px] uppercase tracking-wide px-1.5 py-0.5 border border-muted-foreground/40 text-muted-foreground rounded-sm">
                        Unlinked
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {readOnly && linkedDebt ? (
                      <>linked to {linkedDebt.creditor} · min {fmtMoney(displayAmount)}/mo · stops at payoff</>
                    ) : (
                      <>
                        {it.cadence}
                        {it.cadence === "monthly" && it.day_of_month ? ` · day ${it.day_of_month}` : ""}
                        {it.category ? ` · ${it.category}` : ""}
                        {it.stops_at_payoff ? " · stops at payoff" : ""}
                      </>
                    )}
                  </div>
                </div>
                <div className={cn(
                  "font-mono-num text-sm font-semibold whitespace-nowrap",
                  it.kind === "income" ? "text-positive" : "",
                )}>
                  {it.kind === "income" ? "+" : "−"}{fmtMoney(displayAmount)}
                </div>
                {readOnly ? (
                  <div className="h-7 w-7 flex items-center justify-center" title="Synced from Debts — read-only">
                    <Lock className="h-3.5 w-3.5 text-muted-foreground/60" />
                  </div>
                ) : (
                  <>
                    <RecurringDialog
                      mode="edit"
                      item={it}
                      debts={debts}
                      onSubmit={async (p) => onUpdate({ id: it.id, ...p })}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 opacity-0 group-hover:opacity-100"
                      onClick={() => onDelete(it.id, it.label)}
                    >
                      <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
                    </Button>
                  </>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function Row({ label, value, tone, bold }: {
  label: string; value: string; tone?: "positive" | "negative"; bold?: boolean;
}) {
  const color =
    tone === "positive" ? "text-positive"
      : tone === "negative" ? "text-destructive" : "";
  return (
    <div className="flex justify-between py-1 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={cn("font-mono-num", color, bold && "font-bold text-lg")}>{value}</span>
    </div>
  );
}

// Suppress unused fmtISO warning — kept for future date-range filtering.
void fmtISO;

import { useMemo } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  Legend,
} from "recharts";
import { useDebts } from "@/hooks/useDebts";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { useRecurring } from "@/hooks/useRecurring";
import { useLedger } from "@/hooks/useLedger";
import { useActualsMTD } from "@/hooks/useActualsMTD";
import { applyPaymentsToDebts } from "@/lib/appliedBalance";
import { resolveExtra } from "@/lib/extraSource";
import { simulate, fmtMonth } from "@/lib/avalanche";

const PIE_COLORS = [
  "hsl(var(--accent))",
  "hsl(var(--primary))",
  "hsl(var(--foreground))",
  "hsl(var(--muted-foreground))",
  "hsl(var(--positive))",
  "hsl(var(--negative))",
  "hsl(var(--border))",
];

const TOOLTIP_STYLE = {
  background: "hsl(var(--card))",
  border: "1px solid hsl(var(--border))",
  borderRadius: 8,
};

function monthKey(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function monthLabel(key: string) {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleString("en-US", { month: "short", year: "2-digit" });
}

export default function Reports() {
  const { debts: rawDebts } = useDebts();
  const { settings } = useAvalancheSettings();
  const { items: recurring } = useRecurring();
  const { data: ledger } = useLedger();

  const debts = useMemo(
    () => applyPaymentsToDebts(rawDebts, ledger.transactions),
    [rawDebts, ledger.transactions],
  );
  const actuals = useActualsMTD(debts);
  const effectiveExtra = useMemo(
    () => resolveExtra(settings, actuals.avalancheActual),
    [settings, actuals.avalancheActual],
  );

  // 1. Payoff timeline from real avalanche sim
  const payoffTimeline = useMemo(() => {
    if (debts.length === 0) return [];
    const sim = simulate({ debts, extraPerMonth: effectiveExtra, strategy: settings.strategy });
    return sim.months.map((m) => ({
      month: fmtMonth(m.date),
      balance: Math.round(m.totalBalanceEnd),
    }));
  }, [debts, effectiveExtra, settings.strategy]);

  // 2. Budget vs actual for current month
  const budgetVsActual = useMemo(() => {
    const lines = ledger.budget_lines ?? [];
    const now = new Date();
    const mk = monthKey(now);
    const actualByCat = new Map<string, number>();
    for (const t of ledger.transactions) {
      if (!t.date || t.type !== "expense") continue;
      if (!t.date.startsWith(mk)) continue;
      const cat = t.category ?? "Uncategorized";
      actualByCat.set(cat, (actualByCat.get(cat) ?? 0) + Math.abs(Number(t.amount)));
    }
    const byCat = new Map<string, { budgeted: number; actual: number }>();
    for (const l of lines) {
      const cat = l.label;
      const cur = byCat.get(cat) ?? { budgeted: 0, actual: 0 };
      cur.budgeted += Number(l.budgeted) || 0;
      byCat.set(cat, cur);
    }
    for (const [cat, amt] of actualByCat) {
      const cur = byCat.get(cat) ?? { budgeted: 0, actual: 0 };
      cur.actual = amt;
      byCat.set(cat, cur);
    }
    return Array.from(byCat.entries())
      .map(([category, v]) => ({ category, budgeted: Math.round(v.budgeted), actual: Math.round(v.actual) }))
      .filter((d) => d.budgeted > 0 || d.actual > 0)
      .sort((a, b) => b.budgeted + b.actual - (a.budgeted + a.actual))
      .slice(0, 10);
  }, [ledger.budget_lines, ledger.transactions]);

  // 3. Cash flow over last 6 months from transactions
  const cashFlow = useMemo(() => {
    const now = new Date();
    const buckets: { key: string; income: number; expense: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      buckets.push({ key: monthKey(d), income: 0, expense: 0 });
    }
    const idx = new Map(buckets.map((b, i) => [b.key, i]));
    for (const t of ledger.transactions) {
      if (!t.date) continue;
      const k = t.date.slice(0, 7);
      const i = idx.get(k);
      if (i === undefined) continue;
      const amt = Math.abs(Number(t.amount));
      if (t.type === "income") buckets[i].income += amt;
      else buckets[i].expense += amt;
    }
    return buckets.map((b) => ({
      month: monthLabel(b.key),
      income: Math.round(b.income),
      expense: Math.round(b.expense),
      net: Math.round(b.income - b.expense),
    }));
  }, [ledger.transactions]);

  // 4. Category breakdown for current month
  const categoryBreakdown = useMemo(() => {
    const mk = monthKey(new Date());
    const m = new Map<string, number>();
    for (const t of ledger.transactions) {
      if (!t.date?.startsWith(mk)) continue;
      if (t.type !== "expense") continue;
      const cat = t.category ?? "Uncategorized";
      m.set(cat, (m.get(cat) ?? 0) + Math.abs(Number(t.amount)));
    }
    return Array.from(m.entries())
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 7);
  }, [ledger.transactions]);

  return (
    <div className="mx-auto max-w-6xl px-6 md:px-10 py-8">
      <div className="border-b-2 border-foreground pb-4 mb-8">
        <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Section VI</div>
        <h1 className="font-display text-5xl font-bold leading-none mt-1">Reports</h1>
        <p className="font-display italic text-muted-foreground mt-2">
          Three views of where the money has been and where it is going.
        </p>
      </div>

      {/* Chart 1 — Payoff timeline */}
      <section className="mb-12">
        <div className="text-[10px] uppercase tracking-[0.25em] text-accent">Forecast</div>
        <h2 className="font-display text-2xl font-semibold mt-1 mb-1">Debt payoff timeline</h2>
        <p className="text-sm text-muted-foreground mb-4">
          Projected total balance under your current {settings.strategy} plan.
        </p>
        <div className="h-72 border-y border-foreground/30 pt-4">
          {payoffTimeline.length === 0 ? (
            <EmptyState message="Add debts to see your payoff projection." />
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={payoffTimeline}>
                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `$${Math.round(v / 1000)}k`} />
                <Tooltip
                  contentStyle={TOOLTIP_STYLE}
                  formatter={(v: number) => [`$${v.toLocaleString()}`, "Balance"]}
                />
                <Line type="monotone" dataKey="balance" stroke="hsl(var(--accent))" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      {/* Chart 2 — Budget vs actual */}
      <section className="mb-12">
        <div className="text-[10px] uppercase tracking-[0.25em] text-accent">Budget</div>
        <h2 className="font-display text-2xl font-semibold mt-1 mb-1">Budget vs actual</h2>
        <p className="text-sm text-muted-foreground mb-4">This month's planned spend compared to actuals.</p>
        <div className="h-80 border-y border-foreground/30 pt-4">
          {budgetVsActual.length === 0 ? (
            <EmptyState message="Add budget lines or transactions to see this view." />
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={budgetVsActual} margin={{ left: 0, right: 8, top: 8, bottom: 8 }}>
                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="category" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" angle={-15} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `$${v}`} />
                <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v: number) => `$${v.toLocaleString()}`} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="budgeted" name="Budgeted" fill="hsl(var(--muted-foreground))" radius={[6, 6, 0, 0]} />
                <Bar dataKey="actual" name="Actual" fill="hsl(var(--accent))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      {/* Chart 3 — Cash flow */}
      <section className="mb-12">
        <div className="text-[10px] uppercase tracking-[0.25em] text-accent">Cash flow</div>
        <h2 className="font-display text-2xl font-semibold mt-1 mb-1">Income vs expenses</h2>
        <p className="text-sm text-muted-foreground mb-4">Last six months from your recorded transactions.</p>
        <div className="h-72 border-y border-foreground/30 pt-4">
          {cashFlow.every((c) => c.income === 0 && c.expense === 0) ? (
            <EmptyState message="Import or log transactions to see your cash flow." />
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={cashFlow}>
                <CartesianGrid stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `$${Math.round(v / 1000)}k`} />
                <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v: number) => `$${v.toLocaleString()}`} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="income" name="Income" fill="hsl(var(--positive))" radius={[6, 6, 0, 0]} />
                <Bar dataKey="expense" name="Expenses" fill="hsl(var(--negative))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      {/* Chart 4 — Category breakdown */}
      <section>
        <div className="text-[10px] uppercase tracking-[0.25em] text-accent">Spending</div>
        <h2 className="font-display text-2xl font-semibold mt-1 mb-1">This month by category</h2>
        <p className="text-sm text-muted-foreground mb-4">Where your money went so far this month.</p>
        <div className="h-80 border-y border-foreground/30 pt-4">
          {categoryBreakdown.length === 0 ? (
            <EmptyState message="No expenses logged this month yet." />
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v: number) => `$${v.toLocaleString()}`} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Pie data={categoryBreakdown} dataKey="value" nameKey="name" outerRadius={110} innerRadius={60} paddingAngle={2}>
                  {categoryBreakdown.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="h-full flex items-center justify-center text-sm text-muted-foreground italic">
      {message}
    </div>
  );
}

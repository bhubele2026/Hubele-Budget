import { useMemo, useState, useCallback } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { useDebts } from "@/hooks/useDebts";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { useLedger } from "@/hooks/useLedger";
import { useReimbursables } from "@/hooks/useReimbursables";
import { useRecurring } from "@/hooks/useRecurring";
import { addDaysISO } from "@/hooks/useWeeklyAllowance";
import { useDashboardBudget } from "@/hooks/useDashboardBudget";
import { simulate, fmtMoney, fmtMonth } from "@/lib/avalanche";
import { applyPaymentsToDebts } from "@/lib/appliedBalance";
import { buildLiveBudget, INITIAL_BUDGET_NO_DEBTS, type BudgetLine } from "@/lib/budgetData";
import { useActualsMTD } from "@/hooks/useActualsMTD";
import { resolveExtra } from "@/lib/extraSource";
import { addDays, fmtISO } from "@/lib/forecast";
import { accountOf } from "@/lib/ledgerTypes";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import h2Logo from "@/assets/h2-logo.png";

const CARD_PAYMENT_RX =
  /credit\s*card|card\s*payment|capital\s*one|amex|american\s*express|applecard|apple\s*card|synchrony|citi|discover|chase|barclay|sofi|wells\s*fargo/i;
const DEBT_PAYMENT_RX =
  /\b(loan|mortgage|auto\s*pay|car\s*payment|student\s*loan|heloc|line\s*of\s*credit|principal|installment)\b/i;

function classifyWeekly(t: { category?: string | null; weekly_allowance?: boolean }):
  "groceries" | "dining" | "entertainment" | "misc" | null {
  if (!t.weekly_allowance) return null;
  const cat = (t.category ?? "").toLowerCase().trim();
  if (cat === "groceries ($425/wk × 4.33 wks)") return "groceries";
  if (cat === "restaurants & bars") return "dining";
  if (cat === "movies / concerts / other fun") return "entertainment";
  return "misc";
}

function isDebtPayment(t: { category?: string | null; description?: string | null }) {
  const hay = `${t.category ?? ""} ${t.description ?? ""}`;
  return CARD_PAYMENT_RX.test(hay) || DEBT_PAYMENT_RX.test(hay);
}

function paceVerdict(pctSpent: number, dayOfMonth: number, daysInMonth: number) {
  const expected = (dayOfMonth / daysInMonth) * 100;
  const delta = pctSpent - expected;
  if (delta < -10) return { label: "Under pace", tone: "positive" as const };
  if (delta > 10) return { label: "Over pace", tone: "negative" as const };
  return { label: "On pace", tone: "neutral" as const };
}

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];
const AUTO_BUDGET_SECTIONS = new Set(["debt-min", "income", "avalanche"]);

function budgetKey(value?: string | null) {
  return (value ?? "").toLowerCase().trim();
}

function budgetForTaggedTransactions(
  transactions: Array<{ category?: string | null }>,
  filterFn: (t: any) => boolean,
  budgetByCategory: Map<string, number>,
) {
  const categories = new Set<string>();
  for (const t of transactions) {
    if (!filterFn(t)) continue;
    const key = budgetKey(t.category);
    if (key) categories.add(key);
  }
  let total = 0;
  for (const key of categories) total += budgetByCategory.get(key) ?? 0;
  return total;
}

/** Return the ISO date string of the Sunday starting the week containing `d`. */
function sundayOfWeek(d: Date): string {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  x.setDate(x.getDate() - x.getDay());
  return x.toISOString().slice(0, 10);
}

export default function Dashboard() {
  const realToday = useMemo(() => new Date(), []);

  // ---- Dashboard month selector ----
  const [selectedMonthIdx, setSelectedMonthIdx] = useState(realToday.getMonth());
  const [selectedYear, setSelectedYear] = useState(realToday.getFullYear());

  const goMonthBack = useCallback(() => {
    setSelectedMonthIdx((prev) => {
      if (prev === 0) { setSelectedYear((y) => y - 1); return 11; }
      return prev - 1;
    });
  }, []);
  const goMonthForward = useCallback(() => {
    setSelectedMonthIdx((prev) => {
      if (prev === 11) { setSelectedYear((y) => y + 1); return 0; }
      return prev + 1;
    });
  }, []);

  const isCurrentMonth = selectedMonthIdx === realToday.getMonth() && selectedYear === realToday.getFullYear();
  const daysInSelectedMonth = new Date(selectedYear, selectedMonthIdx + 1, 0).getDate();
  const dayOfSelectedMonth = isCurrentMonth ? realToday.getDate() : daysInSelectedMonth;

  // ---- Weekly week selector (Sun-Sat) ----
  const [selectedWeekStart, setSelectedWeekStart] = useState(() => sundayOfWeek(realToday));
  const selectedWeekEnd = addDaysISO(selectedWeekStart, 6);
  const isCurrentWeek = selectedWeekStart === sundayOfWeek(realToday);

  const goWeekBack = useCallback(() => {
    setSelectedWeekStart((prev) => addDaysISO(prev, -7));
  }, []);
  const goWeekForward = useCallback(() => {
    setSelectedWeekStart((prev) => addDaysISO(prev, 7));
  }, []);

  // ---- Data hooks ----
  const { debts: rawDebts } = useDebts();
  const { settings } = useAvalancheSettings();
  // All transactions (unfiltered) for weekly card (can span months)
  const { data: allLedger, updateTransaction: allUpdateTxn } = useLedger();
  // Month-filtered transactions for budget snapshot / monthly / unplanned
  const { data: monthLedger, updateTransaction: monthUpdateTxn } = useLedger({ month: selectedMonthIdx + 1, year: selectedYear });
  const { items: recurringItems } = useRecurring();
  const { items: reimbursableItems, toggleReimbursed } = useReimbursables();
  // Period-scoped dashboard budgets
  const monthPeriodKey = `${selectedYear}-${String(selectedMonthIdx + 1).padStart(2, "0")}`;
  const weeklyBudget = useDashboardBudget("weekly", selectedWeekStart);
  const monthlyBudget = useDashboardBudget("monthly", monthPeriodKey);
  const unplannedBudget = useDashboardBudget("unplanned", monthPeriodKey);

  const debts = useMemo(
    () => applyPaymentsToDebts(rawDebts, allLedger.transactions),
    [rawDebts, allLedger.transactions],
  );

  const budgetLines = useMemo<BudgetLine[]>(() => {
    const savedEditableRows = monthLedger.budget_lines
      .filter((r) => !AUTO_BUDGET_SECTIONS.has(r.section))
      .map((r) => ({
        id: r.id,
        section: r.section,
        label: r.label,
        budgeted: Number(r.budgeted),
        actual: 0,
        source: (r.source as BudgetLine["source"]) ?? "editable",
        notes: r.notes ?? undefined,
      }));
    const fallbackEditableRows = INITIAL_BUDGET_NO_DEBTS.filter((l) => !AUTO_BUDGET_SECTIONS.has(l.section));
    const autoRows = buildLiveBudget(debts, INITIAL_BUDGET_NO_DEBTS, recurringItems)
      .filter((l) => AUTO_BUDGET_SECTIONS.has(l.section))
      .map((l) => l.id === "a-extra" ? { ...l, budgeted: settings.manualExtra } : l);
    return [...(savedEditableRows.length ? savedEditableRows : fallbackEditableRows), ...autoRows];
  }, [debts, recurringItems, monthLedger.budget_lines, settings.manualExtra]);

  const budgetByCategory = useMemo(() => {
    const map = new Map<string, number>();
    for (const line of budgetLines) {
      if (line.section === "income") continue;
      const key = budgetKey(line.label);
      if (key) map.set(key, (map.get(key) ?? 0) + Number(line.budgeted));
      if (line.section === "debt-min") {
        const noPct = budgetKey(line.label.replace(/\s*\([^)]*%\)\s*$/, ""));
        if (noPct) map.set(noPct, (map.get(noPct) ?? 0) + Number(line.budgeted));
      }
    }
    return map;
  }, [budgetLines]);

  const isMonthlyBucketTxn = useCallback(
    (t: any) => !!t.monthly_allowance && t.type === "expense" && accountOf(t.source) === "amex",
    [],
  );
  const isUnplannedBucketTxn = useCallback(
    (t: any) => !!t.unplanned_allowance && t.type === "expense" && accountOf(t.source) === "amex",
    [],
  );

  const monthlyCategoryBudget = useMemo(
    () => budgetForTaggedTransactions(monthLedger.transactions, isMonthlyBucketTxn, budgetByCategory),
    [monthLedger.transactions, isMonthlyBucketTxn, budgetByCategory],
  );
  const unplannedCategoryBudget = useMemo(
    () => budgetForTaggedTransactions(monthLedger.transactions, isUnplannedBucketTxn, budgetByCategory),
    [monthLedger.transactions, isUnplannedBucketTxn, budgetByCategory],
  );
  const monthlyBudgetTotal = monthlyBudget.savedAmount != null && monthlyBudget.savedAmount > 0 ? monthlyBudget.savedAmount : monthlyCategoryBudget;
  const unplannedBudgetTotal = unplannedBudget.savedAmount != null && unplannedBudget.savedAmount > 0 ? unplannedBudget.savedAmount : unplannedCategoryBudget;

  // ---- Avalanche projection ----
  const selectedPeriodDate = useMemo(
    () => new Date(selectedYear, selectedMonthIdx, dayOfSelectedMonth),
    [selectedYear, selectedMonthIdx, dayOfSelectedMonth],
  );
  const actuals = useActualsMTD(debts, selectedPeriodDate);
  const sourceAmount = useMemo(
    () => resolveExtra(settings, actuals.avalancheActual),
    [settings, actuals.avalancheActual],
  );
  const effectiveExtra = Math.max(0, sourceAmount);

  const sim = useMemo(
    () => simulate({ debts, extraPerMonth: effectiveExtra, strategy: settings.strategy }),
    [debts, effectiveExtra, settings.strategy],
  );

  const totalOwed = useMemo(
    () => debts.filter((d) => d.status === "active" && d.balance > 0).reduce((s, d) => s + d.balance, 0),
    [debts],
  );
  const activeCount = debts.filter((d) => d.status === "active" && d.balance > 0).length;

  const nextTargets = useMemo(() => {
    const killById = new Map(sim.killedOrder.map((k) => [k.id, k.date]));
    const active = debts.filter((d) => d.status === "active" && d.balance > 0);
    const sorted = [...active].sort((a, b) =>
      settings.strategy === "avalanche"
        ? b.apr - a.apr || a.balance - b.balance
        : a.balance - b.balance || b.apr - a.apr,
    );
    return sorted.slice(0, 3).map((d, i) => ({
      rank: i + 1,
      id: d.id,
      creditor: d.creditor,
      apr: d.apr,
      balance: d.balance,
      minPayment: d.minPayment,
      killDate: killById.get(d.id) ?? null,
    }));
  }, [sim.killedOrder, debts, settings.strategy]);

  // ---- This-week expenses (last 7 days from today for the bottom card) ----
  const week = useMemo(() => {
    const from = addDays(realToday, -6);
    const fromISO = fmtISO(from);
    const toISO = fmtISO(realToday);

    type Item = { id: string; date: string; description: string; amount: number; account: "Bank" | "Amex" };
    const items: Item[] = [];
    let bank = 0, amex = 0;

    for (const t of allLedger.transactions) {
      if (t.date < fromISO || t.date > toISO) continue;
      if (t.type === "transfer" || t.type === "income") continue;
      if (isDebtPayment(t)) continue;
      const account: "Bank" | "Amex" = accountOf(t.source) === "amex" ? "Amex" : "Bank";
      const amt = Math.abs(Number(t.amount));
      if (account === "Amex") amex += amt; else bank += amt;
      items.push({
        id: t.id,
        date: t.date,
        description: t.description || t.category || "(no description)",
        amount: amt,
        account,
      });
    }
    items.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    return { items, bank, amex, total: bank + amex, count: items.length };
  }, [allLedger.transactions, realToday]);

  // ---- Budget snapshot (uses selected month) ----
  const budgetSnapshot = useMemo(() => {
    const actualsByCategory = new Map<string, number>();
    let incomeReceived = 0;
    for (const t of monthLedger.transactions) {
      if (t.type === "transfer") continue;
      if (t.type === "income") {
        incomeReceived += Number(t.amount);
        continue;
      }
      const key = (t.category ?? "").toLowerCase().trim();
      if (!key) continue;
      actualsByCategory.set(key, (actualsByCategory.get(key) ?? 0) + Math.abs(Number(t.amount)));
    }

    let incomeBudget = 0, expenseBudget = 0, expenseActual = 0;
    for (const l of budgetLines) {
      if (l.section === "income") {
        incomeBudget += l.budgeted;
      } else {
        expenseBudget += l.budgeted;
        const labelKey = l.label.toLowerCase().trim();
        let actual = actualsByCategory.get(labelKey) ?? 0;
        if (!actual && l.section === "debt-min") {
          const noPct = l.label.replace(/\s*\([^)]*%\)\s*$/, "").toLowerCase().trim();
          actual = actualsByCategory.get(noPct) ?? 0;
        }
        expenseActual += actual;
      }
    }

    const pctSpent = expenseBudget > 0 ? (expenseActual / expenseBudget) * 100 : 0;
    const remaining = Math.max(0, expenseBudget - expenseActual);
    const verdict = paceVerdict(pctSpent, dayOfSelectedMonth, daysInSelectedMonth);

    const debtPaid = actuals.debtMinsPaid + actuals.debtExtraPaid;
    const netActual = incomeReceived - expenseActual - debtPaid;

    return {
      incomeBudget, incomeReceived, expenseBudget, expenseActual,
      pctSpent, remaining, verdict, net: netActual,
    };
  }, [budgetLines, monthLedger.transactions, dayOfSelectedMonth, daysInSelectedMonth, actuals.debtMinsPaid, actuals.debtExtraPaid]);

  const todayLabel = `${DAY_NAMES[realToday.getDay()]} · ${MONTH_NAMES[realToday.getMonth()]} ${realToday.getDate()}, ${realToday.getFullYear()}`;


  return (
    <div className="mx-auto max-w-6xl px-6 md:px-10 py-8 bg-warm-gradient">
      {/* Masthead */}
      <div className="relative rounded-3xl bg-card border border-border p-6 md:p-8 mb-8 shadow-[0_8px_30px_-12px_hsl(22_92%_56%/0.25)] overflow-hidden">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-accent/15 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-10 h-48 w-48 rounded-full bg-secondary/20 blur-2xl pointer-events-none" />
        <div className="relative flex items-center justify-between gap-4 flex-wrap">
          <img
            src={h2Logo}
            alt="H2"
            className="h-28 md:h-36 w-auto object-contain drop-shadow-md"
          />
          <span className="text-[11px] uppercase tracking-[0.25em] text-accent font-semibold bg-accent/10 px-3 py-1.5 rounded-full">
            {todayLabel}
          </span>
        </div>
      </div>

      {/* Dashboard month navigator */}
      <div className="flex items-center justify-center gap-3 mb-6">
        <Button variant="outline" size="icon" onClick={goMonthBack} className="rounded-full">
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="font-display text-xl font-semibold w-48 text-center">
          {MONTH_NAMES[selectedMonthIdx]} {selectedYear}
        </div>
        <Button variant="outline" size="icon" onClick={goMonthForward} className="rounded-full">
          <ChevronRight className="h-4 w-4" />
        </Button>
        {!isCurrentMonth && (
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-accent"
            onClick={() => { setSelectedMonthIdx(realToday.getMonth()); setSelectedYear(realToday.getFullYear()); }}
          >
            Today
          </Button>
        )}
      </div>

      {/* Headline strip */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border-y border-foreground/30 mb-10">
        <Headline
          label="Total Owed"
          value={fmtMoney(totalOwed)}
          sub={`${activeCount} active debt${activeCount === 1 ? "" : "s"}`}
        />
        <Headline
          label={`Net ${MONTH_NAMES[selectedMonthIdx]}`}
          value={fmtMoney(budgetSnapshot.net)}
          sub={budgetSnapshot.net >= 0 ? "received − spent − debt paid" : "shortfall"}
          tone={budgetSnapshot.net >= 0 ? "positive" : "negative"}
          last
        />
      </div>

      {/* Month vs Budget */}
      <section className="mb-10">
        <div className="flex items-baseline justify-between gap-4">
          <SectionTitle kicker="Budget" title={`${MONTH_NAMES[selectedMonthIdx]} vs plan`} />
          <Link to="/budget" className="text-[10px] uppercase tracking-widest text-accent hover:underline">
            Open budget →
          </Link>
        </div>

        <div className="border border-border bg-card rounded-2xl mt-4 p-6">
          <div className="flex items-baseline justify-between mb-2">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Spent</div>
            <div className="font-mono-num text-sm tabular">
              {fmtMoney(budgetSnapshot.expenseActual)} of {fmtMoney(budgetSnapshot.expenseBudget)}
            </div>
          </div>
          <div className="h-3 bg-secondary border border-border overflow-hidden">
            <div
              className={cn(
                "h-full transition-all",
                budgetSnapshot.pctSpent > 100 ? "bg-destructive" : "bg-accent",
              )}
              style={{ width: `${Math.min(100, budgetSnapshot.pctSpent)}%` }}
            />
          </div>
          <div className="flex items-baseline justify-between mt-2 text-xs text-muted-foreground">
            <span>{Math.round(budgetSnapshot.pctSpent)}% used · day {dayOfSelectedMonth} of {daysInSelectedMonth}</span>
            <span
              className={cn(
                "font-display uppercase tracking-widest",
                budgetSnapshot.verdict.tone === "positive" && "text-positive",
                budgetSnapshot.verdict.tone === "negative" && "text-destructive",
              )}
            >
              {budgetSnapshot.verdict.label}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 pt-6 border-t border-border">
            <div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
                Income received
              </div>
              <div className="font-display text-2xl font-bold tabular">
                {fmtMoney(budgetSnapshot.incomeReceived)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                of {fmtMoney(budgetSnapshot.incomeBudget)} budgeted
              </div>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
                Left to spend
              </div>
              <div className="font-display text-2xl font-bold tabular text-accent">
                {fmtMoney(budgetSnapshot.remaining)}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                across the rest of {MONTH_NAMES[selectedMonthIdx]}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Your next 3 moves */}
      <section className="mb-10">
        <div className="flex items-baseline justify-between gap-4">
          <SectionTitle
            kicker={settings.strategy === "snowball" ? "Snowball Plan · Kill Order" : "Avalanche Plan · Kill Order"}
            title="Your next 3 moves"
          />
          <Link to="/avalanche" className="text-[10px] uppercase tracking-widest text-accent hover:underline">
            See full order →
          </Link>
        </div>

        {nextTargets.length === 0 ? (
          <p className="text-muted-foreground text-sm mt-4">
            No active debts. Add some on the avalanche board.
          </p>
        ) : (
          <div className="grid md:grid-cols-3 gap-4 mt-4">
            {nextTargets.map((t, i) => (
              <div
                key={t.id}
                className={cn(
                  "border bg-card p-5",
                  i === 0 ? "border-foreground" : "border-border",
                )}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div
                    className={cn(
                      "h-6 w-6 inline-flex items-center justify-center text-[10px] font-bold border",
                      i === 0 ? "bg-foreground text-background border-foreground" : "border-border",
                    )}
                  >
                    #{t.rank}
                  </div>
                  <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    {t.killDate ? `Pay off by ${fmtMonth(t.killDate)}` : "In the queue"}
                  </span>
                </div>
                <div className="font-display text-lg font-semibold leading-tight mb-1 truncate">
                  {t.creditor}
                </div>
                <div className="text-xs text-muted-foreground mb-3 tabular">
                  {(t.apr * 100).toFixed(2)}% APR · {fmtMoney(t.balance)} balance
                </div>
                <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                  Frees up
                </div>
                <div className="font-display text-2xl font-bold text-positive">
                  {fmtMoney(t.minPayment)}
                  <span className="text-xs text-muted-foreground font-normal">/mo</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Weekly allowance tracker — with week navigation */}
      <WeeklyAmexCard
        transactions={allLedger.transactions}
        weekStart={selectedWeekStart}
        weekEnd={selectedWeekEnd}
        weeklyTotal={weeklyBudget.savedAmount ?? 425}
        isCurrentWeek={isCurrentWeek}
        onWeekBack={goWeekBack}
        onWeekForward={goWeekForward}
        onGoToCurrentWeek={() => setSelectedWeekStart(sundayOfWeek(realToday))}
        onBudgetChange={(v) => weeklyBudget.save(v)}
        realToday={realToday}
      />

      {/* Monthly spending tracker — scoped to selected month */}
      <BucketCard
        title="Monthly spending"
        kicker="Monthly Budget"
        transactions={monthLedger.transactions}
        budgetTotal={monthlyBudgetTotal}
        onBudgetChange={(v) => monthlyBudget.save(v)}
        filterFn={isMonthlyBucketTxn}
        periodLabel={`${MONTH_NAMES[selectedMonthIdx]} ${selectedYear}`}
        dayProgress={`day ${dayOfSelectedMonth} of ${daysInSelectedMonth}`}
      />

      {/* Unplanned spending tracker — scoped to selected month */}
      <BucketCard
        title="Unplanned spending"
        kicker="Unplanned Budget"
        transactions={monthLedger.transactions}
        budgetTotal={unplannedBudgetTotal}
        onBudgetChange={(v) => unplannedBudget.save(v)}
        filterFn={isUnplannedBucketTxn}
        periodLabel={`${MONTH_NAMES[selectedMonthIdx]} ${selectedYear}`}
        dayProgress={`day ${dayOfSelectedMonth} of ${daysInSelectedMonth}`}
      />

      {/* Reimbursables tracker */}
      <ReimbursablesCard
        items={reimbursableItems}
        onToggleReimbursed={(id, reimbursed) => {
          toggleReimbursed.mutate({ id, reimbursed });
        }}
      />

      {/* This week purchases — bottom of dashboard */}
      <section className="mb-10">
        <div className="flex items-baseline justify-between gap-4">
          <SectionTitle kicker="This Week" title="Purchases" />
          <div className="flex items-baseline gap-4">
            <Link to="/banking" className="text-[10px] uppercase tracking-widest text-accent hover:underline">
              Banking →
            </Link>
            <Link to="/amex" className="text-[10px] uppercase tracking-widest text-accent hover:underline">
              Amex →
            </Link>
          </div>
        </div>

        <div className="mt-4 border border-border bg-card rounded-2xl">
          <div className="grid grid-cols-3 divide-x divide-border border-b border-border">
            <WeekStat label="Bank" value={week.bank} />
            <WeekStat label="Amex" value={week.amex} />
            <WeekStat label="Total" value={week.total} accent />
          </div>
          <div className="px-5 py-2 text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border bg-secondary/30">
            {week.count} {week.count === 1 ? "expense" : "expenses"} · last 7 days · debt payments excluded
          </div>

          {week.items.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-muted-foreground">
              No expenses in the last 7 days.
            </p>
          ) : (
            <ul className="divide-y divide-border max-h-[28rem] overflow-y-auto">
              {week.items.map((it) => {
                const d = new Date(it.date + "T00:00:00");
                const dateLabel = `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getDate()}`;
                return (
                  <li
                    key={it.id}
                    className="group flex items-center gap-4 px-5 py-3 hover:bg-secondary/40 transition-colors"
                  >
                    <div className="w-12 text-[10px] uppercase tracking-[0.2em] text-muted-foreground shrink-0 font-display">
                      {dateLabel}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate leading-tight">
                        {it.description}
                      </div>
                    </div>
                    <span
                      className={cn(
                        "text-[9px] uppercase tracking-[0.18em] px-2 py-0.5 border shrink-0 rounded-sm",
                        it.account === "Amex"
                          ? "border-accent/40 text-accent bg-accent/5"
                          : "border-border text-muted-foreground bg-secondary/40",
                      )}
                    >
                      {it.account}
                    </span>
                    <div className="font-mono-num tabular text-sm shrink-0 w-24 text-right text-foreground">
                      −{fmtMoney(it.amount)}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

function WeekStat({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return (
    <div className="px-5 py-4">
      <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-1">{label}</div>
      <div
        className={cn(
          "font-display font-bold tabular leading-none",
          accent ? "text-2xl text-accent" : "text-xl text-foreground",
        )}
      >
        {fmtMoney(value)}
      </div>
    </div>
  );
}

function Headline({
  label, value, sub, tone, last,
}: {
  label: string; value: string; sub: string;
  tone?: "negative" | "accent" | "positive"; last?: boolean;
}) {
  const color =
    tone === "accent" ? "text-accent" :
    tone === "positive" ? "text-positive" :
    tone === "negative" ? "text-destructive" :
    "text-foreground";
  return (
    <div className={`px-6 py-6 ${!last ? "md:border-r border-border" : ""}`}>
      <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground mb-2">{label}</div>
      <div className={`font-display text-3xl md:text-4xl font-bold leading-none tabular ${color}`}>{value}</div>
      <div className="text-xs text-muted-foreground mt-2">{sub}</div>
    </div>
  );
}

function SectionTitle({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-[0.25em] text-accent">{kicker}</div>
      <h2 className="font-display text-2xl font-semibold mt-1">{title}</h2>
    </div>
  );
}

const CAT_LABELS: Record<"groceries" | "dining" | "entertainment" | "misc", string> = {
  groceries: "Groceries",
  dining: "Dining",
  entertainment: "Entertainment",
  misc: "Misc",
};

function WeeklyAmexCard({
  transactions,
  weekStart,
  weekEnd,
  weeklyTotal,
  isCurrentWeek,
  onWeekBack,
  onWeekForward,
  onGoToCurrentWeek,
  onBudgetChange,
  realToday,
}: {
  transactions: Array<{
    id: string;
    date: string;
    description: string;
    amount: number;
    type: string;
    category?: string | null;
    source: string;
    weekly_allowance?: boolean;
  }>;
  weekStart: string;
  weekEnd: string;
  weeklyTotal: number;
  isCurrentWeek: boolean;
  onWeekBack: () => void;
  onWeekForward: () => void;
  onGoToCurrentWeek: () => void;
  onBudgetChange: (v: number) => void;
  realToday: Date;
}) {
  const summary = useMemo(() => {
    const buckets = { groceries: 0, dining: 0, entertainment: 0, misc: 0 };
    const counts = { groceries: 0, dining: 0, entertainment: 0, misc: 0 };
    const matched: Array<{ id: string; date: string; description: string; amount: number; bucket: keyof typeof buckets }> = [];
    for (const t of transactions) {
      if (t.type !== "expense") continue;
      if (accountOf(t.source) !== "amex") continue;
      if (t.date < weekStart || t.date > weekEnd) continue;
      const bucket = classifyWeekly(t);
      if (!bucket) continue;
      const amt = Math.abs(Number(t.amount));
      buckets[bucket] += amt;
      counts[bucket] += 1;
      matched.push({ id: t.id, date: t.date, description: t.description, amount: amt, bucket });
    }
    matched.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    const total = buckets.groceries + buckets.dining + buckets.entertainment + buckets.misc;
    return { buckets, counts, matched, total };
  }, [transactions, weekStart, weekEnd]);

  const pct = weeklyTotal > 0 ? (summary.total / weeklyTotal) * 100 : 0;
  const remaining = weeklyTotal - summary.total;
  const overBudget = summary.total > weeklyTotal;

  // Day index within the 7-day window
  const todayISO = realToday.toISOString().slice(0, 10);
  const startMs = new Date(weekStart + "T00:00:00").getTime();
  const todayMs = new Date(todayISO + "T00:00:00").getTime();
  const dayInWeek = isCurrentWeek
    ? Math.min(7, Math.max(1, Math.floor((todayMs - startMs) / 86400000) + 1))
    : 7; // Past weeks are fully elapsed

  const fmtRange = (a: string, b: string) => {
    const [, am, ad] = a.split("-").map(Number);
    const [, bm, bd] = b.split("-").map(Number);
    const monStr = (m: number) => MONTH_NAMES[m - 1].slice(0, 3);
    if (am === bm) return `${monStr(am)} ${ad} – ${bd}`;
    return `${monStr(am)} ${ad} – ${monStr(bm)} ${bd}`;
  };

  return (
    <section className="mb-10">
      <div className="flex items-baseline justify-between gap-4">
        <SectionTitle kicker={`Weekly ${fmtMoney(weeklyTotal)}`} title="Life this week" />
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={onWeekBack} className="h-7 w-7 rounded-full">
            <ChevronLeft className="h-3.5 w-3.5" />
          </Button>
          <span className="text-[10px] uppercase tracking-widest text-muted-foreground min-w-[110px] text-center">
            {fmtRange(weekStart, weekEnd)}
          </span>
          <Button variant="outline" size="icon" onClick={onWeekForward} className="h-7 w-7 rounded-full">
            <ChevronRight className="h-3.5 w-3.5" />
          </Button>
          {!isCurrentWeek && (
            <Button variant="ghost" size="sm" className="text-xs text-accent h-7" onClick={onGoToCurrentWeek}>
              This week
            </Button>
          )}
        </div>
      </div>

      <div className="mt-4 border border-border bg-card rounded-2xl p-6">
        {/* Headline */}
        <div className="flex items-baseline justify-between mb-2 flex-wrap gap-2">
          <div className="font-display text-3xl font-bold tabular">
            <span className={cn(overBudget && "text-destructive")}>{fmtMoney(summary.total)}</span>
            <span className="text-muted-foreground text-xl"> / </span>
              <EditableBudget value={weeklyTotal} onChange={onBudgetChange} className="text-muted-foreground text-xl" />
          </div>
          <div className="text-xs text-muted-foreground">
            {overBudget
              ? `Over by ${fmtMoney(Math.abs(remaining))}`
              : `${fmtMoney(remaining)} left`} · day {dayInWeek} of 7
          </div>
        </div>
        <div className="h-3 bg-secondary border border-border overflow-hidden">
          <div
            className={cn(
              "h-full transition-all",
              overBudget ? "bg-destructive" : "bg-accent",
            )}
            style={{ width: `${Math.min(100, pct)}%` }}
          />
        </div>

        {/* Breakdown */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-border">
          {(["groceries", "dining", "entertainment", "misc"] as const).map((k) => (
            <div key={k}>
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-1">
                {CAT_LABELS[k]}
              </div>
              <div className="font-display text-lg font-semibold tabular">
                {fmtMoney(summary.buckets[k])}
              </div>
              {summary.counts[k] > 0 && (
                <div className="text-[10px] text-muted-foreground mt-0.5">
                  {summary.counts[k]} {summary.counts[k] === 1 ? "item" : "items"}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Recent contributing charges */}
        {summary.matched.length > 0 && (
          <div className="mt-5 pt-4 border-t border-border">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
              Recent ({summary.matched.length})
            </div>
            <ul className="divide-y divide-border max-h-[20rem] overflow-y-auto">
              {summary.matched.map((m) => {
                const d = new Date(m.date + "T00:00:00");
                const dateLabel = `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getDate()}`;
                return (
                  <li key={m.id} className="flex items-center gap-3 py-2 text-sm">
                    <span className="w-12 text-[10px] uppercase tracking-[0.2em] text-muted-foreground shrink-0 font-display">
                      {dateLabel}
                    </span>
                    <span className="flex-1 truncate">{m.description}</span>
                    <span className="text-[9px] uppercase tracking-[0.18em] px-2 py-0.5 border border-border text-muted-foreground bg-secondary/40 rounded-sm shrink-0">
                      {CAT_LABELS[m.bucket]}
                    </span>
                    <span className="font-mono-num tabular text-sm w-20 text-right shrink-0">
                      −{fmtMoney(m.amount)}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        )}

        {/* Footer */}
        <div className="mt-5 pt-4 border-t border-border flex items-center justify-between gap-3 flex-wrap">
          <div className="text-xs text-muted-foreground">
            Tag any other Amex charge as "weekly" on the <Link to="/amex" className="text-accent hover:underline">Amex page</Link> to add it to Misc.
          </div>
        </div>
      </div>
    </section>
  );
}

function EditableBudget({ value, onChange, className }: { value: number; onChange: (v: number) => void; className?: string }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(value));

  if (editing) {
    return (
      <input
        type="number"
        className={cn("bg-transparent border-b border-accent outline-none w-24 font-display font-bold tabular", className)}
        value={draft}
        autoFocus
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => {
          const n = Number(draft);
          if (n > 0) onChange(n);
          setEditing(false);
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            const n = Number(draft);
            if (n > 0) onChange(n);
            setEditing(false);
          }
          if (e.key === "Escape") setEditing(false);
        }}
      />
    );
  }
  return (
    <button
      onClick={() => { setDraft(String(value)); setEditing(true); }}
      className={cn("hover:text-accent transition-colors cursor-pointer font-display font-bold tabular", className)}
      title="Click to edit budget"
    >
      {fmtMoney(value)}
    </button>
  );
}

function BucketCard({
  title,
  kicker,
  transactions,
  budgetTotal,
  onBudgetChange,
  filterFn,
  periodLabel,
  dayProgress,
}: {
  title: string;
  kicker: string;
  transactions: Array<{
    id: string;
    date: string;
    description: string;
    amount: number;
    type: string;
    category?: string | null;
    source: string;
    monthly_allowance?: boolean;
    unplanned_allowance?: boolean;
  }>;
  budgetTotal: number;
  onBudgetChange: (v: number) => void;
  filterFn: (t: any) => boolean;
  periodLabel: string;
  dayProgress: string;
}) {
  const summary = useMemo(() => {
    const matched: Array<{ id: string; date: string; description: string; amount: number }> = [];
    let total = 0;
    for (const t of transactions) {
      if (!filterFn(t)) continue;
      const amt = Math.abs(Number(t.amount));
      total += amt;
      matched.push({ id: t.id, date: t.date, description: t.description || t.category || "(no description)", amount: amt });
    }
    matched.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    return { total, matched };
  }, [transactions, filterFn]);

  const pct = budgetTotal > 0 ? (summary.total / budgetTotal) * 100 : 0;
  const remaining = budgetTotal - summary.total;
  const overBudget = budgetTotal > 0 && summary.total > budgetTotal;
  const noBudgetSet = budgetTotal <= 0;

  return (
    <section className="mb-10">
      <div className="flex items-baseline justify-between gap-4">
        <SectionTitle kicker={kicker} title={title} />
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          {periodLabel}
        </span>
      </div>

      <div className="mt-4 border border-border bg-card rounded-2xl p-6">
        <div className="flex items-baseline justify-between mb-2 flex-wrap gap-2">
          <div className="font-display text-3xl font-bold tabular">
            <span className={cn(overBudget && "text-destructive")}>{fmtMoney(summary.total)}</span>
            <span className="text-muted-foreground text-xl"> / </span>
            <EditableBudget value={budgetTotal} onChange={onBudgetChange} className="text-muted-foreground text-xl" />
          </div>
          <div className="text-xs text-muted-foreground">
            {noBudgetSet
              ? "Click budget to set amount"
              : overBudget
                ? `Over by ${fmtMoney(Math.abs(remaining))}`
                : `${fmtMoney(remaining)} left`} · {dayProgress}
          </div>
        </div>
        {!noBudgetSet && (
          <div className="h-3 bg-secondary border border-border overflow-hidden">
            <div
              className={cn("h-full transition-all", overBudget ? "bg-destructive" : "bg-accent")}
              style={{ width: `${Math.min(100, pct)}%` }}
            />
          </div>
        )}

        {summary.matched.length > 0 && (
          <div className="mt-5 pt-4 border-t border-border">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
              Recent ({summary.matched.length})
            </div>
            <ul className="divide-y divide-border max-h-[20rem] overflow-y-auto">
              {summary.matched.map((m) => {
                const d = new Date(m.date + "T00:00:00");
                const dateLabel = `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getDate()}`;
                return (
                  <li key={m.id} className="flex items-center gap-3 py-2 text-sm">
                    <span className="w-12 text-[10px] uppercase tracking-[0.2em] text-muted-foreground shrink-0 font-display">
                      {dateLabel}
                    </span>
                    <span className="flex-1 truncate">{m.description}</span>
                    <span className="font-mono-num tabular text-sm w-20 text-right shrink-0">
                      −{fmtMoney(m.amount)}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        )}

        {summary.matched.length === 0 && (
          <div className="mt-4 text-sm text-muted-foreground text-center py-4">
            No transactions tagged yet. Tag charges on the <Link to="/amex" className="text-accent hover:underline">Amex page</Link>.
          </div>
        )}
      </div>
    </section>
  );
}

function ReimbursablesCard({
  items: rawItems,
  onToggleReimbursed,
}: {
  items: Array<{
    id: string;
    date: string;
    description: string;
    amount: number;
    source: string;
    reimbursed: boolean;
  }>;
  onToggleReimbursed: (id: string, reimbursed: boolean) => void;
}) {
  const items = useMemo(() => {
    return rawItems
      .map((t) => ({
        id: t.id,
        date: t.date,
        description: t.description || "(no description)",
        amount: Math.abs(Number(t.amount)),
        reimbursed: !!t.reimbursed,
      }))
      .sort((a, b) => {
        if (a.reimbursed !== b.reimbursed) return a.reimbursed ? 1 : -1;
        return a.date < b.date ? 1 : a.date > b.date ? -1 : 0;
      });
  }, [rawItems]);

  const pending = items.filter((i) => !i.reimbursed);
  const received = items.filter((i) => i.reimbursed);
  const pendingTotal = pending.reduce((s, i) => s + i.amount, 0);
  const receivedTotal = received.reduce((s, i) => s + i.amount, 0);

  return (
    <section className="mb-10">
      <div className="flex items-baseline justify-between gap-4">
        <SectionTitle kicker="Reimbursables" title="Pending reimbursements" />
      </div>

      <div className="mt-4 border border-purple-200 bg-card rounded-2xl p-5">
        <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
          <div className="font-display text-2xl font-bold tabular text-purple-600">
            {fmtMoney(pendingTotal)}
            <span className="text-sm text-muted-foreground font-normal ml-2">
              pending · {pending.length} {pending.length === 1 ? "item" : "items"}
            </span>
          </div>
          {receivedTotal > 0 && (
            <div className="text-xs text-positive">
              ✓ {fmtMoney(receivedTotal)} reimbursed
            </div>
          )}
        </div>

        {items.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-6">
            No reimbursable items yet. Tag charges as reimbursable on the{" "}
            <Link to="/amex" className="text-accent hover:underline">Amex page</Link>.
          </div>
        ) : (
          <div className="max-h-[320px] overflow-y-auto">
            <ul className="divide-y divide-border">
              {items.map((item) => {
                const d = new Date(item.date + "T00:00:00");
                const dateLabel = `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getDate()}`;
                return (
                  <li key={item.id} className={cn("flex items-center gap-3 py-2 text-sm", item.reimbursed && "opacity-50")}>
                    <Checkbox
                      checked={item.reimbursed}
                      onCheckedChange={() => onToggleReimbursed(item.id, !item.reimbursed)}
                      className="border-purple-400 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500 shrink-0"
                      aria-label={item.reimbursed ? "Mark as not reimbursed" : "Mark as reimbursed"}
                    />
                    <span className="w-12 text-[10px] uppercase tracking-[0.2em] text-muted-foreground shrink-0 font-display">
                      {dateLabel}
                    </span>
                    <span className={cn("flex-1 truncate", item.reimbursed && "line-through")}>{item.description}</span>
                    <span className={cn("font-mono-num tabular text-sm w-20 text-right shrink-0", item.reimbursed && "line-through")}>
                      {fmtMoney(item.amount)}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </div>
    </section>
  );
}
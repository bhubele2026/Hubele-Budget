import { forwardRef, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { toast } from "@/hooks/use-toast";
import {
  Flame,
  Plus,
  Pencil,
  X,
  Check,
  ChevronDown,
  TrendingDown,
  AlertTriangle,
  Sparkles,
  ClipboardPaste,
  CloudOff,
} from "lucide-react";
import { useDebts } from "@/hooks/useDebts";
import { useAvalancheSettings } from "@/hooks/useAvalancheSettings";
import { useLedger } from "@/hooks/useLedger";
import {
  simulate,
  monthsIfMinOnly,
  interestIfMinOnly,
  dailyInterest,
  fmtMoney,
  fmtMoneyCompact,
  fmtMonth,
  fmtPct,
} from "@/lib/avalanche";
import {
  FALLBACK_DEBTS,
  parsePastedDebts,
  type Debt,
  type ExtraSource,
  type Strategy,
} from "@/lib/debtData";
import { buildBudgetSnapshot } from "@/lib/budgetSnapshot";
import { useActualsMTD } from "@/hooks/useActualsMTD";
import { useRecurring } from "@/hooks/useRecurring";
import { resolveExtra } from "@/lib/extraSource";
import {
  applyPaymentsToDebts,
  isBalanceStale,
  type AppliedDebt,
} from "@/lib/appliedBalance";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { DebtPlaidLinkButton, SyncAllDebtBalancesButton } from "@/components/DebtPlaidLink";

export default function Avalanche() {
  const { debts: dbDebts, isLoading, error: debtsError, refetch: refetchDebts, updateDebt, recordBalance, addDebt, deleteDebt, setStatus } = useDebts();
  const { settings, update: updateSettings, error: settingsError, refetch: refetchSettings } = useAvalancheSettings();
  const backendError = debtsError ?? settingsError;

  // Local fallback so the board never gets stranded if the backend is briefly down.
  // We also let users paste their own list as a hard escape hatch.
  const [localDebts, setLocalDebts] = useState<Debt[] | null>(null);
  const [showPaste, setShowPaste] = useState(false);

  // Decide which dataset drives the page:
  // 1. If user pasted local debts → use those.
  // 2. Else if backend returned debts → use those.
  // 3. Else if backend errored AND we have nothing → use the bundled fallback.
  const usingFallback = !localDebts && (dbDebts?.length ?? 0) === 0 && !!backendError;
  const rawDebts: Debt[] = localDebts
    ?? (dbDebts.length > 0 ? dbDebts : usingFallback ? FALLBACK_DEBTS : []);

  // Pull the full transaction history once so we can subtract any payments
  // made since each debt's last_balance_update from its stored balance. The
  // simulator + totals + queue all run against the *applied* balance — the
  // last known statement minus payments since.
  const { data: ledger } = useLedger();
  const debts: AppliedDebt[] = useMemo(
    () => applyPaymentsToDebts(rawDebts, ledger.transactions),
    [rawDebts, ledger.transactions],
  );

  const [showAllMonths, setShowAllMonths] = useState(false);
  const [adding, setAdding] = useState(false);

  const { items: recurringItems, update: updateRecurring } = useRecurring();
  const budget = useMemo(
    () => buildBudgetSnapshot(debts, recurringItems, settings.manualExtra),
    [debts, recurringItems, settings.manualExtra],
  );

  const actuals = useActualsMTD(debts);
  const effectiveExtra = useMemo(
    () => resolveExtra(settings, actuals.avalancheActual),
    [settings, actuals.avalancheActual],
  );

  const sim = useMemo(
    () => simulate({ debts, extraPerMonth: effectiveExtra, strategy: settings.strategy }),
    [debts, effectiveExtra, settings.strategy],
  );

  // Companion sim for the strategy comparison chip.
  const otherSim = useMemo(
    () => simulate({
      debts,
      extraPerMonth: effectiveExtra,
      strategy: settings.strategy === "avalanche" ? "snowball" : "avalanche",
    }),
    [debts, effectiveExtra, settings.strategy],
  );
  const interestDelta = otherSim.totalInterestPaid - sim.totalInterestPaid;

  const activeDebts = debts.filter((d) => d.status === "active");
  const paidOffDebts = debts.filter((d) => d.status === "paid_off");
  const targetDebt = sim.months[0]?.activeTargetId
    ? debts.find((d) => d.id === sim.months[0].activeTargetId) ?? null
    : null;

  const totalDebtNow = activeDebts.reduce((s, d) => s + d.balance, 0);
  const totalMinNow = activeDebts.reduce((s, d) => s + d.minPayment, 0);

  // Map debt id → kill info from the simulation
  const killById = useMemo(() => {
    const m = new Map<string, { date: Date; monthIndex: number }>();
    for (const k of sim.killedOrder) m.set(k.id, { date: k.date, monthIndex: k.monthIndex });
    return m;
  }, [sim]);

  // "Next moves" follows the active strategy: top targets in the same order
  // as the Debt queue (highest APR for avalanche, smallest balance for snowball).
  const next3 = useMemo(() => {
    return sortDebts(activeDebts, settings.strategy)
      .slice(0, 3)
      .map((d) => {
        const k = killById.get(d.id);
        return {
          id: d.id,
          creditor: d.creditor,
          apr: d.apr,
          balance: d.balance,
          minFreed: d.minPayment,
          date: k?.date ?? null,
        };
      });
  }, [activeDebts, settings.strategy, killById]);

  const handleSave = async (id: string, patch: Partial<Debt>) => {
    try {
      await updateDebt.mutateAsync({ id, ...patch });
      // When due day changes, also update the linked recurring item's day_of_month
      if (patch.dueDay !== undefined) {
        const linked = recurringItems.find(
          (it) => it.kind === "debt_min" && it.linked_debt_id === id
        );
        if (linked) {
          updateRecurring.mutate({ id: linked.id, day_of_month: patch.dueDay });
        }
      }
    } catch (e) {
      toast({ title: "Couldn't save", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleAdd = async (input: Omit<Debt, "id" | "sortOrder">) => {
    try {
      await addDebt.mutateAsync(input);
      setAdding(false);
      toast({ title: "Debt added" });
    } catch (e) {
      toast({ title: "Couldn't add debt", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleMarkPaid = async (id: string) => {
    try {
      await setStatus.mutateAsync({ id, status: "paid_off" });
      toast({ title: "🎉 Debt killed", description: "Freed minimum cascades to the next target." });
    } catch (e) {
      toast({ title: "Couldn't update", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleReactivate = async (id: string) => {
    try {
      await setStatus.mutateAsync({ id, status: "active" });
    } catch (e) {
      toast({ title: "Couldn't update", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleDelete = async (id: string, creditor: string) => {
    if (!confirm(`Delete "${creditor}"? This can't be undone.`)) return;
    try {
      await deleteDebt.mutateAsync(id);
      toast({ title: "Debt removed" });
    } catch (e) {
      toast({ title: "Couldn't delete", description: (e as Error).message, variant: "destructive" });
    }
  };

  const handleRecordBalance = async (
    id: string,
    balance: number,
    asOf: Date,
  ) => {
    try {
      await recordBalance.mutateAsync({ id, balance, asOf });
      toast({
        title: "Balance updated",
        description: `Recorded ${fmtMoney(balance)} as of ${format(asOf, "MMM d")}.`,
      });
    } catch (e) {
      toast({
        title: "Couldn't update balance",
        description: (e as Error).message,
        variant: "destructive",
      });
    }
  };

  return (
    <TooltipProvider delayDuration={150}>
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-8">
        {/* Header */}
        <div className="border-b-2 border-foreground pb-4 mb-6 flex items-end justify-between gap-4 flex-wrap">
          <div>
            <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
              Section II
            </div>
            <h1 className="font-display text-5xl font-bold leading-none mt-1">Avalanche</h1>
            <p className="font-display italic text-muted-foreground mt-2">
              Pay the highest interest first. Watch the snowball cascade.
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2" onClick={() => setShowPaste((s) => !s)}>
              <ClipboardPaste className="h-4 w-4" /> Paste debts
            </Button>
            <Button className="gap-2" onClick={() => setAdding(true)}>
              <Plus className="h-4 w-4" /> Add debt
            </Button>
          </div>
        </div>

        {isLoading && !backendError && debts.length === 0 && (
          <div className="text-sm text-muted-foreground mb-4">Loading your debts…</div>
        )}

        {backendError && (
          <div className="mb-6 border border-destructive/40 bg-destructive/5 p-4 flex items-start justify-between gap-4 flex-wrap">
            <div className="flex items-start gap-3 min-w-0">
              <CloudOff className="h-4 w-4 mt-0.5 text-destructive shrink-0" />
              <div className="min-w-0">
                <div className="font-display font-semibold text-sm mb-1">
                  {usingFallback
                    ? "Showing the local debt plan"
                    : localDebts
                      ? "Working offline — your pasted list is loaded"
                      : "Cloud sync is reconnecting"}
                </div>
                <div className="text-xs text-muted-foreground">
                  {usingFallback
                    ? "The backend is briefly unavailable, so we loaded the 25 starter debts. Edits won't save until cloud sync is back."
                    : "Your data is loaded. Edits won't save to the cloud until the connection returns."}
                </div>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                refetchDebts();
                refetchSettings();
              }}
            >
              Retry sync
            </Button>
          </div>
        )}

        {showPaste && (
          <PasteDebtsPanel
            onApply={(parsed) => {
              setLocalDebts(parsed);
              setShowPaste(false);
              toast({ title: `Loaded ${parsed.length} debts locally` });
            }}
            onCancel={() => setShowPaste(false)}
          />
        )}


        {/* HERO STRIP */}
        <div className="grid grid-cols-2 md:grid-cols-4 border-y border-foreground/30 mb-6">
          <Stat label="Total debt" value={fmtMoneyCompact(totalDebtNow)} />
          <Stat
            label="Months to free"
            value={sim.ranOutOfTime ? "∞" : String(sim.monthsToFreedom)}
            sub={sim.ranOutOfTime ? "raise the extra" : `${(sim.monthsToFreedom / 12).toFixed(1)} yrs`}
          />
          <Stat
            label="Debt-free date"
            value={sim.debtFreeDate ? fmtMonth(sim.debtFreeDate) : "—"}
          />
          <Stat
            label="Total interest"
            value={fmtMoneyCompact(sim.totalInterestPaid)}
            tone="negative"
            last
          />
        </div>

        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex items-baseline justify-between text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
            <span>Progress</span>
            <span className="font-mono-num">
              {fmtPct(
                sim.startingTotalBalance > 0
                  ? 1 - totalDebtNow / sim.startingTotalBalance
                  : 0,
                1,
              )}
            </span>
          </div>
          <div className="h-2 w-full bg-secondary overflow-hidden">
            <div
              className="h-full bg-foreground transition-all"
              style={{
                width: `${
                  sim.startingTotalBalance > 0
                    ? Math.max(0, Math.min(100, (1 - totalDebtNow / sim.startingTotalBalance) * 100))
                    : 0
                }%`,
              }}
            />
          </div>
        </div>

        {/* CONTROL PANEL */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Extra payment source */}
          <div className="border border-border bg-card rounded-2xl p-5">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
              Extra per month
            </div>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="font-display text-4xl font-bold tabular">
                {fmtMoney(effectiveExtra)}
              </span>
              <span className="text-xs text-muted-foreground">/mo</span>
            </div>

            {settings.budgetMode === "actual" ? (
              <div>
                <div className="text-[11px] text-muted-foreground mb-2">
                  Sum of this month's transactions categorized as{" "}
                  <span className="font-mono-num text-foreground">Avalanche extra</span>.
                  Tag transactions on the Banking page to update this number.
                </div>
                <div className="text-[11px] text-muted-foreground">
                  Budgeted target:{" "}
                  <span className="font-mono-num text-foreground">{fmtMoney(settings.manualExtra)}</span>
                  {actuals.avalancheActual < settings.manualExtra ? (
                    <> · short by {fmtMoney(settings.manualExtra - actuals.avalancheActual)}</>
                  ) : actuals.avalancheActual > settings.manualExtra ? (
                    <> · ahead by <span className="text-positive">{fmtMoney(actuals.avalancheActual - settings.manualExtra)}</span></>
                  ) : null}
                </div>
              </div>
            ) : (
              /* Avalanche budget slider — writes to settings.manual_extra,
                 the same value as the Budget page's "Avalanche extra" row.
                 Drag here = edit the budget. */
              <div>
                <div className="flex items-baseline justify-between mb-2">
                  <label className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    Avalanche budget
                  </label>
                  <span className="font-mono-num text-sm font-semibold">
                    {fmtMoney(settings.manualExtra)}
                    <span className="text-muted-foreground font-normal">/mo</span>
                  </span>
                </div>
                <Slider
                  value={[settings.manualExtra]}
                  min={0}
                  max={Math.max(2000, settings.manualExtra + 500, Math.round(budget.income))}
                  step={25}
                  onValueChange={(v) =>
                    updateSettings.mutate({ manualExtra: v[0] })
                  }
                />
                {(() => {
                  const remaining = budget.income - (budget.expenses - settings.manualExtra);
                  const over = settings.manualExtra > remaining;
                  if (over) {
                    return (
                      <div className="mt-2 text-[11px] text-negative flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        Over budget by {fmtMoney(settings.manualExtra - Math.max(0, remaining))} — cut spending or income won't cover it.
                      </div>
                    );
                  }
                  return (
                    <div className="mt-2 text-[11px] text-muted-foreground">
                      Room left in budget: <span className="font-mono-num text-foreground">{fmtMoney(Math.max(0, remaining - settings.manualExtra))}</span>
                    </div>
                  );
                })()}
                {settings.manualExtra > 0 && (
                  <button
                    onClick={() => updateSettings.mutate({ manualExtra: 0 })}
                    className="text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground mt-2"
                  >
                    Reset to $0
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Strategy + mode */}
          <div className="border border-border bg-card rounded-2xl p-5">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
              Strategy
            </div>
            <div className="grid grid-cols-2 gap-1 mb-4 p-1 bg-secondary border border-border rounded-2xl">
              <StrategyPill
                active={settings.strategy === "avalanche"}
                onClick={() => updateSettings.mutate({ strategy: "avalanche" })}
                label="Avalanche"
                sub="Highest APR first"
              />
              <StrategyPill
                active={settings.strategy === "snowball"}
                onClick={() => updateSettings.mutate({ strategy: "snowball" })}
                label="Snowball"
                sub="Smallest balance first"
              />
            </div>
            <div className="text-xs text-muted-foreground mb-5">
              {interestDelta > 0 ? (
                <>
                  <Sparkles className="inline h-3 w-3 mr-1 text-positive" />
                  Sticking with{" "}
                  <strong className="text-foreground">{settings.strategy}</strong> saves you{" "}
                  <strong className="text-positive">{fmtMoney(interestDelta)}</strong> vs the other
                  strategy.
                </>
              ) : interestDelta < 0 ? (
                <>
                  Switching to{" "}
                  <strong className="text-foreground">
                    {settings.strategy === "avalanche" ? "snowball" : "avalanche"}
                  </strong>{" "}
                  would save{" "}
                  <strong className="text-positive">{fmtMoney(-interestDelta)}</strong> in interest.
                </>
              ) : (
                <>Both strategies cost the same in interest right now.</>
              )}
            </div>

            <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
              Mode
            </div>
            <div className="grid grid-cols-2 gap-1 p-1 bg-secondary border border-border rounded-2xl">
              <StrategyPill
                active={settings.budgetMode === "budgeted"}
                onClick={() => updateSettings.mutate({ budgetMode: "budgeted" })}
                label="Budgeted"
                sub="Plan numbers"
              />
              <StrategyPill
                active={settings.budgetMode === "actual"}
                onClick={() => updateSettings.mutate({ budgetMode: "actual" })}
                label="Actual"
                sub="From transactions"
              />
            </div>
            <p className="text-[11px] text-muted-foreground mt-3">
              {settings.budgetMode === "actual" ? (
                <>
                  Live month-to-date: income {fmtMoneyCompact(actuals.incomeReceived)} ·
                  expenses {fmtMoneyCompact(actuals.expenseActual)} · debt mins {fmtMoneyCompact(actuals.debtMinsPaid)} ·
                  extra paid {fmtMoneyCompact(actuals.debtExtraPaid)}.
                </>
              ) : (
                <>Plan numbers from your Budget. Switch to Actual to drive the plan from real transactions this month.</>
              )}
            </p>
          </div>
        </div>

        {/* NEXT 3 MOVES */}
        {next3.length > 0 && (
          <div className="mb-8">
            <h2 className="font-display text-xl font-semibold mb-3 flex items-baseline gap-3">
              Your next 3 moves
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                kill order
              </span>
            </h2>
            <div className="grid md:grid-cols-3 gap-4">
              {next3.map((k, i) => (
                <div
                  key={k.id}
                  className={cn(
                    "border bg-card p-5",
                    i === 0 ? "border-foreground" : "border-border",
                  )}
                >
                  <div className="flex items-center gap-2 mb-3">
                    <div
                      className={cn(
                        "h-6 w-6 inline-flex items-center justify-center text-[10px] font-bold border",
                        i === 0 ? "bg-foreground text-background border-foreground" : "border-border",
                      )}
                    >
                      #{i + 1}
                    </div>
                    <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                      {k.date ? `Pay off by ${fmtMonth(k.date)}` : "In the queue"}
                    </span>
                  </div>
                  <div className="font-display text-lg font-semibold leading-tight mb-1 truncate">
                    {k.creditor}
                  </div>
                  <div className="text-xs text-muted-foreground mb-3">
                    {fmtPct(k.apr, 2)} APR · {fmtMoney(k.balance)} balance
                  </div>
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                    Frees up
                  </div>
                  <div className="font-display text-2xl font-bold text-positive">
                    {fmtMoney(k.minFreed)}
                    <span className="text-xs text-muted-foreground font-normal">/mo</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* DEBT QUEUE TABLE */}
        <div className="mb-8">
          <div className="flex items-baseline justify-between mb-3 flex-wrap gap-2">
            <div className="flex items-center gap-3">
              <h2 className="font-display text-xl font-semibold">
                Debt queue{" "}
                <span className="text-sm text-muted-foreground font-normal">
                  ({activeDebts.length} active · {paidOffDebts.length} killed)
                </span>
              </h2>
              <SyncAllDebtBalancesButton />
            </div>
            <div className="text-xs text-muted-foreground">
              Sorted by {settings.strategy === "avalanche" ? "highest APR" : "smallest balance"} ·
              click any value to edit
            </div>
          </div>

          <div className="border border-border bg-card rounded-2xl overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border bg-secondary/40">
                  <th className="text-left py-3 px-3 w-10">#</th>
                  <th className="text-left py-3 px-3">Creditor</th>
                  <th className="text-right py-3 px-3 w-24">APR</th>
                  <th className="text-right py-3 px-3 w-32">Balance</th>
                  <th className="text-right py-3 px-3 w-28">Min/mo</th>
                  <th className="text-right py-3 px-3 w-20">Due</th>
                  <th className="text-right py-3 px-3 w-28 hidden lg:table-cell">Daily int.</th>
                  <th className="text-right py-3 px-3 w-32 hidden lg:table-cell">Min-only</th>
                  <th className="text-right py-3 px-3 w-32">Killed</th>
                  <th className="text-right py-3 px-3 w-20"></th>
                </tr>
              </thead>
              <tbody>
                {sortDebts(activeDebts, settings.strategy).map((d, i) => (
                  <DebtRow
                    key={d.id}
                    d={d}
                    rank={i + 1}
                    isTarget={d.id === targetDebt?.id}
                    kill={killById.get(d.id) ?? null}
                    onSave={(patch) => handleSave(d.id, patch)}
                    onMarkPaid={() => handleMarkPaid(d.id)}
                    onDelete={() => handleDelete(d.id, d.creditor)}
                    onRecordBalance={(balance, asOf) =>
                      handleRecordBalance(d.id, balance, asOf)
                    }
                  />
                ))}
                {paidOffDebts.length > 0 && (
                  <tr className="border-t border-border bg-secondary/20">
                    <td colSpan={10} className="py-2 px-3 text-[10px] uppercase tracking-widest text-muted-foreground">
                      Killed debts
                    </td>
                  </tr>
                )}
                {paidOffDebts.map((d) => (
                  <tr key={d.id} className="border-b border-border last:border-b-0 opacity-60">
                    <td className="py-3 px-3"></td>
                    <td className="py-3 px-3 line-through truncate">{d.creditor}</td>
                    <td className="py-3 px-3 text-right font-mono-num">{fmtPct(d.apr, 2)}</td>
                    <td className="py-3 px-3 text-right font-mono-num">{fmtMoney(d.balance)}</td>
                    <td className="py-3 px-3 text-right font-mono-num">{fmtMoney(d.minPayment)}</td>
                    <td className="py-3 px-3 text-right font-mono-num text-muted-foreground">{d.dueDay || "—"}</td>
                    <td className="hidden lg:table-cell"></td>
                    <td className="hidden lg:table-cell"></td>
                    <td className="py-3 px-3 text-right">
                      <span className="text-[10px] uppercase tracking-widest text-positive">
                        ✓ Paid
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleReactivate(d.id)}
                        className="text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground"
                      >
                        Restore
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-foreground">
                  <td colSpan={3} className="py-3 px-3 text-[10px] uppercase tracking-widest text-muted-foreground">
                    Active totals
                  </td>
                  <td className="py-3 px-3 text-right font-display text-lg font-bold tabular">
                    {fmtMoney(totalDebtNow)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono-num font-semibold">
                    {fmtMoney(totalMinNow)}
                  </td>
                  <td colSpan={5}></td>
                </tr>
              </tfoot>
            </table>
          </div>

          {adding && (
            <AddDebtForm onSave={handleAdd} onCancel={() => setAdding(false)} />
          )}
        </div>

        {/* PAYOFF TIMELINE */}
        {sim.killedOrder.length > 0 && (
          <div className="mb-8">
            <h2 className="font-display text-xl font-semibold mb-3">Payoff timeline</h2>
            <div className="border border-border bg-card rounded-2xl p-5 space-y-2">
              {sim.killedOrder.map((k) => {
                const maxMonths = sim.killedOrder[sim.killedOrder.length - 1].monthIndex;
                const widthPct = (k.monthIndex / maxMonths) * 100;
                const heat = aprHeat(k.apr);
                return (
                  <div key={k.id} className="flex items-center gap-3 text-xs">
                    <div className="w-44 truncate text-right text-muted-foreground">
                      {k.creditor}
                    </div>
                    <div className="flex-1 relative h-6 bg-secondary">
                      <div
                        className="h-full transition-all"
                        style={{ width: `${widthPct}%`, background: heat }}
                      />
                      <span className="absolute inset-0 flex items-center px-2 font-mono-num text-[10px]">
                        Mo {k.monthIndex} · {fmtMonth(k.date)}
                      </span>
                    </div>
                    <div className="w-20 text-right font-mono-num text-muted-foreground">
                      {fmtPct(k.apr, 2)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* SNOWBALL FREEDOM PANEL */}
        <div className="border border-border bg-card rounded-2xl p-5 mb-8 flex items-center gap-4 flex-wrap">
          <TrendingDown className="h-6 w-6 text-positive" />
          <div className="flex-1 min-w-[260px]">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
              When all debts die
            </div>
            <div className="text-sm">
              You'll have{" "}
              <span className="font-display text-2xl font-bold text-positive">
                {fmtMoney(totalMinNow + effectiveExtra)}/mo
              </span>{" "}
              back in your budget.
            </div>
          </div>
          {sim.debtFreeDate && (
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
                Freedom date
              </div>
              <div className="font-display text-2xl font-bold">
                {fmtMonth(sim.debtFreeDate)}
              </div>
            </div>
          )}
        </div>

        {/* MONTH-BY-MONTH */}
        {sim.months.length > 0 && (
          <div className="mb-8">
            <button
              onClick={() => setShowAllMonths((s) => !s)}
              className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground hover:text-foreground mb-3"
            >
              <ChevronDown className={cn("h-3 w-3 transition-transform", !showAllMonths && "-rotate-90")} />
              Month-by-month projection ({sim.months.length} months)
            </button>
            {showAllMonths && (
              <div className="border border-border bg-card rounded-2xl overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border bg-secondary/40">
                      <th className="text-left py-2 px-3">Mo</th>
                      <th className="text-left py-2 px-3">Date</th>
                      <th className="text-right py-2 px-3">Interest</th>
                      <th className="text-right py-2 px-3">Mins paid</th>
                      <th className="text-right py-2 px-3">Extra paid</th>
                      <th className="text-left py-2 px-3">Active target</th>
                      <th className="text-right py-2 px-3">Balance end</th>
                      <th className="text-right py-2 px-3">% Done</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sim.months.map((m) => (
                      <tr key={m.monthIndex} className="border-b border-border last:border-b-0 hover:bg-secondary/30">
                        <td className="py-2 px-3 font-mono-num text-muted-foreground">{m.monthIndex}</td>
                        <td className="py-2 px-3">{fmtMonth(m.date)}</td>
                        <td className="py-2 px-3 text-right font-mono-num text-negative">{fmtMoneyCompact(m.totalInterest)}</td>
                        <td className="py-2 px-3 text-right font-mono-num">{fmtMoneyCompact(m.totalMinsPaid)}</td>
                        <td className="py-2 px-3 text-right font-mono-num text-accent">{fmtMoneyCompact(m.totalExtraPaid)}</td>
                        <td className="py-2 px-3 truncate max-w-[200px] text-muted-foreground">{m.activeTargetCreditor ?? "—"}</td>
                        <td className="py-2 px-3 text-right font-mono-num font-semibold">{fmtMoneyCompact(m.totalBalanceEnd)}</td>
                        <td className="py-2 px-3 text-right font-mono-num">{fmtPct(m.pctPaidOff, 1)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {sim.ranOutOfTime && (
          <div className="border border-negative bg-card p-4 mb-8 flex items-start gap-3 text-sm">
            <AlertTriangle className="h-4 w-4 text-negative shrink-0 mt-0.5" />
            <div>
              The simulation hit its 600-month cap without finishing. One or more debts have
              minimum payments below the monthly interest. Increase the extra/month or raise
              the affected minimums to make progress.
            </div>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}

function sortDebts(debts: Debt[], strat: Strategy): Debt[] {
  const arr = [...debts];
  if (strat === "avalanche") {
    arr.sort((a, b) => b.apr - a.apr || a.balance - b.balance);
  } else {
    arr.sort((a, b) => a.balance - b.balance || b.apr - a.apr);
  }
  return arr;
}

function aprHeat(apr: number): string {
  // 0% = cool blue, 35%+ = hot red. HSL within design tokens — using raw hue for the bar fill.
  const t = Math.max(0, Math.min(1, apr / 0.35));
  const h = 200 - 200 * t; // 200 → 0 (blue → red)
  return `hsl(${h.toFixed(0)} 70% 45%)`;
}

function Stat({
  label,
  value,
  sub,
  tone,
  last,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: "positive" | "negative";
  last?: boolean;
}) {
  const color =
    tone === "positive" ? "text-positive"
      : tone === "negative" ? "text-negative"
        : "text-foreground";
  return (
    <div className={cn("px-5 py-5", !last && "md:border-r border-border")}>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">
        {label}
      </div>
      <div className={cn("font-display text-3xl font-bold tabular", color)}>{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}

const SourcePill = forwardRef<
  HTMLButtonElement,
  {
    active: boolean;
    onClick: () => void;
    label: string;
    value: string;
  }
>(function SourcePill({ active, onClick, label, value }, ref) {
  return (
    <button
      ref={ref}
      onClick={onClick}
      className={cn(
        "px-2 py-2 text-left transition-colors",
        active ? "bg-foreground text-background" : "hover:bg-card",
      )}
    >
      <div className="text-[9px] uppercase tracking-widest opacity-80">{label}</div>
      <div className="font-mono-num text-sm font-semibold">{value}</div>
    </button>
  );
});

const StrategyPill = forwardRef<
  HTMLButtonElement,
  {
    active: boolean;
    onClick: () => void;
    label: string;
    sub: string;
  }
>(function StrategyPill({ active, onClick, label, sub }, ref) {
  return (
    <button
      ref={ref}
      onClick={onClick}
      className={cn(
        "px-4 py-2 text-left transition-colors rounded-xl",
        active ? "bg-foreground text-background" : "hover:bg-card",
      )}
    >
      <div className="font-display font-semibold text-sm">{label}</div>
      <div className="text-[10px] uppercase tracking-wider opacity-80">{sub}</div>
    </button>
  );
});

function DebtRow({
  d,
  rank,
  isTarget,
  kill,
  onSave,
  onMarkPaid,
  onDelete,
  onRecordBalance,
}: {
  d: AppliedDebt | Debt;
  rank: number;
  isTarget: boolean;
  kill: { date: Date; monthIndex: number } | null;
  onSave: (patch: Partial<Debt>) => void;
  onMarkPaid: () => void;
  onDelete: () => void;
  onRecordBalance?: (balance: number, asOf: Date) => void;
}) {
  const minMonths = monthsIfMinOnly(d);
  const minInterest = interestIfMinOnly(d);
  const daily = dailyInterest(d);
  const minDoesntCover = minMonths === null && d.balance > 0;

  // Applied-balance bookkeeping (only present when the page passed an
  // AppliedDebt). The "stored" balance is the last statement / manual entry,
  // and `balance` here is already the applied (post-payment) value.
  const applied = (d as AppliedDebt).appliedBalance !== undefined
    ? (d as AppliedDebt)
    : null;
  const stale = isBalanceStale(d);

  return (
    <tr
      className={cn(
        "group border-b border-border last:border-b-0 hover:bg-secondary/30 transition-colors",
        isTarget && "bg-accent/5",
      )}
    >
      <td className="py-3 px-3 font-display font-bold text-muted-foreground">
        {isTarget ? <Flame className="h-4 w-4 text-accent inline" /> : rank}
      </td>
      <td className="py-3 px-3">
        <EditableText
          value={d.creditor}
          onSave={(v) => onSave({ creditor: v })}
          className="font-medium"
        />
        {minDoesntCover && (
          <div className="text-[10px] text-negative flex items-center gap-1 mt-0.5">
            <AlertTriangle className="h-3 w-3" />
            Min doesn't cover interest
          </div>
        )}
      </td>
      <td className="py-3 px-3 text-right">
        <EditableNumber
          value={d.apr * 100}
          suffix="%"
          decimals={2}
          onSave={(v) => onSave({ apr: v / 100 })}
          className={cn("font-mono-num", isTarget && "text-accent font-semibold")}
        />
      </td>
      <td className="py-3 px-3 text-right">
        {/* Balance cell: applied (post-payment) value is what the simulator
            uses, shown in bold. Underneath, we expose the last known
            statement balance the payments were subtracted from. */}
        <div className="flex flex-col items-end gap-0.5">
          <span className="font-mono-num font-semibold tabular">
            {fmtMoney(d.balance)}
          </span>
          {applied && applied.paymentsApplied > 0 && (
            <Tooltip>
              <TooltipTrigger asChild>
                <span className="text-[10px] text-muted-foreground tabular cursor-help">
                  was {fmtMoney(applied.appliedBalance + applied.paymentsApplied)} · −{fmtMoney(applied.paymentsApplied)} pmts
                </span>
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                Last known statement balance was{" "}
                <strong>{fmtMoney(applied.appliedBalance + applied.paymentsApplied)}</strong>
                {applied.daysSinceUpdate !== null
                  ? ` (set ${applied.daysSinceUpdate}d ago)`
                  : " (never set — using a 35-day window)"}
                . We've matched{" "}
                <strong>{fmtMoney(applied.paymentsApplied)}</strong> in payments
                from your transactions since then. New charges aren't tracked —
                upload a fresh statement to recalibrate.
              </TooltipContent>
            </Tooltip>
          )}
          {onRecordBalance && (
            <UpdateBalancePopover
              currentBalance={d.balance}
              stale={stale}
              onRecord={onRecordBalance}
            />
          )}
        </div>
      </td>
      <td className="py-3 px-3 text-right">
        <EditableNumber
          value={d.minPayment}
          prefix="$"
          decimals={2}
          onSave={(v) => onSave({ minPayment: v })}
          className="font-mono-num"
        />
      </td>
      <td className="py-3 px-3 text-right">
        <EditableNumber
          value={d.dueDay ?? 0}
          suffix=""
          decimals={0}
          onSave={(v) => onSave({ dueDay: Math.max(1, Math.min(31, Math.round(v))) })}
          className="font-mono-num"
          placeholder="—"
        />
      </td>
      <td className="py-3 px-3 text-right font-mono-num text-muted-foreground hidden lg:table-cell">
        {fmtMoney(daily)}
      </td>
      <td className="py-3 px-3 text-right font-mono-num text-muted-foreground hidden lg:table-cell">
        {minMonths === null ? "∞" : `${minMonths} mo`}
        {minInterest !== null && (
          <div className="text-[10px] text-negative">
            +{fmtMoneyCompact(minInterest)} int.
          </div>
        )}
      </td>
      <td className="py-3 px-3 text-right">
        {kill ? (
          <div>
            <div className="font-mono-num text-xs">{fmtMonth(kill.date)}</div>
            <div className="text-[10px] text-muted-foreground">Mo {kill.monthIndex}</div>
          </div>
        ) : (
          <span className="text-muted-foreground text-xs">—</span>
        )}
      </td>
      <td className="py-3 px-3 text-right">
        <div className="flex justify-end items-center gap-1 opacity-60 group-hover:opacity-100 transition-opacity">
          <DebtPlaidLinkButton debt={d} />
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onMarkPaid}
                className="h-7 w-7 inline-flex items-center justify-center text-positive hover:bg-secondary"
                aria-label="Mark paid off"
              >
                <Check className="h-4 w-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Mark paid off</TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onDelete}
                className="h-7 w-7 inline-flex items-center justify-center text-muted-foreground hover:text-negative hover:bg-secondary"
                aria-label="Delete debt"
              >
                <X className="h-4 w-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>Delete</TooltipContent>
          </Tooltip>
        </div>
      </td>
    </tr>
  );
}

function UpdateBalancePopover({
  currentBalance,
  stale,
  onRecord,
}: {
  currentBalance: number;
  stale: boolean;
  onRecord: (balance: number, asOf: Date) => void;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(currentBalance.toFixed(2));
  const [asOf, setAsOf] = useState<Date>(new Date());

  const submit = () => {
    const n = parseFloat(draft.replace(/[^0-9.\-]/g, ""));
    if (isNaN(n) || n < 0) return;
    onRecord(n, asOf);
    setOpen(false);
  };

  return (
    <Popover
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (v) {
          setDraft(currentBalance.toFixed(2));
          setAsOf(new Date());
        }
      }}
    >
      <PopoverTrigger asChild>
        <button
          className={cn(
            "text-[10px] uppercase tracking-widest hover:text-accent transition-colors flex items-center gap-1",
            stale ? "text-amber-500" : "text-muted-foreground",
          )}
          aria-label="Record statement balance"
        >
          {stale && <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />}
          Update
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 p-3 space-y-3">
        <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
          Record statement balance
        </div>
        <div>
          <label className="text-xs text-muted-foreground">New balance ($)</label>
          <Input
            autoFocus
            type="text"
            inputMode="decimal"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit();
            }}
            className="mt-1 font-mono-num"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Statement date</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full mt-1 justify-start text-left font-normal"
              >
                <CalendarIcon className="mr-2 h-4 w-4 opacity-60" />
                {format(asOf, "PPP")}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={asOf}
                onSelect={(d) => d && setAsOf(d)}
                disabled={(d) => d > new Date()}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>
        <div className="flex justify-end gap-2 pt-1">
          <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button size="sm" onClick={submit}>Save</Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

function EditableText({
  value,
  onSave,
  className,
}: {
  value: string;
  onSave: (v: string) => void;
  className?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);

  if (!editing) {
    return (
      <button
        onClick={() => { setDraft(value); setEditing(true); }}
        className={cn("text-left hover:text-accent transition-colors inline-flex items-center gap-1.5 max-w-full", className)}
      >
        <span className="truncate">{value}</span>
        <Pencil className="h-3 w-3 opacity-0 hover:opacity-60 shrink-0" />
      </button>
    );
  }
  const commit = () => {
    setEditing(false);
    if (draft.trim() && draft !== value) onSave(draft.trim());
  };
  return (
    <Input
      autoFocus
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") setEditing(false);
      }}
      className="h-8 text-sm"
    />
  );
}

function EditableNumber({
  value,
  prefix = "",
  suffix = "",
  decimals = 2,
  onSave,
  className,
  placeholder,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  onSave: (v: number) => void;
  className?: string;
  placeholder?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(String(value));

  if (!editing) {
    const display = placeholder && value === 0
      ? placeholder
      : prefix === "$"
        ? fmtMoney(value)
        : `${prefix}${value.toFixed(decimals)}${suffix}`;
    return (
      <button
        onClick={() => { setDraft(value.toFixed(decimals)); setEditing(true); }}
        className={cn("hover:text-accent transition-colors", className)}
      >
        {display}
      </button>
    );
  }
  const commit = () => {
    setEditing(false);
    const n = parseFloat(draft.replace(/[^0-9.\-]/g, ""));
    if (!isNaN(n) && n !== value) onSave(n);
  };
  return (
    <Input
      autoFocus
      value={draft}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === "Enter") commit();
        if (e.key === "Escape") setEditing(false);
      }}
      className={cn("h-8 text-right font-mono-num", className)}
    />
  );
}

function AddDebtForm({
  onSave,
  onCancel,
}: {
  onSave: (input: Omit<Debt, "id" | "sortOrder">) => void;
  onCancel: () => void;
}) {
  const [creditor, setCreditor] = useState("");
  const [apr, setApr] = useState("");
  const [balance, setBalance] = useState("");
  const [minPayment, setMinPayment] = useState("");

  const submit = () => {
    if (!creditor.trim()) return;
    onSave({
      creditor: creditor.trim(),
      apr: (parseFloat(apr) || 0) / 100,
      balance: parseFloat(balance) || 0,
      minPayment: parseFloat(minPayment) || 0,
      status: "active",
    });
  };

  return (
    <div className="border border-foreground bg-card p-5 mt-4">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-3">
        Add a debt
      </div>
      <div className="grid md:grid-cols-[2fr,1fr,1fr,1fr,auto] gap-3 items-end">
        <div>
          <label className="text-[10px] uppercase tracking-widest text-muted-foreground">Creditor</label>
          <Input value={creditor} onChange={(e) => setCreditor(e.target.value)} placeholder="e.g. Chase Sapphire" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-muted-foreground">APR %</label>
          <Input value={apr} onChange={(e) => setApr(e.target.value)} placeholder="22.99" inputMode="decimal" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-muted-foreground">Balance</label>
          <Input value={balance} onChange={(e) => setBalance(e.target.value)} placeholder="1500.00" inputMode="decimal" />
        </div>
        <div>
          <label className="text-[10px] uppercase tracking-widest text-muted-foreground">Min/mo</label>
          <Input value={minPayment} onChange={(e) => setMinPayment(e.target.value)} placeholder="50.00" inputMode="decimal" />
        </div>
        <div className="flex gap-2">
          <Button onClick={submit} className="gap-1"><Check className="h-4 w-4" /> Add</Button>
          <Button onClick={onCancel} variant="outline">Cancel</Button>
        </div>
      </div>
    </div>
  );
}

function PasteDebtsPanel({
  onApply,
  onCancel,
}: {
  onApply: (debts: Debt[]) => void;
  onCancel: () => void;
}) {
  const [text, setText] = useState("");
  const parsed = useMemo(() => (text.trim() ? parsePastedDebts(text) : []), [text]);
  const ok = parsed.filter((p) => p.ok) as Extract<typeof parsed[number], { ok: true }>[];
  const errors = parsed.filter((p) => !p.ok) as Extract<typeof parsed[number], { ok: false }>[];

  const apply = () => {
    if (ok.length === 0) return;
    const debts: Debt[] = ok.map((row, i) => ({
      id: `local-${i + 1}`,
      sortOrder: i + 1,
      ...row.debt,
    }));
    onApply(debts);
  };

  return (
    <div className="border-2 border-foreground bg-card p-5 mb-6">
      <div className="flex items-baseline justify-between mb-3 gap-3 flex-wrap">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">
            Paste your debts
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            One per line: <span className="font-mono-num">Creditor, APR, Balance, Min</span>.
            Tabs, commas, or Excel paste all work. APR can be 28.74% or 0.2874.
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={apply} disabled={ok.length === 0} className="gap-1">
            <Check className="h-4 w-4" /> Use {ok.length || ""} debts
          </Button>
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
        </div>
      </div>
      <Textarea
        rows={8}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder={`Capital One Platinum, 28.74%, 5339.94, 200\nDiscover, 27.99%, 2349.00, 80`}
        className="font-mono-num text-xs"
      />
      {parsed.length > 0 && (
        <div className="mt-3 text-xs">
          <div className="text-muted-foreground">
            {ok.length} ready · {errors.length} need attention
          </div>
          {errors.slice(0, 5).map((e, i) => (
            <div key={i} className="text-destructive mt-1">
              <span className="font-mono-num">"{e.line}"</span> — {e.error}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

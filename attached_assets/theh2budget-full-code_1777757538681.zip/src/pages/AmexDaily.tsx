import { useMemo, useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandInput, CommandList, CommandGroup, CommandItem } from "@/components/ui/command";
import { Plus, Search, Upload, Trash2, ChevronLeft, ChevronRight, Check, ChevronsUpDown } from "lucide-react";
import PlaidConnect from "@/components/PlaidConnect";
import PlaidSync from "@/components/PlaidSync";
import { toast } from "sonner";
import { useLedger } from "@/hooks/useLedger";
import { useDebts } from "@/hooks/useDebts";
import { INITIAL_BUDGET_NO_DEBTS, fmtMoney } from "@/lib/budgetData";
import { parseBankPaste, inferType, type ParsedRow } from "@/lib/bankParser";
import { suggestCategory, buildMatchNote } from "@/lib/ruleEngine";
import type { Transaction, TxType } from "@/lib/ledgerTypes";
import { cn } from "@/lib/utils";
import { isDuplicate } from "@/lib/duplicateDetect";
import { readFileAsText } from "@/lib/fileImport";

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const TYPE_OPTIONS: TxType[] = ["expense","income","transfer"];

export default function AmexDaily() {
  const today = new Date();
  const [year, setYear] = useState(2026);
  const [monthIdx, setMonthIdx] = useState(3); // April default to show seeded data
  const { data, isLoading, addTransaction, updateTransaction, deleteTransaction, importBatch } =
    useLedger({ month: monthIdx + 1, year, account: "amex" });
  const { data: allAmex } = useLedger({ account: "amex" });
  const { debts } = useDebts();
  const tableScrollRef = useRef<HTMLDivElement>(null);

  const captureScroll = () => {
    const table = tableScrollRef.current;
    const tableTop = table?.scrollTop ?? 0;
    const tableLeft = table?.scrollLeft ?? 0;
    const pageX = window.scrollX;
    const pageY = window.scrollY;

    return () => {
      if (table) {
        table.scrollTop = tableTop;
        table.scrollLeft = tableLeft;
      }
      window.scrollTo(pageX, pageY);
    };
  };

  const updateTxnPreservingScroll = (id: string, patch: Partial<Transaction>) => {
    const restore = captureScroll();
    updateTransaction.mutate(
      { id, ...patch },
      {
        onSettled: () => {
          restore();
          requestAnimationFrame(restore);
          window.setTimeout(restore, 250);
        },
      },
    );
    requestAnimationFrame(restore);
  };

  const categoryOptions = useMemo(() => {
    const fromBudget = INITIAL_BUDGET_NO_DEBTS.map((b) => b.label);
    const fromDebts = debts.map((d) => d.creditor);
    return Array.from(new Set([...fromBudget, ...fromDebts])).sort();
  }, [debts]);

  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<"all" | TxType>("all");
  const [memberFilter, setMemberFilter] = useState<string>("all");

  const members = useMemo(() => {
    const s = new Set<string>();
    for (const t of data.transactions) if (t.member) s.add(t.member);
    return Array.from(s).sort();
  }, [data.transactions]);

  const filtered = useMemo(() => {
    return data.transactions.filter((t) => {
      if (typeFilter !== "all" && t.type !== typeFilter) return false;
      if (memberFilter !== "all" && t.member !== memberFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!t.description.toLowerCase().includes(q) && !(t.category ?? "").toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [data.transactions, search, typeFilter, memberFilter]);

  // Compute carry-forward balance from all Amex transactions before this month
  const carryForward = useMemo(() => {
    const PRE_TRACKING_BALANCE = -3354.16;
    const monthStart = `${year}-${String(monthIdx + 1).padStart(2, "0")}-01`;
    let prior = PRE_TRACKING_BALANCE;
    for (const t of allAmex.transactions) {
      if (t.date >= monthStart) break; // sorted ascending
      const a = Math.abs(Number(t.amount));
      if (t.type === "expense") prior += a;
      else prior -= a;
    }
    return prior;
  }, [allAmex.transactions, year, monthIdx]);

  // Compute running balances client-side (credit card: charges increase balance, payments decrease)
  const runningBalances = useMemo(() => {
    const map = new Map<string, number>();
    let balance = carryForward;
    for (const t of data.transactions) {
      const a = Math.abs(Number(t.amount));
      if (t.type === "expense") balance += a;
      else balance -= a;
      map.set(t.id, balance);
    }
    return map;
  }, [data.transactions, carryForward]);

  // Credit-card period totals (charges = expenses, payments+credits = transfer+income)
  const totals = useMemo(() => {
    let charges = 0, credits = 0;
    for (const t of data.transactions) {
      const a = Math.abs(Number(t.amount));
      if (t.type === "expense") charges += a;
      else credits += a; // transfer payments + statement credits
    }
    return { charges, credits, net: charges - credits };
  }, [data.transactions]);

  return (
    <div className="mx-auto max-w-7xl px-6 md:px-10 py-8">
      <div className="border-b-2 border-foreground pb-4 mb-6 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">Section III · Amex</div>
          <h1 className="font-display text-5xl font-bold leading-none mt-1">Amex Daily</h1>
          <p className="font-display italic text-muted-foreground mt-2">Everyday card spending — categorized into your budget.</p>
        </div>
        <div className="flex items-center gap-2">
          <PlaidConnect account="amex" />
          <PlaidSync account="amex" />
          <ImportDialog
            categoryOptions={categoryOptions}
            existingRules={data.rules}
            existingTransactions={data.transactions}
            onImport={async (rows, newRules) => {
              await importBatch.mutateAsync({ rows, new_rules: newRules, label: `Amex paste ${new Date().toISOString().slice(0,10)}` });
              toast.success(`Imported ${rows.length} transactions`);
            }}
          />
          <AddTxnDialog
            categoryOptions={categoryOptions}
            onAdd={async (p) => { await addTransaction.mutateAsync(p); toast.success("Added"); }}
          />
        </div>
      </div>

      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => {
            if (monthIdx === 0) { setMonthIdx(11); setYear(year - 1); } else setMonthIdx(monthIdx - 1);
          }}><ChevronLeft className="h-4 w-4" /></Button>
          <div className="font-display text-xl font-semibold w-32 text-center">{MONTHS[monthIdx]} {year}</div>
          <Button variant="outline" size="icon" onClick={() => {
            if (monthIdx === 11) { setMonthIdx(0); setYear(year + 1); } else setMonthIdx(monthIdx + 1);
          }}><ChevronRight className="h-4 w-4" /></Button>
        </div>
        <div className="grid grid-cols-4 gap-4 text-sm">
          <SummaryStat label="Ending Balance" value={data.transactions.length ? (runningBalances.get(data.transactions[data.transactions.length - 1].id) ?? 0) : 0} className="font-bold" />
          <SummaryStat label="Charges" value={totals.charges} />
          <SummaryStat label="Payments & Credits" value={totals.credits} className="text-positive" />
          <SummaryStat label="Net Change" value={totals.net} className={totals.net >= 0 ? "text-destructive" : "text-positive"} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search description or category" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8 h-9" />
        </div>
        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as any)}>
          <SelectTrigger className="h-9 w-36"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            <SelectItem value="expense">Charges</SelectItem>
            <SelectItem value="transfer">Payments</SelectItem>
            <SelectItem value="income">Credits</SelectItem>
          </SelectContent>
        </Select>
        {members.length > 1 && (
          <Select value={memberFilter} onValueChange={setMemberFilter}>
            <SelectTrigger className="h-9 w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All cardholders</SelectItem>
              {members.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        <div className="text-xs text-muted-foreground ml-auto">{filtered.length} of {data.transactions.length} rows</div>
      </div>

      <div
        ref={tableScrollRef}
        className="border-y border-foreground/30 overflow-auto max-h-[calc(100vh-280px)]"
        style={{ overflowAnchor: "none" }}
      >
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-background">
            <tr className="text-[10px] uppercase tracking-widest text-muted-foreground border-b border-border">
              <th className="text-left py-3 pr-3 w-10">#</th>
              <th className="text-left py-3 pr-3">Date</th>
              <th className="text-left py-3 pr-3 min-w-[260px]">Description</th>
              <th className="text-left py-3 pr-3">Card</th>
              <th className="text-left py-3 pr-3">Type</th>
              <th className="text-left py-3 pr-3 min-w-[200px]">Category</th>
              <th className="text-center py-3 pr-1 w-10" title="Weekly bucket">Wk</th>
              <th className="text-center py-3 pr-1 w-10" title="Monthly bucket">Mo</th>
              <th className="text-center py-3 pr-1 w-10" title="Unplanned bucket">Un</th>
              <th className="text-center py-3 pr-1 w-10" title="Reimbursable">Re</th>
              <th className="text-right py-3 pr-3">Amount</th>
              <th className="text-right py-3 pr-3">Running</th>
              <th className="w-8"></th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr><td colSpan={11} className="py-10 text-center text-muted-foreground">Loading transactions…</td></tr>
            )}
            {!isLoading && filtered.length === 0 && (
              <tr><td colSpan={11} className="py-10 text-center text-muted-foreground">
                No Amex transactions for {MONTHS[monthIdx]} {year}. Click <strong>Paste Amex CSV</strong> to import.
              </td></tr>
            )}
            {filtered.map((t, idx) => (
              <TxnRow
                key={t.id}
                num={idx + 1}
                txn={t}
                runningBalance={runningBalances.get(t.id) ?? null}
                categoryOptions={categoryOptions}
                onUpdate={(patch) => updateTxnPreservingScroll(t.id, patch)}
                onDelete={() => { if (confirm("Delete this transaction?")) deleteTransaction.mutate(t.id); }}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function SummaryStat({ label, value, className }: { label: string; value: number; className?: string }) {
  return (
    <div className="text-right">
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className={cn("font-mono-num font-semibold text-base", className)}>{fmtMoney(value)}</div>
    </div>
  );
}

type BucketKind = "weekly" | "monthly" | "unplanned" | "none";

function getBucket(txn: Transaction): BucketKind {
  if (txn.weekly_allowance) return "weekly";
  if ((txn as any).monthly_allowance) return "monthly";
  if ((txn as any).unplanned_allowance) return "unplanned";
  return "none";
}

function TxnRow({ num, txn, runningBalance, categoryOptions, onUpdate, onDelete }: {
  num: number;
  txn: Transaction;
  runningBalance: number | null;
  categoryOptions: string[];
  onUpdate: (p: Partial<Transaction>) => void;
  onDelete: () => void;
}) {
  // Local pending bucket state to prevent snap-back from refetches
  const [pendingBucket, setPendingBucket] = useState<BucketKind | null>(null);
  const [pendingReimb, setPendingReimb] = useState<boolean | null>(null);
  const pendingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const reimbTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const displayBucket = pendingBucket ?? getBucket(txn);
  const displayReimbursable = pendingReimb ?? (txn.reimbursable ?? false);

  const toggleBucket = useCallback((target: BucketKind) => {
    const next: BucketKind = displayBucket === target ? "none" : target;
    setPendingBucket(next);
    if (pendingTimer.current) clearTimeout(pendingTimer.current);
    pendingTimer.current = setTimeout(() => setPendingBucket(null), 3000);
    onUpdate({
      weekly_allowance: next === "weekly",
      monthly_allowance: next === "monthly",
      unplanned_allowance: next === "unplanned",
    });
  }, [displayBucket, onUpdate]);

  const toggleReimbursable = useCallback(() => {
    const next = !displayReimbursable;
    setPendingReimb(next);
    if (reimbTimer.current) clearTimeout(reimbTimer.current);
    reimbTimer.current = setTimeout(() => setPendingReimb(null), 3000);
    onUpdate({ reimbursable: next, ...(next ? {} : { reimbursed: false }) });
  }, [displayReimbursable, onUpdate]);

  return (
    <tr className="border-b border-border hover:bg-secondary/40 transition-colors">
      <td className="py-2 pr-3 text-muted-foreground font-mono-num text-xs">{num}</td>
      <td className="py-2 pr-3 text-muted-foreground font-mono-num text-xs whitespace-nowrap">{txn.date}</td>
      <td className="py-2 pr-3">
        <div className="font-medium truncate max-w-[360px]" title={txn.description}>{txn.description}</div>
        {txn.notes && <div className="text-[11px] text-muted-foreground truncate" title={txn.notes}>{txn.notes}</div>}
      </td>
      <td className="py-2 pr-3 text-xs text-muted-foreground whitespace-nowrap">{txn.member ?? "—"}</td>
      <td className="py-2 pr-3">
        <Select value={txn.type} onValueChange={(v) => onUpdate({ type: v as TxType })}>
          <SelectTrigger className="h-7 text-xs w-28"><SelectValue /></SelectTrigger>
          <SelectContent>
            {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
          </SelectContent>
        </Select>
      </td>
      <td className="py-2 pr-3">
        <CategoryPicker value={txn.category ?? ""} options={categoryOptions} onChange={(v) => onUpdate({ category: v })} />
      </td>
      <td className="py-2 pr-1 text-center">
        <Checkbox
          checked={displayBucket === "weekly"}
          onCheckedChange={() => toggleBucket("weekly")}
          aria-label="Weekly bucket"
        />
      </td>
      <td className="py-2 pr-1 text-center">
        <Checkbox
          checked={displayBucket === "monthly"}
          onCheckedChange={() => toggleBucket("monthly")}
          aria-label="Monthly bucket"
        />
      </td>
      <td className="py-2 pr-1 text-center">
        <Checkbox
          checked={displayBucket === "unplanned"}
          onCheckedChange={() => toggleBucket("unplanned")}
          aria-label="Unplanned bucket"
        />
      </td>
      <td className="py-2 pr-1 text-center">
        <Checkbox
          checked={displayReimbursable}
          onCheckedChange={toggleReimbursable}
          aria-label="Reimbursable"
          className={displayReimbursable ? "border-purple-400 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500" : ""}
        />
      </td>
      <td className={cn("py-2 pr-3 text-right font-mono-num font-medium",
        txn.type === "expense" ? "" : "text-positive")}>
        {fmtMoney(Math.abs(txn.amount))}
      </td>
      <td className="py-2 pr-3 text-right font-mono-num text-xs text-muted-foreground">
        {runningBalance == null ? "—" : fmtMoney(runningBalance)}
      </td>
      <td className="py-2 pr-1">
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onDelete}>
          <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
        </Button>
      </td>
    </tr>
  );
}

function CategoryPicker({ value, options, onChange }: {
  value: string; options: string[]; onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" role="combobox" className="h-7 text-xs w-56 justify-between font-normal truncate">
          <span className="truncate">{value || "Uncategorized"}</span>
          <ChevronsUpDown className="ml-1 h-3 w-3 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-0" align="start">
        <Command>
          <CommandInput placeholder="Search or type…" />
          <CommandList>
            <CommandGroup>
              {options.map((o) => (
                <CommandItem key={o} onSelect={() => { onChange(o); setOpen(false); }}>
                  <Check className={cn("mr-2 h-3 w-3", value === o ? "opacity-100" : "opacity-0")} />
                  {o}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function AddTxnDialog({ categoryOptions, onAdd }: {
  categoryOptions: string[];
  onAdd: (p: Partial<Transaction>) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [desc, setDesc] = useState("");
  const [type, setType] = useState<TxType>("expense");
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [bucket, setBucket] = useState<"none"|"weekly"|"monthly"|"unplanned">("none");
  const reset = () => { setDate(new Date().toISOString().slice(0,10)); setDesc(""); setType("expense"); setCategory(""); setAmount(""); setBucket("none"); };
  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild><Button className="gap-2"><Plus className="h-4 w-4" /> Add</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Add Amex transaction</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <label className="text-xs">Date<Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
          <label className="text-xs">Type
            <Select value={type} onValueChange={(v) => setType(v as TxType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </label>
          <label className="text-xs col-span-2">Description<Input value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
          <label className="text-xs col-span-2">Category
            <Input list="amex-cat-options" value={category} onChange={(e) => setCategory(e.target.value)} />
          </label>
          <label className="text-xs col-span-2">Amount (positive number)
            <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </label>
          <label className="text-xs col-span-2">Bucket
            <Select value={bucket} onValueChange={(v) => setBucket(v as any)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="unplanned">Unplanned</SelectItem>
              </SelectContent>
            </Select>
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={async () => {
            const a = Number(amount);
            if (!date || !desc || !a) { toast.error("Fill date, description, amount"); return; }
            await onAdd({
              date, description: desc, type, category: category || null,
              amount: type === "income" ? Math.abs(a) : type === "transfer" ? -Math.abs(a) : Math.abs(a),
              weekly_allowance: bucket === "weekly",
              monthly_allowance: bucket === "monthly",
              unplanned_allowance: bucket === "unplanned",
            });
            setOpen(false); reset();
          }}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

type StagedRow = ParsedRow & {
  type: TxType;
  category: string;
  matchKeyword: string | null;
  saveRule: boolean;
  ruleKeyword: string;
  include: boolean;
  isDuplicate: boolean;
};

function ImportDialog({ categoryOptions, existingRules, existingTransactions, onImport }: {
  categoryOptions: string[];
  existingRules: { keyword: string; category: string; type: TxType | null; priority: number; id: string }[];
  existingTransactions: Transaction[];
  onImport: (rows: any[], newRules: any[]) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [staged, setStaged] = useState<StagedRow[]>([]);
  const [fileName, setFileName] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    try {
      const content = await readFileAsText(file);
      setText(content);
      setFileName(file.name);
      toast.success(`Loaded ${file.name}`);
    } catch {
      toast.error("Could not read file");
    }
  };

  const parse = () => {
    const { rows, skipped } = parseBankPaste(text);
    const next: StagedRow[] = rows.map((r) => {
      const sug = suggestCategory(r.description, existingRules as any);
      // Amex convention: positive = charge (expense), negative = credit/payment
      const t: TxType = sug.type ?? (r.amount < 0 ? "transfer" : "expense");
      const words = r.description.toUpperCase().replace(/[^A-Z0-9 ]+/g, " ").split(/\s+/).filter(Boolean);
      const ruleKw = sug.ruleKeyword ?? (words[0] ?? "");
      const dupe = isDuplicate(r.date, r.description, r.amount, existingTransactions);
      return {
        ...r, type: t, category: sug.category ?? "",
        matchKeyword: sug.ruleKeyword,
        saveRule: false, ruleKeyword: ruleKw, include: !dupe, isDuplicate: dupe,
      };
    });
    setStaged(next);
    const dupeCount = next.filter((r) => r.isDuplicate).length;
    if (skipped > 0) toast.message(`Parsed ${rows.length}, skipped ${skipped} unreadable lines`);
    else if (dupeCount > 0) toast.warning(`Parsed ${rows.length} rows — ${dupeCount} duplicate(s) auto-excluded`);
    else toast.success(`Parsed ${rows.length} rows`);
  };

  const reset = () => { setText(""); setStaged([]); setFileName(""); };

  const submit = async () => {
    const rows = staged.filter((r) => r.include).map((r) => ({
      date: r.date,
      description: r.description,
      type: r.type,
      category: r.category || null,
      amount: r.type === "income" ? Math.abs(r.amount) : r.type === "transfer" ? -Math.abs(r.amount) : Math.abs(r.amount),
      notes: buildMatchNote(r.matchKeyword ?? r.ruleKeyword, r.category),
    }));
    if (rows.length === 0) { toast.error("Nothing to import"); return; }
    const newRules = staged
      .filter((r) => r.include && r.saveRule && r.ruleKeyword.trim() && r.category.trim())
      .map((r) => ({ keyword: r.ruleKeyword.trim(), category: r.category.trim(), type: r.type, priority: 10 }));
    await onImport(rows, newRules);
    setOpen(false); reset();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2"><Upload className="h-4 w-4" /> Import</Button>
      </DialogTrigger>
      <DialogContent className="max-w-5xl">
        <DialogHeader>
          <DialogTitle>Import Amex transactions</DialogTitle>
        </DialogHeader>
        {staged.length === 0 ? (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Upload a CSV or Excel file from Amex, or paste rows directly.
              Positive amounts = charges, negative = payments/credits.
            </p>
            <div
              className="border-2 border-dashed border-border rounded-xl p-6 text-center cursor-pointer hover:border-accent/50 transition-colors"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
              onDrop={(e) => { e.preventDefault(); e.stopPropagation(); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.xlsx,.xls,.txt"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
              <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
              {fileName ? (
                <p className="text-sm font-medium text-accent">{fileName}</p>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Drop a <span className="font-semibold">.csv</span> or <span className="font-semibold">.xlsx</span> file here, or click to browse
                </p>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t" /></div>
              <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-muted-foreground">or paste</span></div>
            </div>
            <Textarea
              value={text} onChange={(e) => { setText(e.target.value); setFileName(""); }}
              placeholder={"04/15/2026, METRO MARKET, HANNAH HUBELE, -51014, 48.80\n04/13/2026, MOBILE PAYMENT - THANK YOU, BRAD HUBELE, -31009, -300.00"}
              className="font-mono text-xs min-h-[120px]"
            />
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={parse} disabled={!text.trim()}>Parse</Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-xs text-muted-foreground">
              Review {staged.length} rows. Edit Type/Category as needed. Tick <Badge variant="outline">Save rule</Badge> to remember a keyword for future imports.
              {staged.some((r) => r.isDuplicate) && (
                <span className="ml-2 text-amber-600 font-semibold">
                  ⚠ {staged.filter((r) => r.isDuplicate).length} duplicate(s) found &amp; auto-excluded
                </span>
              )}
            </div>
            <div className="max-h-[420px] overflow-auto border rounded-md">
              <table className="w-full text-xs">
                <thead className="bg-secondary/50 sticky top-0">
                  <tr>
                    <th className="text-left p-2 w-8"></th>
                    <th className="text-left p-2">Date</th>
                    <th className="text-left p-2">Description</th>
                    <th className="text-left p-2">Type</th>
                    <th className="text-left p-2">Category</th>
                    <th className="text-right p-2">Amount</th>
                    <th className="text-left p-2">Save rule (keyword)</th>
                  </tr>
                </thead>
                <tbody>
                  {staged.map((r, i) => (
                    <tr key={i} className="border-t border-border">
                      <td className="p-2"><Checkbox checked={r.include} onCheckedChange={(v) => {
                        const c = [...staged]; c[i].include = !!v; setStaged(c);
                      }} /></td>
                      <td className="p-2 font-mono-num">{r.date}</td>
                      <td className="p-2 max-w-[280px] truncate" title={r.description}>
                        {r.description}
                        {r.isDuplicate && <Badge variant="outline" className="ml-1 text-[10px] border-amber-500 text-amber-600">Duplicate</Badge>}
                      </td>
                      <td className="p-2">
                        <Select value={r.type} onValueChange={(v) => {
                          const c = [...staged]; c[i].type = v as TxType; setStaged(c);
                        }}>
                          <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {TYPE_OPTIONS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="p-2">
                        <Input list="amex-cat-options" value={r.category} onChange={(e) => {
                          const c = [...staged]; c[i].category = e.target.value; setStaged(c);
                        }} className={cn("h-7 text-xs w-48", !r.category && "border-amber-500/60")} placeholder="—" />
                      </td>
                      <td className={cn("p-2 text-right font-mono-num",
                        r.type === "expense" ? "" : "text-positive")}>{fmtMoney(Math.abs(r.amount))}</td>
                      <td className="p-2">
                        <div className="flex items-center gap-1">
                          <Checkbox checked={r.saveRule} onCheckedChange={(v) => {
                            const c = [...staged]; c[i].saveRule = !!v; setStaged(c);
                          }} />
                          <Input value={r.ruleKeyword} onChange={(e) => {
                            const c = [...staged]; c[i].ruleKeyword = e.target.value; setStaged(c);
                          }} className="h-7 text-xs w-32" disabled={!r.saveRule} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setStaged([])}>Back</Button>
              <Button onClick={submit}>Import {staged.filter((r) => r.include).length}</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

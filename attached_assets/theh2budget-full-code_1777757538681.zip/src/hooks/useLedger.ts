// Cloud-backed ledger: transactions, match_rules, budget_lines.
// Mirrors the resilient pattern used in useDebts (edge function with fallback).

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AMEX_SOURCES, BANKING_SOURCES, type Account, type BudgetLineRow, type MatchRule, type Transaction } from "@/lib/ledgerTypes";

export type LedgerData = {
  transactions: Transaction[];
  rules: MatchRule[];
  budget_lines: BudgetLineRow[];
};

const KEY = (month?: number, year?: number, account?: Account) =>
  ["ledger", month ?? "all", year ?? "all", account ?? "all"];

async function loadLedger(month?: number, year?: number): Promise<LedgerData> {
  const { data, error } = await supabase.functions.invoke("ledger-api", {
    body: { action: "list", payload: { month, year } },
  });
  if (!error && data?.transactions) return data as LedgerData;
  // Fallback: direct table reads. Keep this filtered too so month pages do not
  // silently show the first 1,000 rows from the whole ledger if the function is unavailable.
  let txQ = supabase
    .from("transactions")
    .select("*")
    .order("date", { ascending: true })
    .order("created_at", { ascending: true });
  if (year && month) {
    const start = `${year}-${String(month).padStart(2, "0")}-01`;
    const end = month === 12
      ? `${year + 1}-01-01`
      : `${year}-${String(month + 1).padStart(2, "0")}-01`;
    txQ = txQ.gte("date", start).lt("date", end);
  }
  const [tx, rules, bl] = await Promise.all([
    txQ,
    supabase.from("match_rules").select("*").order("priority", { ascending: false }),
    supabase.from("budget_lines").select("*").order("sort_order", { ascending: true }),
  ]);
  if (tx.error) throw error ?? tx.error;
  return {
    transactions: (tx.data ?? []).map((r: any) => ({ ...r, amount: Number(r.amount) })),
    rules: (rules.data ?? []) as any,
    budget_lines: (bl.data ?? []).map((r: any) => ({ ...r, budgeted: Number(r.budgeted) })),
  };
}

export function useLedger(opts?: { month?: number; year?: number; account?: Account }) {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  // Track in-flight mutations so realtime doesn't blow away optimistic updates
  const mutatingRef = useRef(0);
  const realtimeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const debouncedInvalidate = useCallback(() => {
    // Skip if a mutation is in progress — onSettled will handle it
    if (mutatingRef.current > 0) return;
    if (realtimeTimerRef.current) clearTimeout(realtimeTimerRef.current);
    realtimeTimerRef.current = setTimeout(() => {
      qc.invalidateQueries({ queryKey: ["ledger"] });
    }, 500);
  }, [qc]);

  const query = useQuery({
    queryKey: KEY(opts?.month, opts?.year, opts?.account),
    enabled: ready && !!session?.user.id,
    retry: 1,
    retryDelay: 1500,
    staleTime: 15_000,
    queryFn: async () => {
      const data = await loadLedger(opts?.month, opts?.year);
      if (!opts?.account) return data;
      const allowedSources = opts.account === "amex" ? AMEX_SOURCES : BANKING_SOURCES;
      const filtered = data.transactions.filter((t) => (allowedSources as readonly string[]).includes(t.source));
      return { ...data, transactions: filtered };
    },
  });

  useEffect(() => {
    if (!ready) return;
    const channelName = `ledger-changes-${Math.random().toString(36).slice(2, 10)}`;
    const channel = supabase
      .channel(channelName)
      .on("postgres_changes", { event: "*", schema: "public", table: "transactions" },
        () => debouncedInvalidate())
      .on("postgres_changes", { event: "*", schema: "public", table: "match_rules" },
        () => debouncedInvalidate())
      .on("postgres_changes", { event: "*", schema: "public", table: "budget_lines" },
        () => debouncedInvalidate())
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
      if (realtimeTimerRef.current) clearTimeout(realtimeTimerRef.current);
    };
  }, [ready, debouncedInvalidate]);

  const call = async (action: string, payload: Record<string, unknown> = {}) => {
    const { data, error } = await supabase.functions.invoke("ledger-api", {
      body: { action, payload },
    });
    if (error) throw error;
    return data;
  };

  const defaultSource = opts?.account === "amex" ? "amex_manual" : "manual";
  const defaultImportSource = opts?.account === "amex" ? "amex_import" : "bank_import";

  const addTransaction = useMutation({
    mutationFn: (p: Partial<Transaction>) => {
      const payload = { source: defaultSource, ...p };
      return call("add_transaction", payload as any);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const updateTransaction = useMutation({
    mutationFn: (p: Partial<Transaction> & { id: string }) => call("update_transaction", p as any),
    onMutate: async (patch) => {
      mutatingRef.current += 1;
      await qc.cancelQueries({ queryKey: ["ledger"] });
      const previous = qc.getQueriesData<LedgerData>({ queryKey: ["ledger"] });
      qc.setQueriesData<LedgerData>({ queryKey: ["ledger"] }, (old) => {
        if (!old) return old;
        return {
          ...old,
          transactions: old.transactions.map((t) =>
            t.id === patch.id ? { ...t, ...patch } : t
          ),
        };
      });
      return { previous };
    },
    onError: (_err, _patch, context) => {
      if (context?.previous) {
        for (const [key, data] of context.previous) {
          qc.setQueryData(key, data);
        }
      }
    },
    onSettled: () => {
      // Mark all ledger queries as stale so they refetch when next observed
      // (e.g. navigating to Dashboard). Using refetchType 'none' avoids an
      // immediate refetch on the current page which would cause scroll jumps.
      qc.invalidateQueries({ queryKey: ["ledger"], refetchType: "none" });
      // Keep mutatingRef elevated for 1.5s so the realtime listener doesn't
      // immediately refetch and overwrite the optimistic state before the DB
      // change fully propagates through the realtime pipeline.
      setTimeout(() => {
        mutatingRef.current = Math.max(0, mutatingRef.current - 1);
      }, 1500);
    },
  });
  const deleteTransaction = useMutation({
    mutationFn: (id: string) => call("delete_transaction", { id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const importBatch = useMutation({
    mutationFn: (p: { rows: any[]; new_rules?: any[]; label?: string }) => {
      const rows = p.rows.map((r) => ({ source: defaultImportSource, ...r }));
      return call("import_batch", { ...p, rows });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const deleteBatch = useMutation({
    mutationFn: (id: string) => call("delete_batch", { id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const addRule = useMutation({
    mutationFn: (p: Partial<MatchRule>) => call("add_rule", p as any),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const deleteRule = useMutation({
    mutationFn: (id: string) => call("delete_rule", { id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });

  const upsertBudgetLine = useMutation({
    mutationFn: (p: Partial<BudgetLineRow> & { id: string }) =>
      call("upsert_budget_line", p as any),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const deleteBudgetLine = useMutation({
    mutationFn: (id: string) => call("delete_budget_line", { id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });
  const seedBudgetLines = useMutation({
    mutationFn: (lines: Array<Partial<BudgetLineRow> & { id: string }>) =>
      call("seed_budget_lines", { lines }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ledger"] }),
  });

  return {
    data: query.data ?? { transactions: [], rules: [], budget_lines: [] },
    isLoading: query.isLoading,
    isFetched: query.isFetched,
    error: query.error,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    importBatch,
    deleteBatch,
    addRule,
    deleteRule,
    upsertBudgetLine,
    deleteBudgetLine,
    seedBudgetLines,
    refetch: query.refetch,
  };
}

// Tracks the active weekly $425 spending window for the household.
// One row per user in weekly_allowance_state. Auto-initialized to the most
// recent Monday on first read.
//
// Resilience: if the backend is temporarily unhappy (PGRST002 schema-cache,
// PGRST001 connection errors, 503/504), we fall back to a local week state
// so the dashboard NEVER gets stuck on "Loading…". The card will still
// render with this week's Monday + $425. Background retries continue, and
// once the backend recovers we'll swap to the real persisted state.

import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type WeeklyAllowanceState = {
  user_id: string;
  week_start_date: string; // YYYY-MM-DD (Monday)
  weekly_total: number;
  monthly_total: number;
  unplanned_total: number;
};

function mondayOf(d: Date): string {
  // Returns the most recent Sunday (week starts Sun, ends Sat).
  // Name kept for backwards compatibility.
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const dow = x.getDay(); // 0=Sun..6=Sat
  x.setDate(x.getDate() - dow);
  return x.toISOString().slice(0, 10);
}

function addDaysISO(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00");
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function isTransientError(err: any): boolean {
  if (!err) return false;
  const code = err.code ?? "";
  if (code === "PGRST001" || code === "PGRST002") return true;
  const status = err.status;
  if (status === 502 || status === 503 || status === 504) return true;
  const msg = (err.message ?? "").toLowerCase();
  return msg.includes("schema cache") || msg.includes("connection") || msg.includes("network");
}

export function useWeeklyAllowance() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();
  const userId = session?.user.id;

  // Local fallback so the UI is never blocked on the backend.
  const [localWeekStart, setLocalWeekStart] = useState<string>(() => mondayOf(new Date()));

  const query = useQuery({
    queryKey: ["weekly-allowance", userId],
    enabled: ready && !!userId,
    staleTime: 30_000,
    // React-query will keep retrying transient errors automatically; the
    // local fallback below makes that retry loop invisible to the user.
    retry: (failureCount, err: any) => isTransientError(err) && failureCount < 8,
    retryDelay: (attempt) => Math.min(8000, 500 * Math.pow(1.6, attempt)),
    queryFn: async (): Promise<WeeklyAllowanceState> => {
      const { data, error } = await supabase
        .from("weekly_allowance_state")
        .select("user_id, week_start_date, weekly_total, monthly_total, unplanned_total")
        .maybeSingle();
      if (error) throw error;
      if (data) {
        return {
          user_id: data.user_id,
          week_start_date: data.week_start_date,
          weekly_total: Number(data.weekly_total),
          monthly_total: Number((data as any).monthly_total ?? 0),
          unplanned_total: Number((data as any).unplanned_total ?? 0),
        };
      }
      const monday = mondayOf(new Date());
      const { data: upserted, error: upErr } = await supabase
        .from("weekly_allowance_state")
        .upsert(
          { user_id: userId!, week_start_date: monday, weekly_total: 425, monthly_total: 0, unplanned_total: 0 } as any,
          { onConflict: "user_id" },
        )
        .select("user_id, week_start_date, weekly_total, monthly_total, unplanned_total")
        .single();
      if (upErr) throw upErr;
      return {
        user_id: upserted.user_id,
        week_start_date: upserted.week_start_date,
        weekly_total: Number(upserted.weekly_total),
        monthly_total: Number((upserted as any).monthly_total ?? 0),
        unplanned_total: Number((upserted as any).unplanned_total ?? 0),
      };
    },
  });

  // Keep our local fallback in sync with whatever the backend last told us.
  useEffect(() => {
    if (query.data?.week_start_date) {
      setLocalWeekStart(query.data.week_start_date);
    }
  }, [query.data?.week_start_date]);

  const advanceWeek = useMutation({
    mutationFn: async () => {
      const currentStart = query.data?.week_start_date ?? localWeekStart;
      const next = addDaysISO(currentStart, 7);

      // Optimistic local advance so the UI feels instant even if the backend
      // is slow/unhealthy.
      setLocalWeekStart(next);

      if (userId) {
        const { error } = await supabase
          .from("weekly_allowance_state")
          .upsert(
            { user_id: userId, week_start_date: next, weekly_total: query.data?.weekly_total ?? 425 },
            { onConflict: "user_id" },
          );
        if (error && !isTransientError(error)) throw error;
      }
      return next;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["weekly-allowance"] }),
  });

  // Always return *some* state so the dashboard tile renders. Prefer the
  // backend value; fall back to the local week with $425 default.
  const effectiveState: WeeklyAllowanceState | undefined = useMemo(() => {
    if (query.data) return query.data;
    if (!userId) return undefined;
    return {
      user_id: userId,
      week_start_date: localWeekStart,
      weekly_total: 425,
      monthly_total: 0,
      unplanned_total: 0,
    };
  }, [query.data, localWeekStart, userId]);

  const updateBudget = useMutation({
    mutationFn: async (patch: { weekly_total?: number; monthly_total?: number; unplanned_total?: number }) => {
      if (!userId) return;
      const row: any = {
        user_id: userId,
        week_start_date: effectiveState?.week_start_date ?? localWeekStart,
        weekly_total: patch.weekly_total ?? effectiveState?.weekly_total ?? 425,
        monthly_total: patch.monthly_total ?? effectiveState?.monthly_total ?? 0,
        unplanned_total: patch.unplanned_total ?? effectiveState?.unplanned_total ?? 0,
      };
      const { error } = await supabase
        .from("weekly_allowance_state")
        .upsert(row, { onConflict: "user_id" });
      if (error && !isTransientError(error)) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["weekly-allowance"] }),
  });

  return {
    state: effectiveState,
    isLoading: query.isLoading && !effectiveState,
    isBackendUnavailable: !!query.error && !query.data,
    advanceWeek,
    updateBudget,
  };
}

export { addDaysISO };

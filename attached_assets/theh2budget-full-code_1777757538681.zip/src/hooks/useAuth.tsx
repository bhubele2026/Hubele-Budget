import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

function isTransientBackendError(error: any): boolean {
  if (!error) return false;
  const status = error.status ?? error.code;
  if (status === 503 || status === 504 || status === 502) return true;
  const msg = (error.message ?? "").toLowerCase();
  return msg.includes("fetch") || msg.includes("network") || msg.includes("connection");
}

export interface AuthState {
  session: Session | null;
  authReady: boolean;     // session restore from storage is finished
  roleLoading: boolean;   // owner-role lookup in flight
  isOwner: boolean;
  /** True when the backend has *confirmed* this user is not an owner. Distinct from "unknown yet". */
  roleResolved: boolean;
  roleError: string | null;
  /**
   * App-shell readiness. True as soon as we have a session — *not* gated on role lookup.
   * Role enforcement is surfaced inline via isOwner/roleResolved so a flaky backend
   * cannot strand the user on a blank screen.
   */
  ready: boolean;
  refetchRole: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

async function fetchIsOwner(
  userId: string,
): Promise<{ ok: boolean; isOwner: boolean; error?: string; transient?: boolean }> {
  const started = Date.now();
  const MAX_MS = 60_000;
  let attempt = 0;
  let lastError: any = null;
  while (Date.now() - started < MAX_MS) {
    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (!error && data) {
      return { ok: true, isOwner: data.some((r: any) => r.role === "owner") };
    }
    lastError = error;
    const status = (error as any)?.status;
    if (status === 401 || status === 403) {
      return { ok: false, isOwner: false, error: error?.message ?? "Not authorized.", transient: false };
    }
    if (!isTransientBackendError(error)) {
      return { ok: false, isOwner: false, error: error?.message ?? "Role lookup failed.", transient: false };
    }
    await new Promise((r) => setTimeout(r, Math.min(6000, 400 * Math.pow(1.6, attempt))));
    attempt++;
  }
  return {
    ok: false,
    isOwner: false,
    error: lastError?.message ?? "Backend unavailable.",
    transient: true,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [roleLoading, setRoleLoading] = useState(false);
  const [isOwner, setIsOwner] = useState(false);
  const [roleResolved, setRoleResolved] = useState(false);
  const [roleError, setRoleError] = useState<string | null>(null);
  const [refetchTick, setRefetchTick] = useState(0);
  const lastCheckedUserId = useRef<string | null>(null);

  useEffect(() => {
    let mounted = true;

    const { data: sub } = supabase.auth.onAuthStateChange((evt, s) => {
      if (!mounted) return;
      setSession(s);
      if (!s) {
        setIsOwner(false);
        setRoleResolved(false);
        setRoleError(null);
        setRoleLoading(false);
        lastCheckedUserId.current = null;
      }
      // If the refresh token is dead, GoTrue fires TOKEN_REFRESHED with null
      // session. Make sure we drop any stale local state so the user lands on
      // the sign-in screen instead of a half-broken app.
      if (evt === "TOKEN_REFRESHED" && !s) {
        supabase.auth.signOut().catch(() => {});
      }
    });

    supabase.auth
      .getSession()
      .then(({ data: { session: s } }) => {
        if (!mounted) return;
        setSession(s);
      })
      .catch(async () => {
        if (!mounted) return;
        // Stored token is invalid (e.g. "Refresh Token Not Found"). Clear it
        // so the next attempt starts clean instead of looping on a dead token.
        try {
          await supabase.auth.signOut();
        } catch {
          // ignore
        }
        if (mounted) setSession(null);
      })
      .finally(() => {
        if (mounted) setAuthReady(true);
      });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!authReady) return;
    const uid = session?.user.id ?? null;
    if (!uid) return;
    if (lastCheckedUserId.current === uid && refetchTick === 0) return;

    let cancelled = false;
    setRoleLoading(true);
    setRoleError(null);

    fetchIsOwner(uid).then((res) => {
      if (cancelled) return;
      lastCheckedUserId.current = uid;
      if (res.ok) {
        setIsOwner(res.isOwner);
        setRoleResolved(true);
        setRoleError(null);
      } else if (res.transient) {
        // Backend is recovering — keep prior state, surface an inline error.
        setRoleError(res.error ?? "Backend reconnecting…");
      } else {
        setIsOwner(false);
        setRoleResolved(true);
        setRoleError(res.error ?? "Could not verify access.");
      }
      setRoleLoading(false);
    });

    return () => {
      cancelled = true;
    };
  }, [authReady, session?.user.id, refetchTick]);

  const value = useMemo<AuthState>(() => {
    // ready = session-restore complete + signed in. NOT gated on role lookup.
    const ready = authReady && !!session;
    return {
      session,
      authReady,
      roleLoading,
      isOwner,
      roleResolved,
      roleError,
      ready,
      refetchRole: () => setRefetchTick((t) => t + 1),
    };
  }, [session, authReady, roleLoading, isOwner, roleResolved, roleError]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within <AuthProvider>");
  return ctx;
}

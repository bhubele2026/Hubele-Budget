// One-shot reconciliation that keeps `recurring_items` of kind "debt_min"
// in sync with the `debts` table. The Bills page treats these rows as
// read-only; this hook is what makes that promise true:
//
//   • For every active debt with min_payment > 0 that has no linked
//     debt_min recurring row → create one.
//   • For every debt_min recurring row whose linked debt no longer exists
//     → mark it inactive (preserve history, don't hard-delete).
//
// We intentionally do NOT overwrite the stored `amount` on existing rows.
// The Bills page and Forecast read the live `min_payment` directly from
// the debt and pass it as an override into `expandAll`. Keeping writes
// minimal avoids edit-loops with realtime subscriptions.

import { useEffect, useRef } from "react";
import { useDebts } from "@/hooks/useDebts";
import { useRecurring } from "@/hooks/useRecurring";

export function useSyncDebtMinimums() {
  const { debts, isLoading: debtsLoading } = useDebts();
  const { items, isLoading: recLoading, add, update } = useRecurring();
  const ranOnceRef = useRef(false);

  useEffect(() => {
    if (debtsLoading || recLoading) return;
    if (ranOnceRef.current) return;
    if (debts.length === 0 && items.length === 0) return;
    ranOnceRef.current = true;

    const debtIds = new Set(debts.map((d) => d.id));
    const debtMinByDebtId = new Map<string, typeof items[number]>();
    for (const it of items) {
      if (it.kind === "debt_min" && it.linked_debt_id) {
        // If multiple rows exist for the same debt, prefer the active one.
        const existing = debtMinByDebtId.get(it.linked_debt_id);
        if (!existing || (it.active && !existing.active)) {
          debtMinByDebtId.set(it.linked_debt_id, it);
        }
      }
    }

    // 1. Create or reactivate debt_min rows for active debts with a positive min payment.
    for (const d of debts) {
      const isActive = d.status !== "paid_off" && (d.balance ?? 0) > 0;
      const min = Number(d.minPayment ?? 0);
      if (!isActive || min <= 0) continue;

      const existing = debtMinByDebtId.get(d.id);
      if (existing) {
        // Reactivate if it was deactivated
        if (!existing.active) {
          update.mutate({ id: existing.id, active: true });
        }
        // Sync day_of_month if debt due_day changed
        if (d.dueDay && existing.day_of_month !== d.dueDay) {
          update.mutate({ id: existing.id, day_of_month: d.dueDay });
        }
        continue;
      }

      add.mutate({
        kind: "debt_min",
        label: `${d.creditor} minimum`,
        amount: min,
        cadence: "monthly",
        anchor_date: new Date().toISOString().slice(0, 10),
        day_of_month: d.dueDay ?? 1,
        linked_debt_id: d.id,
        stops_at_payoff: true,
        active: true,
        category: "Debt — Minimum Payments",
      } as any);
    }

    // 2. Deactivate orphaned debt_min rows (linked debt was deleted).
    for (const it of items) {
      if (it.kind !== "debt_min" || !it.linked_debt_id) continue;
      if (!debtIds.has(it.linked_debt_id) && it.active) {
        update.mutate({ id: it.id, active: false });
      }
    }
  }, [debts, items, debtsLoading, recLoading, add, update]);
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type ReimbursableItem = {
  id: string;
  date: string;
  description: string;
  amount: number;
  source: string;
  reimbursed: boolean;
};

export function useReimbursables() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["reimbursables"],
    enabled: ready && !!session?.user.id,
    staleTime: 15_000,
    queryFn: async (): Promise<ReimbursableItem[]> => {
      const { data, error } = await supabase.functions.invoke("ledger-api", {
        body: { action: "list_reimbursables" },
      });
      if (!error && Array.isArray(data?.transactions)) {
        return data.transactions.map((t: any) => ({
          ...t,
          amount: Number(t.amount),
          reimbursed: !!t.reimbursed,
        }));
      }
      // Fallback: direct query
      const { data: rows, error: qErr } = await supabase
        .from("transactions")
        .select("id, date, description, amount, source, reimbursable, reimbursed")
        .eq("reimbursable", true)
        .order("date", { ascending: false });
      if (qErr) throw qErr;
      return (rows ?? []).map((t: any) => ({
        ...t,
        amount: Number(t.amount),
        reimbursed: !!t.reimbursed,
      }));
    },
  });

  const toggleReimbursed = useMutation({
    mutationFn: async ({ id, reimbursed }: { id: string; reimbursed: boolean }) => {
      const { error } = await supabase.functions.invoke("ledger-api", {
        body: { action: "update_transaction", payload: { id, reimbursed } },
      });
      if (error) throw error;
    },
    onMutate: async ({ id, reimbursed }) => {
      await qc.cancelQueries({ queryKey: ["reimbursables"] });
      const prev = qc.getQueryData<ReimbursableItem[]>(["reimbursables"]);
      qc.setQueryData<ReimbursableItem[]>(["reimbursables"], (old) =>
        (old ?? []).map((t) => (t.id === id ? { ...t, reimbursed } : t)),
      );
      return { prev };
    },
    onError: (_err, _vars, ctx) => {
      if (ctx?.prev) qc.setQueryData(["reimbursables"], ctx.prev);
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: ["reimbursables"] });
      qc.invalidateQueries({ queryKey: ["ledger"], refetchType: "none" });
    },
  });

  return {
    items: query.data ?? [],
    isLoading: query.isLoading,
    toggleReimbursed,
  };
}

// React Query hook for per-user avalanche settings, served via the
// `debts-api` edge function so the cloud read path is consistent with
// debts and resilient to transient REST hiccups.

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { BudgetMode, ExtraSource, Strategy } from "@/lib/debtData";

export type AvalancheSettings = {
  strategy: Strategy;
  extraSource: ExtraSource;
  manualExtra: number;
  budgetMode: BudgetMode;
};

const DEFAULTS: AvalancheSettings = {
  strategy: "avalanche",
  extraSource: "budget_net",
  manualExtra: 0,
  budgetMode: "budgeted",
};

const KEY = ["avalanche-settings"];

async function loadSettings(): Promise<AvalancheSettings> {
  const { data, error } = await supabase.functions.invoke("debts-api", {
    body: { action: "list" },
  });
  if (error) throw error;
  const s = data?.settings;
  if (!s) return DEFAULTS;
  return {
    strategy: s.strategy as Strategy,
    extraSource: s.extra_source as ExtraSource,
    manualExtra: Number(s.manual_extra),
    budgetMode: s.budget_mode as BudgetMode,
  };
}

export function useAvalancheSettings() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: KEY,
    enabled: ready && !!session?.user.id,
    retry: 1,
    retryDelay: 1500,
    staleTime: 30_000,
    queryFn: loadSettings,
  });

  const update = useMutation({
    mutationFn: async (patch: Partial<AvalancheSettings>) => {
      const payload: Record<string, unknown> = {};
      if (patch.strategy !== undefined) payload.strategy = patch.strategy;
      if (patch.extraSource !== undefined) payload.extra_source = patch.extraSource;
      if (patch.manualExtra !== undefined) payload.manual_extra = patch.manualExtra;
      if (patch.budgetMode !== undefined) payload.budget_mode = patch.budgetMode;
      const { error } = await supabase.functions.invoke("debts-api", {
        body: { action: "update_settings", payload },
      });
      if (error) throw error;
    },
    onMutate: async (patch) => {
      await qc.cancelQueries({ queryKey: KEY });
      const prev = qc.getQueryData<AvalancheSettings>(KEY);
      if (prev) qc.setQueryData<AvalancheSettings>(KEY, { ...prev, ...patch });
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(KEY, ctx.prev);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  return {
    settings: query.data ?? DEFAULTS,
    isLoading: query.isLoading,
    error: query.error as Error | null,
    refetch: query.refetch,
    update,
  };
}

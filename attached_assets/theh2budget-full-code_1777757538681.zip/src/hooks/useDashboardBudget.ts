// Period-scoped dashboard budget amounts.
// Each bucket (weekly / monthly / unplanned) is stored per period key:
//   weekly  → Sunday ISO date "2026-04-27"
//   monthly → "2026-05"
//   unplanned → "2026-05"

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

type Bucket = "weekly" | "monthly" | "unplanned";

const KEY = (bucket: Bucket, periodKey: string) => ["dashboard-budget", bucket, periodKey];

export function useDashboardBudget(bucket: Bucket, periodKey: string) {
  const { session, ready } = useAuth();
  const qc = useQueryClient();
  const userId = session?.user.id;

  const query = useQuery({
    queryKey: KEY(bucket, periodKey),
    enabled: ready && !!userId && !!periodKey,
    staleTime: 30_000,
    queryFn: async (): Promise<number | null> => {
      const { data, error } = await supabase
        .from("dashboard_budgets")
        .select("amount")
        .eq("bucket", bucket)
        .eq("period_key", periodKey)
        .maybeSingle();
      if (error) throw error;
      return data ? Number(data.amount) : null;
    },
  });

  const upsert = useMutation({
    mutationFn: async (amount: number) => {
      if (!userId) return;
      const { error } = await supabase
        .from("dashboard_budgets")
        .upsert(
          { user_id: userId, bucket, period_key: periodKey, amount } as any,
          { onConflict: "user_id,bucket,period_key" },
        );
      if (error) throw error;
    },
    onMutate: async (amount) => {
      // Optimistic update
      await qc.cancelQueries({ queryKey: KEY(bucket, periodKey) });
      const prev = qc.getQueryData<number | null>(KEY(bucket, periodKey));
      qc.setQueryData(KEY(bucket, periodKey), amount);
      return { prev };
    },
    onError: (_err, _amount, ctx) => {
      if (ctx?.prev !== undefined) qc.setQueryData(KEY(bucket, periodKey), ctx.prev);
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: KEY(bucket, periodKey) });
    },
  });

  return {
    /** The manually saved budget, or null if none set for this period. */
    savedAmount: query.data ?? null,
    isLoading: query.isLoading,
    save: upsert.mutate,
  };
}

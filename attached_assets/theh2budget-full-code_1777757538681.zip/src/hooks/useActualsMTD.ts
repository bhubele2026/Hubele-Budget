// Month-to-date actuals derived from the ledger, shared by Avalanche + Dashboard.
//
// A "debt payment" is an outflow from a BANKING account whose category exactly
// matches an active debt's creditor (case-insensitive). This avoids the old
// fuzzy-regex approach that mis-classified every Amex purchase containing the
// word "card", "synchrony", "affirm", etc. as a debt payment.
//
// Avalanche-extra entries (category = "avalanche extra") are also counted as
// debt payments and tracked separately as the avalanche source amount.

import { useMemo } from "react";
import { useLedger } from "@/hooks/useLedger";
import type { Debt } from "@/lib/debtData";
import type { ActualsMTD } from "@/lib/extraSource";
import { accountOf } from "@/lib/ledgerTypes";

export function useActualsMTD(debts: Debt[], today: Date = new Date()): ActualsMTD {
  const month = today.getMonth() + 1;
  const year = today.getFullYear();
  const { data } = useLedger({ month, year });

  return useMemo(() => {
    const activeDebts = debts.filter((d) => d.status === "active");
    const creditorSet = new Set(
      activeDebts.map((d) => d.creditor.toLowerCase().trim()),
    );
    const sumOfMins = activeDebts.reduce((s, d) => s + d.minPayment, 0);

    let incomeReceived = 0;
    let expenseActual = 0;
    let debtPaymentsTotal = 0;
    let avalancheActual = 0;

    for (const t of data.transactions) {
      if (t.type === "transfer") continue;
      if (t.type === "income") {
        incomeReceived += Number(t.amount);
        continue;
      }

      const amt = Math.abs(Number(t.amount));
      const cat = (t.category ?? "").toLowerCase().trim();
      const account = accountOf(t.source);

      // Avalanche extras count as debt payments regardless of account.
      if (cat === "avalanche extra") {
        avalancheActual += amt;
        debtPaymentsTotal += amt;
        continue;
      }

      // Only banking outflows whose category matches a known creditor count
      // as a debt payment. Amex purchases are charges, not debt payoffs.
      if (account === "banking" && creditorSet.has(cat)) {
        debtPaymentsTotal += amt;
      } else {
        expenseActual += amt;
      }
    }

    const debtMinsPaid = Math.min(debtPaymentsTotal, sumOfMins);
    const debtExtraPaid = Math.max(0, debtPaymentsTotal - sumOfMins);

    return { incomeReceived, expenseActual, debtMinsPaid, debtExtraPaid, avalancheActual };
  }, [data.transactions, debts]);
}

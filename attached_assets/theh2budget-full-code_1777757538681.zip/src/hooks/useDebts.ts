// React Query hooks for the debts table.
// Reads + writes go through the `debts-api` edge function for a stable
// cloud path that survives transient REST/schema-cache hiccups. We also
// fall back to a direct table read if the function call fails, so the
// page never gets stranded.

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { rowToDebt, type Debt, type DebtStatus } from "@/lib/debtData";

const KEY = ["debts"];

type ApiDebt = {
  id: string;
  creditor: string;
  apr: number;
  balance: number;
  min_payment: number;
  status: string;
  notes: string | null;
  sort_order: number;
  last_balance_update?: string | null;
  statement_day?: number | null;
  due_day?: number | null;
  plaid_item_id?: string | null;
  plaid_account_id?: string | null;
};

async function loadDebts(): Promise<Debt[]> {
  // Primary: cloud edge function. One stable path for the whole page.
  const { data, error } = await supabase.functions.invoke("debts-api", {
    body: { action: "list" },
  });
  if (!error && data?.debts) {
    return (data.debts as ApiDebt[]).map((r) => rowToDebt(r));
  }
  // Fallback: direct table read.
  const direct = await supabase
    .from("debts")
    .select(
      "id, creditor, apr, balance, min_payment, status, notes, sort_order, last_balance_update, statement_day, due_day, plaid_item_id, plaid_account_id",
    )
    .order("apr", { ascending: false })
    .order("balance", { ascending: false });
  if (direct.error) throw error ?? direct.error;
  return (direct.data ?? []).map((r) => rowToDebt(r as any));
}

export function useDebts() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: KEY,
    enabled: ready && !!session?.user.id,
    retry: 1,
    retryDelay: 1500,
    staleTime: 30_000,
    queryFn: loadDebts,
  });

  useEffect(() => {
    if (!ready) return;
    // Unique channel name per mount — multiple components may use this hook
    // simultaneously and Supabase throws if two mounts share a channel name.
    const channelName = `debts-changes-${Math.random().toString(36).slice(2, 10)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "debts" },
        () => qc.invalidateQueries({ queryKey: KEY }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [ready, qc]);

  const callApi = async (action: string, payload: Record<string, unknown>) => {
    const { error } = await supabase.functions.invoke("debts-api", {
      body: { action, payload },
    });
    if (error) throw error;
  };

  const updateDebt = useMutation({
    mutationFn: async (input: Partial<Debt> & { id: string }) => {
      const payload: Record<string, unknown> = { id: input.id };
      if (input.creditor !== undefined) payload.creditor = input.creditor;
      if (input.apr !== undefined) payload.apr = input.apr;
      if (input.balance !== undefined) payload.balance = input.balance;
      if (input.minPayment !== undefined) payload.min_payment = input.minPayment;
      if (input.status !== undefined) payload.status = input.status;
      if (input.notes !== undefined) payload.notes = input.notes ?? null;
      if (input.sortOrder !== undefined) payload.sort_order = input.sortOrder;
      if (input.lastBalanceUpdate !== undefined) {
        payload.last_balance_update = input.lastBalanceUpdate;
      }
      if (input.statementDay !== undefined) {
        payload.statement_day = input.statementDay;
      }
      if (input.dueDay !== undefined) {
        payload.due_day = input.dueDay;
      }
      await callApi("update_debt", payload);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  /**
   * Record a fresh statement balance. Stamps `last_balance_update` so the
   * payment-decrement window restarts from this moment.
   */
  const recordBalance = useMutation({
    mutationFn: async (input: { id: string; balance: number; asOf?: Date }) => {
      const stamp = (input.asOf ?? new Date()).toISOString();
      await callApi("update_debt", {
        id: input.id,
        balance: input.balance,
        last_balance_update: stamp,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const addDebt = useMutation({
    mutationFn: async (input: Omit<Debt, "id" | "sortOrder"> & { sortOrder?: number }) => {
      await callApi("add_debt", {
        creditor: input.creditor,
        apr: input.apr,
        balance: input.balance,
        min_payment: input.minPayment,
        status: input.status,
        notes: input.notes ?? null,
        sort_order: input.sortOrder,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const deleteDebt = useMutation({
    mutationFn: async (id: string) => {
      await callApi("delete_debt", { id });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const setStatus = useMutation({
    mutationFn: async (input: { id: string; status: DebtStatus }) => {
      await callApi("set_status", { id: input.id, status: input.status });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  return {
    debts: query.data ?? [],
    isLoading: query.isLoading,
    error: query.error,
    updateDebt,
    recordBalance,
    addDebt,
    deleteDebt,
    setStatus,
    refetch: query.refetch,
  };
}

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

const KEY = ["forecast_settings"];

export function useForecastSettings() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();
  const uid = session?.user?.id;

  const query = useQuery({
    queryKey: KEY,
    enabled: ready && !!uid,
    staleTime: 30_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("forecast_settings" as any)
        .select("*")
        .eq("user_id", uid!)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as { user_id: string; bank_balance: number; updated_at: string } | null;
    },
  });

  const upsert = useMutation({
    mutationFn: async (bank_balance: number) => {
      const { error } = await supabase
        .from("forecast_settings" as any)
        .upsert({ user_id: uid!, bank_balance } as any, { onConflict: "user_id" });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  return {
    bankBalance: query.data?.bank_balance ?? 0,
    isLoading: query.isLoading,
    setBankBalance: upsert,
  };
}

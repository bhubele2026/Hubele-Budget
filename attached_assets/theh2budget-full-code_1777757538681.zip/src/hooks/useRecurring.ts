// Cloud-backed recurring items for the Forecast page.
// Reads/writes go through the `forecast-api` edge function so the page
// is not stranded by transient PostgREST schema-cache hiccups on the
// direct REST endpoint.

import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { RecurringItem } from "@/lib/forecast";

const KEY = ["recurring_items"];

async function loadItems(): Promise<RecurringItem[]> {
  const { data, error } = await supabase.functions.invoke("forecast-api", {
    body: { action: "list" },
  });
  if (error) throw error;
  const items = (data?.items ?? []) as any[];
  return items.map((r) => ({
    id: r.id,
    kind: r.kind,
    label: r.label,
    amount: Number(r.amount),
    category: r.category ?? null,
    cadence: r.cadence,
    anchor_date: r.anchor_date,
    day_of_month: r.day_of_month ?? null,
    linked_debt_id: r.linked_debt_id ?? null,
    stops_at_payoff: !!r.stops_at_payoff,
    active: !!r.active,
    notes: r.notes ?? null,
  })) as RecurringItem[];
}

async function call(action: string, payload: Record<string, unknown> = {}) {
  const { data, error } = await supabase.functions.invoke("forecast-api", {
    body: { action, payload },
  });
  if (error) throw error;
  return data;
}

export function useRecurring() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: KEY,
    enabled: ready && !!session?.user.id,
    retry: 2,
    retryDelay: (n) => Math.min(4000, 600 * Math.pow(2, n)),
    staleTime: 30_000,
    refetchOnWindowFocus: false,
    queryFn: loadItems,
  });

  // Realtime: any household edit propagates instantly.
  useEffect(() => {
    if (!ready) return;
    // Unique channel name per mount — multiple components may use this hook.
    const channelName = `recurring-items-changes-${Math.random().toString(36).slice(2, 10)}`;
    const ch = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "recurring_items" },
        () => qc.invalidateQueries({ queryKey: KEY }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [ready, qc]);

  const add = useMutation({
    mutationFn: (p: Partial<RecurringItem>) =>
      call("add_item", {
        kind: p.kind ?? "expense",
        label: p.label ?? "New item",
        amount: p.amount ?? 0,
        category: p.category ?? null,
        cadence: p.cadence ?? "monthly",
        anchor_date: p.anchor_date ?? new Date().toISOString().slice(0, 10),
        day_of_month: p.day_of_month ?? null,
        linked_debt_id: p.linked_debt_id ?? null,
        stops_at_payoff: p.stops_at_payoff ?? (p.kind === "debt_min"),
        active: p.active ?? true,
        notes: p.notes ?? null,
        sort_order: 100,
      }),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const update = useMutation({
    mutationFn: (p: Partial<RecurringItem> & { id: string }) =>
      call("update_item", p as any),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const remove = useMutation({
    mutationFn: (id: string) => call("delete_item", { id }),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  return {
    items: query.data ?? [],
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error: query.error as Error | null,
    refetch: query.refetch,
    add,
    update,
    remove,
  };
}

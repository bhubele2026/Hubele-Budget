// Cloud-backed forecast event resolutions + month closeouts.
import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import type { Resolution } from "@/lib/forecastMatch";

const KEY = ["forecast_resolutions"];
const KEY_CLOSEOUTS = ["forecast_month_closeouts"];

async function call(action: string, payload: Record<string, unknown> = {}) {
  const { data, error } = await supabase.functions.invoke("forecast-api", {
    body: { action, payload },
  });
  if (error) throw error;
  return data;
}

export function useForecastResolutions() {
  const { session, ready } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: KEY,
    enabled: ready && !!session?.user.id,
    staleTime: 15_000,
    refetchOnWindowFocus: false,
    queryFn: async () => {
      const data = await call("list_resolutions");
      return (data?.resolutions ?? []) as Resolution[];
    },
  });

  const closeouts = useQuery({
    queryKey: KEY_CLOSEOUTS,
    enabled: ready && !!session?.user.id,
    staleTime: 15_000,
    refetchOnWindowFocus: false,
    queryFn: async () => {
      const data = await call("list_closeouts");
      return ((data?.closeouts ?? []) as { month: string }[]).map((c) => c.month);
    },
  });

  useEffect(() => {
    if (!ready) return;
    const ch = supabase
      .channel("forecast-resolutions")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "forecast_event_resolutions" },
        () => qc.invalidateQueries({ queryKey: KEY }),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "forecast_month_closeouts" },
        () => qc.invalidateQueries({ queryKey: KEY_CLOSEOUTS }),
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [ready, qc]);

  const resolve = useMutation({
    mutationFn: (p: {
      recurring_item_id?: string | null;
      occurrence_date?: string | null;
      status: Resolution["status"];
      matched_txn_id?: string | null;
      notes?: string | null;
    }) => call("resolve_event", p),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const unresolve = useMutation({
    mutationFn: (p: { id?: string; recurring_item_id?: string; occurrence_date?: string; matched_txn_id?: string }) =>
      call("unresolve_event", p),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY }),
  });

  const closeoutMonth = useMutation({
    mutationFn: (month: string) => call("closeout_month", { month }),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY_CLOSEOUTS }),
  });

  const reopenMonth = useMutation({
    mutationFn: (month: string) => call("reopen_month", { month }),
    onSuccess: () => qc.invalidateQueries({ queryKey: KEY_CLOSEOUTS }),
  });

  return {
    resolutions: query.data ?? [],
    closedMonths: new Set(closeouts.data ?? []),
    isLoading: query.isLoading,
    error: query.error as Error | null,
    resolve,
    unresolve,
    closeoutMonth,
    reopenMonth,
    refetch: query.refetch,
  };
}

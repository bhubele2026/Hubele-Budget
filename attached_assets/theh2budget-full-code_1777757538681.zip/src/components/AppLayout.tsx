import { Outlet } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useState } from "react";
import { useSyncDebtMinimums } from "@/hooks/useSyncDebtMinimums";

export default function AppLayout() {
  const [member, setMember] = useState("both");
  useSyncDebtMinimums();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />

        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 flex items-center justify-between border-b border-border px-4 gap-3">
            <div className="flex items-center gap-2">
              <SidebarTrigger />
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground hidden sm:inline">
                Vol. I &middot; No. 04
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Select value={member} onValueChange={setMember}>
                <SelectTrigger className="h-8 w-[130px] text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="both">Both members</SelectItem>
                  <SelectItem value="alex">Alex</SelectItem>
                  <SelectItem value="sam">Sam</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="ghost" size="sm" onClick={() => supabase.auth.signOut()}>
                Sign out
              </Button>
            </div>
          </header>

          <main className="flex-1">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

import { useState, useCallback, useRef, useEffect } from "react";
import { usePlaidLink } from "react-plaid-link";
import { Button } from "@/components/ui/button";
import { Landmark, CreditCard, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { plaidAction } from "@/lib/plaidAction";

interface PlaidConnectProps {
  account?: "banking" | "amex";
}

export default function PlaidConnect({ account = "banking" }: PlaidConnectProps) {
  const qc = useQueryClient();
  const receivedRedirectUri = typeof window !== "undefined" && window.location.href.includes("oauth_state_id=")
    ? window.location.href
    : undefined;
  const [linkToken, setLinkToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const hasOpened = useRef(false);

  const isAmex = account === "amex";

  const startLink = async () => {
    setLoading(true);
    hasOpened.current = false;
    try {
      const res = await plaidAction("create_link_token");
      setLinkToken(res.link_token);
    } catch (e: any) {
      const message = e.message ?? "Could not start bank connection";
      toast.error(message.includes("OAuth redirect URI") ? "Chase needs Plaid OAuth redirect setup before it can connect." : message);
      setLoading(false);
    }
  };

  const onSuccess = useCallback(
    async (publicToken: string, metadata: any) => {
      console.log("[Plaid] onSuccess fired, institution:", metadata?.institution?.name);
      setLoading(true);
      try {
        const exchangeRes = await plaidAction("exchange_token", {
          public_token: publicToken,
          institution_name: metadata?.institution?.name ?? null,
          account,
        });

        // Sync transactions immediately
        const syncRes = await plaidAction("sync_transactions", {
          item_id: exchangeRes.item_id,
          account,
        });

        const imported = syncRes.imported ?? 0;
        if (imported > 0) {
          toast.success(
            `Connected to ${metadata?.institution?.name ?? (isAmex ? "your Amex" : "your bank")}! Imported ${imported} transactions. More may arrive shortly as your bank sends data.`
          );
        } else {
          toast.success(
            `Connected to ${metadata?.institution?.name ?? (isAmex ? "your Amex" : "your bank")}! Initial sync started — transactions will appear automatically as your bank sends data.`
          );
        }
        // Refresh the ledger data
        qc.invalidateQueries({ queryKey: ["ledger"] });
      } catch (e: any) {
        console.error("[Plaid] post-link error:", e);
        toast.error(e.message ?? "Failed to sync transactions");
      } finally {
        setLoading(false);
        setLinkToken(null);
        hasOpened.current = false;
      }
    },
    [qc, account, isAmex]
  );

  const onExit = useCallback((err: any, metadata: any) => {
    console.error("[Plaid] onExit fired", { err, metadata });
    if (err) {
      toast.error(`Plaid error: ${err.display_message || err.error_message || err.error_code || "Unknown error"}`);
    }
    setLinkToken(null);
    setLoading(false);
    hasOpened.current = false;
  }, []);

  const onEvent = useCallback((eventName: string, metadata: any) => {
    console.log("[Plaid] event:", eventName, metadata);
  }, []);

  const { open, ready } = usePlaidLink({
    token: linkToken,
    onSuccess,
    onExit,
    onEvent,
    receivedRedirectUri,
  });

  // Auto-open exactly once when link token is set and hook is ready
  useEffect(() => {
    if (linkToken && ready && !hasOpened.current) {
      hasOpened.current = true;
      open();
    }
  }, [linkToken, ready, open]);

  const Icon = isAmex ? CreditCard : Landmark;

  return (
    <Button
      variant="outline"
      className="gap-2"
      onClick={startLink}
      disabled={loading}
    >
      {loading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Icon className="h-4 w-4" />
      )}
      {isAmex ? "Connect Amex" : "Connect Bank"}
    </Button>
  );
}

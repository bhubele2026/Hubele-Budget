import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

/**
 * Only gates on session presence. Role verification + role errors are surfaced
 * inline by AppLayout so the app shell (sidebar, header) keeps rendering.
 */
export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { session, authReady } = useAuth();

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center text-muted-foreground">
        Loading…
      </div>
    );
  }
  if (!session) return <Navigate to="/auth" replace />;
  return <>{children}</>;
}

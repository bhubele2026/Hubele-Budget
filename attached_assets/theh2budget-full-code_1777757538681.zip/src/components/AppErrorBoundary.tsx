import * as React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface State {
  error: Error | null;
}

export class AppErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error("[AppErrorBoundary]", error, info);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="container py-10 max-w-lg">
          <Card>
            <CardContent className="p-6 flex flex-col items-start gap-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
                <div className="font-semibold">Something went wrong</div>
              </div>
              <p className="text-sm text-muted-foreground break-words">
                {this.state.error.message || "An unexpected error occurred while rendering."}
              </p>
              <Button size="sm" onClick={() => window.location.reload()}>
                Reload app
              </Button>
            </CardContent>
          </Card>
        </div>
      );
    }
    return this.props.children;
  }
}

import { useMemo, useState, useCallback } from "react";
import { CheckCircle2, AlertCircle, HelpCircle, Link2, Sparkles } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { fmtMoney } from "@/lib/budgetData";
import { cn } from "@/lib/utils";
import { findCandidates, suggestMatch, type LineRow, type BankLine, type PlanLine } from "@/lib/forecastMatch";

type Actions = {
  onMatch: (a: LineRow, b: LineRow) => void;
  onMissed: (planRow: PlanLine) => void;
  onNotForecasted: (bankRow: BankLine) => void;
};

export function PlanRegister({ rows, actions, onDropMatch }: {
  rows: LineRow[];
  actions: Actions;
  onDropMatch?: (txnId: string, planRow: PlanLine) => void;
}) {
  // Date de-dup: only show date when it changes
  let prevDate = "";
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent, idx: number, row: LineRow) => {
    if (row.kind !== "plan") return;
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    setDragOverIdx(idx);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent, row: LineRow) => {
    e.preventDefault();
    setDragOverIdx(null);
    if (row.kind !== "plan" || !onDropMatch) return;
    const txnId = e.dataTransfer.getData("application/forecast-txn-id");
    if (txnId) onDropMatch(txnId, row as PlanLine);
  }, [onDropMatch]);

  return (
    <div className="border border-border bg-card rounded-2xl mb-6 overflow-hidden">
      <div className="px-4 py-3 border-b border-border bg-secondary/40 flex items-baseline justify-between">
        <h2 className="font-display text-lg font-semibold">Plan register</h2>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          {rows.length} line{rows.length === 1 ? "" : "s"} · awaiting your call
        </span>
      </div>
      <div className="max-h-[640px] overflow-y-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-card border-b border-border z-10">
            <tr className="text-[10px] uppercase tracking-widest text-muted-foreground">
              <th className="text-left py-2 px-3 w-28">Date</th>
              <th className="text-left py-2 px-3 w-16">Source</th>
              <th className="text-left py-2 px-3">Description</th>
              <th className="text-right py-2 px-3 w-28">Amount</th>
              <th className="text-left py-2 px-3 w-[280px]">Action</th>
              <th className="text-right py-2 px-3 w-28">Balance</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-sm text-muted-foreground italic text-center">
                  Nothing to triage in this window. Reconciled.
                </td>
              </tr>
            )}
            {rows.map((row, idx) => {
              const showDate = row.date !== prevDate;
              prevDate = row.date;
              const dateLabel = showDate
                ? new Date(row.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })
                : "";

              const isBank = row.kind === "bank";
              const isPlanFuture = row.kind === "plan" && row.status === "future";
              const positive = row.amount > 0;

              return (
                <tr
                  key={`${row.kind}-${idx}-${row.date}`}
                  className={cn(
                    "border-b border-border/60 last:border-b-0 hover:bg-accent/5",
                    isPlanFuture && "opacity-70",
                    row.kind === "plan" && dragOverIdx === idx && "bg-orange-100/60 ring-2 ring-orange-400 ring-inset",
                  )}
                  onDragOver={(e) => handleDragOver(e, idx, row)}
                  onDragLeave={() => setDragOverIdx(null)}
                  onDrop={(e) => handleDrop(e, row)}
                >
                  <td className="py-2 px-3 font-mono-num text-xs whitespace-nowrap text-muted-foreground align-top">
                    {dateLabel}
                  </td>
                  <td className="py-2 px-3 align-top">
                    <span
                      className={cn(
                        "inline-block px-1.5 py-0.5 text-[9px] uppercase tracking-widest font-semibold border",
                        isBank
                          ? "border-foreground/40 text-foreground"
                          : "border-accent/60 text-accent",
                      )}
                    >
                      {isBank ? "Bank" : "Plan"}
                    </span>
                  </td>
                  <td className="py-2 px-3 align-top">
                    <div className="truncate max-w-[360px]" title={isBank ? row.txn.description : row.label}>
                      {isBank ? row.txn.description : row.label}
                    </div>
                    {isBank && row.txn.category && (
                      <div className="text-[10px] text-muted-foreground mt-0.5">{row.txn.category}</div>
                    )}
                    {isPlanFuture && (
                      <div className="text-[10px] text-muted-foreground mt-0.5">projected</div>
                    )}
                  </td>
                  <td
                    className={cn(
                      "py-2 px-3 text-right font-mono-num text-xs whitespace-nowrap align-top",
                      positive ? "text-positive" : "",
                      isPlanFuture && "text-muted-foreground",
                    )}
                  >
                    {positive ? "+" : "−"}
                    {fmtMoney(Math.abs(row.amount))}
                  </td>
                  <td className="py-2 px-3 align-top">
                    {isPlanFuture ? (
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground">future</span>
                    ) : (
                      <RowActions row={row} allRows={rows} actions={actions} />
                    )}
                  </td>
                  <td className="py-2 px-3 text-right font-mono-num font-semibold text-xs align-top">
                    {row.runningBalance != null ? fmtMoney(row.runningBalance) : ""}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RowActions({
  row,
  allRows,
  actions,
}: {
  row: LineRow;
  allRows: LineRow[];
  actions: Actions;
}) {
  const [open, setOpen] = useState(false);
  const candidates = open ? findCandidates(row, allRows, 7) : [];

  // AI suggestion for this row
  const suggestion = useMemo(() => suggestMatch(row, allRows), [row, allRows]);

  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      {/* AI suggestion chip */}
      {suggestion && (
        <Button
          size="sm"
          className="h-7 text-xs px-2 gap-1 bg-accent/15 text-accent hover:bg-accent/25 border border-accent/30"
          onClick={() => actions.onMatch(row, suggestion.candidate)}
        >
          <Sparkles className="h-3 w-3" />
          {suggestion.candidate.kind === "plan"
            ? (suggestion.candidate as PlanLine).label
            : (suggestion.candidate as BankLine).txn.description}
          <span className="text-[9px] opacity-70 ml-0.5">
            {fmtMoney(Math.abs(suggestion.candidate.amount))}
          </span>
        </Button>
      )}

      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button size="sm" variant="outline" className="h-7 text-xs px-2 gap-1">
            <Link2 className="h-3 w-3" /> Match
          </Button>
        </PopoverTrigger>
        <PopoverContent align="start" className="w-[340px] p-0">
          <div className="px-3 py-2 border-b text-[10px] uppercase tracking-widest text-muted-foreground">
            Match to {row.kind === "bank" ? "a planned item" : "a bank line"}
          </div>
          <div className="max-h-[260px] overflow-y-auto">
            {candidates.length === 0 ? (
              <div className="px-3 py-4 text-xs text-muted-foreground italic">
                No candidates within ±7 days.
              </div>
            ) : (
              candidates.map((c, i) => {
                const label = c.kind === "bank" ? c.txn.description : c.label;
                const dt = new Date(c.date).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                });
                return (
                  <button
                    key={i}
                    onClick={() => {
                      actions.onMatch(row, c);
                      setOpen(false);
                    }}
                    className="w-full text-left px-3 py-2 text-xs hover:bg-accent/10 border-b last:border-b-0 flex items-center gap-2"
                  >
                    <span className="text-muted-foreground w-12 shrink-0 font-mono-num">{dt}</span>
                    <span className="flex-1 truncate" title={label}>
                      {label}
                    </span>
                    <span
                      className={cn(
                        "font-mono-num shrink-0",
                        c.amount > 0 ? "text-positive" : "",
                      )}
                    >
                      {c.amount > 0 ? "+" : "−"}
                      {fmtMoney(Math.abs(c.amount))}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </PopoverContent>
      </Popover>

      {row.kind === "bank" ? (
        <Button
          size="sm"
          variant="ghost"
          className="h-7 text-xs px-2 gap-1 text-amber-600 hover:text-amber-700"
          onClick={() => actions.onNotForecasted(row)}
        >
          <HelpCircle className="h-3 w-3" /> Not forecasted
        </Button>
      ) : (
        <Button
          size="sm"
          variant="ghost"
          className="h-7 text-xs px-2 gap-1 text-destructive hover:text-destructive"
          onClick={() => actions.onMissed(row)}
        >
          <AlertCircle className="h-3 w-3" /> Missed
        </Button>
      )}
    </div>
  );
}

// keep unused-import quiet
void CheckCircle2;

import { useState } from "react";
import { CheckCircle2, AlertCircle, HelpCircle, CircleDashed, Undo2, Lock, ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fmtMoney } from "@/lib/budgetData";
import { cn } from "@/lib/utils";
import type { BucketEntry } from "@/lib/forecastMatch";

type Tab = "matched" | "missed" | "ignored_unforecasted" | "unplanned";

export function ReviewBucket({
  entries,
  monthKey,
  onMonthChange,
  isClosed,
  onCloseMonth,
  onReopenMonth,
  onUndo,
  onAddToBills,
}: {
  entries: BucketEntry[];
  monthKey: string;       // YYYY-MM
  onMonthChange: (m: string) => void;
  isClosed: boolean;
  onCloseMonth: () => void;
  onReopenMonth: () => void;
  onUndo: (e: BucketEntry) => void;
  onAddToBills: (e: BucketEntry) => void;
}) {
  const [tab, setTab] = useState<Tab>("matched");

  const counts = {
    matched: entries.filter((e) => e.status === "matched").length,
    missed: entries.filter((e) => e.status === "missed").length,
    ignored_unforecasted: entries.filter((e) => e.status === "ignored_unforecasted").length,
    unplanned: entries.filter((e) => e.status === "unplanned").length,
  };
  const visible = entries.filter((e) => e.status === tab);

  const monthLabel = new Date(monthKey + "-01").toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });

  return (
    <div className="border border-border bg-card rounded-2xl mb-6">
      <div className="px-4 py-3 border-b border-border bg-secondary/40 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <h2 className="font-display text-lg font-semibold">Review bucket</h2>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onMonthChange(shiftMonth(monthKey, -1))}
              className="p-1 hover:bg-accent/10 rounded"
              aria-label="Previous month"
            >
              <ChevronLeft className="h-3 w-3" />
            </button>
            <span className="text-xs font-semibold tracking-wide w-32 text-center">{monthLabel}</span>
            <button
              onClick={() => onMonthChange(shiftMonth(monthKey, +1))}
              className="p-1 hover:bg-accent/10 rounded"
              aria-label="Next month"
            >
              <ChevronRight className="h-3 w-3" />
            </button>
          </div>
          {isClosed && (
            <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-muted-foreground border px-1.5 py-0.5">
              <Lock className="h-3 w-3" /> Closed
            </span>
          )}
        </div>
        <div>
          {isClosed ? (
            <Button size="sm" variant="outline" onClick={onReopenMonth} className="h-8 text-xs">
              Reopen {monthLabel}
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={onCloseMonth}
              className="h-8 text-xs"
              disabled={entries.length === 0}
            >
              Close out {monthLabel} →
            </Button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        <TabBtn active={tab === "matched"} onClick={() => setTab("matched")} icon={<CheckCircle2 className="h-3 w-3" />}>
          Matched ({counts.matched})
        </TabBtn>
        <TabBtn active={tab === "missed"} onClick={() => setTab("missed")} icon={<AlertCircle className="h-3 w-3" />}>
          Missed ({counts.missed})
        </TabBtn>
        <TabBtn
          active={tab === "ignored_unforecasted"}
          onClick={() => setTab("ignored_unforecasted")}
          icon={<HelpCircle className="h-3 w-3" />}
        >
          Not forecasted ({counts.ignored_unforecasted})
        </TabBtn>
        <TabBtn
          active={tab === "unplanned"}
          onClick={() => setTab("unplanned")}
          icon={<CircleDashed className="h-3 w-3" />}
        >
          Unplanned ({counts.unplanned})
        </TabBtn>
      </div>

      {/* List */}
      <div className="max-h-[360px] overflow-y-auto">
        {visible.length === 0 ? (
          <div className="px-4 py-8 text-xs text-muted-foreground italic text-center">
            {isClosed ? "This month is closed." : "Nothing here yet."}
          </div>
        ) : (
          <ul>
            {visible.map((e) => (
              <li
                key={e.id}
                className="px-4 py-2 border-b border-border/60 last:border-b-0 flex items-center gap-3 text-sm"
              >
                <span className="font-mono-num text-xs text-muted-foreground w-20 shrink-0">
                  {new Date(e.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                </span>
                <span className="flex-1 truncate" title={e.label}>
                  {e.label || <em className="text-muted-foreground">untitled</em>}
                </span>
                <span
                  className={cn(
                    "font-mono-num text-xs shrink-0 w-24 text-right",
                    e.amount > 0 ? "text-positive" : "",
                  )}
                >
                  {e.amount > 0 ? "+" : "−"}
                  {fmtMoney(Math.abs(e.amount))}
                </span>
                {!isClosed && (
                  <div className="flex items-center gap-1">
                    {e.status === "ignored_unforecasted" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs px-2 gap-1"
                        onClick={() => onAddToBills(e)}
                      >
                        <Plus className="h-3 w-3" /> To Bills
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 text-xs px-2 gap-1 text-muted-foreground"
                      onClick={() => onUndo(e)}
                    >
                      <Undo2 className="h-3 w-3" /> Undo
                    </Button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function TabBtn({
  active,
  onClick,
  icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex-1 px-4 py-2 text-xs uppercase tracking-widest font-semibold flex items-center justify-center gap-1.5 transition-colors",
        active
          ? "bg-foreground text-background"
          : "text-muted-foreground hover:text-foreground",
      )}
    >
      {icon} {children}
    </button>
  );
}

function shiftMonth(m: string, delta: number) {
  const [y, mm] = m.split("-").map(Number);
  const d = new Date(y, mm - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil } from "lucide-react";
import { toast } from "sonner";
import type { Cadence, RecurringItem } from "@/lib/forecast";

const CADENCES: { value: Cadence; label: string }[] = [
  { value: "weekly", label: "Weekly" },
  { value: "biweekly", label: "Bi-weekly" },
  { value: "semimonthly", label: "Semi-monthly (twice a month)" },
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "annual", label: "Annual" },
  { value: "onetime", label: "One-time" },
];

export type RecurringDialogProps = {
  mode: "add" | "edit";
  item?: RecurringItem;
  debts: { id: string; creditor: string }[];
  onSubmit: (p: Partial<RecurringItem>) => Promise<void>;
  triggerLabel?: string;
  /** When set, the dialog uses controlled open state and no built-in trigger. */
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
  /** Prefill values (used when adding from the Forecast unforecasted box). */
  prefill?: Partial<RecurringItem>;
  hideTrigger?: boolean;
};

export function RecurringDialog({
  mode, item, debts, onSubmit, triggerLabel,
  open: controlledOpen, onOpenChange, prefill, hideTrigger,
}: RecurringDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen ?? internalOpen;
  const setOpen = (v: boolean) => { onOpenChange ? onOpenChange(v) : setInternalOpen(v); };

  const seed = prefill ?? item;
  const [kind, setKind] = useState<RecurringItem["kind"]>(seed?.kind ?? "expense");
  const [label, setLabel] = useState(seed?.label ?? "");
  const [amount, setAmount] = useState(seed?.amount?.toString() ?? "");
  const [cadence, setCadence] = useState<Cadence>(seed?.cadence ?? "monthly");
  const [anchor, setAnchor] = useState(seed?.anchor_date ?? new Date().toISOString().slice(0, 10));
  const [day, setDay] = useState(seed?.day_of_month?.toString() ?? "");
  const [linked, setLinked] = useState<string>(seed?.linked_debt_id ?? "");
  const [stops, setStops] = useState(seed?.stops_at_payoff ?? (kind === "debt_min"));

  useEffect(() => { if (kind === "debt_min") setStops(true); }, [kind]);

  // When opening in add-mode with prefill, refresh local state.
  useEffect(() => {
    if (open && mode === "add" && prefill) {
      setKind(prefill.kind ?? "expense");
      setLabel(prefill.label ?? "");
      setAmount(prefill.amount?.toString() ?? "");
      setCadence(prefill.cadence ?? "monthly");
      setAnchor(prefill.anchor_date ?? new Date().toISOString().slice(0, 10));
      setDay(prefill.day_of_month?.toString() ?? "");
      setLinked(prefill.linked_debt_id ?? "");
      setStops(prefill.stops_at_payoff ?? false);
    }
  }, [open, mode, prefill]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {!hideTrigger && (
        <DialogTrigger asChild>
          {mode === "add" ? (
            <Button className="gap-2"><Plus className="h-4 w-4" /> {triggerLabel ?? "Add recurring"}</Button>
          ) : (
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
            </Button>
          )}
        </DialogTrigger>
      )}
      <DialogContent>
        <DialogHeader><DialogTitle>{mode === "add" ? "Add bill or income" : "Edit recurring item"}</DialogTitle></DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label className="text-xs">Type</Label>
            <Select value={kind} onValueChange={(v) => setKind(v as RecurringItem["kind"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="income">Income</SelectItem>
                <SelectItem value="expense">Expense / Bill</SelectItem>
                {kind === "debt_min" && (
                  <SelectItem value="debt_min">Debt minimum payment (auto-synced)</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2 flex items-center gap-2 pt-1">
            <Checkbox
              id="oneoff"
              checked={cadence === "onetime"}
              onCheckedChange={(checked) => setCadence(checked ? "onetime" : "monthly")}
            />
            <Label htmlFor="oneoff" className="text-sm cursor-pointer">One-time / single</Label>
          </div>
          <div className="col-span-2">
            <Label className="text-xs">Label</Label>
            <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="e.g. Mortgage" />
          </div>
          <div>
            <Label className="text-xs">Amount</Label>
            <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          {cadence !== "onetime" && (
            <div>
              <Label className="text-xs">Cadence</Label>
              <Select value={cadence} onValueChange={(v) => setCadence(v as Cadence)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CADENCES.filter((c) => c.value !== "onetime").map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div>
            <Label className="text-xs">{cadence === "onetime" ? "Date" : "First occurrence"}</Label>
            <Input type="date" value={anchor} onChange={(e) => setAnchor(e.target.value)} />
          </div>
          {cadence !== "onetime" && (cadence === "monthly" || cadence === "semimonthly") && (
            <div>
              <Label className="text-xs">Day of month</Label>
              <Input type="number" min="1" max="31" value={day} onChange={(e) => setDay(e.target.value)} placeholder="auto" />
            </div>
          )}
          {kind === "debt_min" && (
            <div className="col-span-2">
              <Label className="text-xs">Linked debt</Label>
              <Select value={linked} onValueChange={setLinked}>
                <SelectTrigger><SelectValue placeholder="Select debt" /></SelectTrigger>
                <SelectContent>
                  {debts.map((d) => <SelectItem key={d.id} value={d.id}>{d.creditor}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="col-span-2 flex items-center gap-3 pt-1">
            <Switch checked={stops} onCheckedChange={setStops} disabled={kind !== "debt_min" && !linked} />
            <Label className="text-xs">Stop after debt is paid off</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={async () => {
            if (!label || !amount) { toast.error("Fill label and amount"); return; }
            await onSubmit({
              kind, label, amount: Number(amount), cadence,
              anchor_date: anchor,
              day_of_month: day ? Number(day) : null,
              linked_debt_id: linked || null,
              stops_at_payoff: stops,
              active: true,
            });
            setOpen(false);
            if (mode === "add") {
              setLabel(""); setAmount(""); setLinked("");
            }
          }}>{mode === "add" ? "Add" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

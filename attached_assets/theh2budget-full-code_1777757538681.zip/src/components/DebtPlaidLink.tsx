import { useState, useCallback, useRef, useEffect } from "react";
import { usePlaidLink } from "react-plaid-link";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Link2, Unlink, Loader2, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { plaidAction } from "@/lib/plaidAction";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import type { Debt } from "@/lib/debtData";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

type PlaidAccount = {
  account_id: string;
  name: string;
  official_name: string | null;
  type: string;
  subtype: string;
  current_balance: number | null;
  minimum_payment: number | null;
};

/** Small inline button to link/unlink a single debt to a Plaid account. */
export function DebtPlaidLinkButton({ debt }: { debt: Debt }) {
  const qc = useQueryClient();
  const [linkToken, setLinkToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPicker, setShowPicker] = useState(false);
  const [accounts, setAccounts] = useState<PlaidAccount[]>([]);
  const [pendingItemId, setPendingItemId] = useState<string | null>(null);
  const hasOpened = useRef(false);

  const isLinked = !!debt.plaidItemId && !!debt.plaidAccountId;

  const startLink = async () => {
    setLoading(true);
    hasOpened.current = false;
    try {
      const res = await plaidAction("create_link_token", {
        products: ["transactions"],
      });
      setLinkToken(res.link_token);
    } catch (e: any) {
      toast.error(e.message ?? "Could not start Plaid connection");
      setLoading(false);
    }
  };

  const onSuccess = useCallback(
    async (publicToken: string, metadata: any) => {
      setLoading(true);
      try {
        const exchangeRes = await plaidAction("exchange_token", {
          public_token: publicToken,
          institution_name: metadata?.institution?.name ?? null,
          account: "debt",
        });
        const itemId = exchangeRes.item_id;
        setPendingItemId(itemId);

        // Fetch accounts for this item
        const acctRes = await plaidAction("get_accounts", { item_id: itemId });
        setAccounts(acctRes.accounts ?? []);
        setShowPicker(true);
      } catch (e: any) {
        toast.error(e.message ?? "Failed to connect");
      } finally {
        setLoading(false);
        setLinkToken(null);
      }
    },
    [],
  );

  const onExit = useCallback(() => {
    setLoading(false);
    setLinkToken(null);
  }, []);

  const { open, ready } = usePlaidLink({
    token: linkToken,
    onSuccess,
    onExit,
  });

  useEffect(() => {
    if (ready && linkToken && !hasOpened.current) {
      hasOpened.current = true;
      open();
    }
  }, [ready, linkToken, open]);

  const pickAccount = async (acct: PlaidAccount) => {
    if (!pendingItemId) return;
    setLoading(true);
    try {
      const { error } = await supabase
        .from("debts")
        .update({
          plaid_item_id: pendingItemId,
          plaid_account_id: acct.account_id,
          balance: Math.abs(acct.current_balance ?? debt.balance),
          ...(acct.minimum_payment != null
            ? { min_payment: acct.minimum_payment }
            : {}),
          last_balance_update: new Date().toISOString(),
        } as any)
        .eq("id", debt.id);
      if (error) throw error;
      toast.success(`Linked ${debt.creditor} to ${acct.name}`);
      qc.invalidateQueries({ queryKey: ["debts"] });
    } catch (e: any) {
      toast.error(e.message ?? "Failed to link account");
    } finally {
      setLoading(false);
      setShowPicker(false);
      setPendingItemId(null);
      setAccounts([]);
    }
  };

  const unlink = async () => {
    setLoading(true);
    try {
      const { error } = await supabase
        .from("debts")
        .update({
          plaid_item_id: null,
          plaid_account_id: null,
        } as any)
        .eq("id", debt.id);
      if (error) throw error;
      toast.success(`Unlinked ${debt.creditor}`);
      qc.invalidateQueries({ queryKey: ["debts"] });
    } catch (e: any) {
      toast.error(e.message ?? "Failed to unlink");
    } finally {
      setLoading(false);
    }
  };

  const fmtMoney = (n: number | null) =>
    n != null
      ? n.toLocaleString("en-US", { style: "currency", currency: "USD" })
      : "—";

  return (
    <>
      <Tooltip>
        <TooltipTrigger asChild>
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          ) : isLinked ? (
            <button
              onClick={unlink}
              className="text-primary hover:text-destructive transition-colors"
              aria-label="Unlink Plaid account"
            >
              <Link2 className="h-4 w-4" />
            </button>
          ) : (
            <button
              onClick={startLink}
              className="text-muted-foreground hover:text-primary transition-colors"
              aria-label="Link to Plaid"
            >
              <Unlink className="h-4 w-4" />
            </button>
          )}
        </TooltipTrigger>
        <TooltipContent>
          {isLinked ? "Connected — click to unlink" : "Link to bank via Plaid"}
        </TooltipContent>
      </Tooltip>

      <Dialog open={showPicker} onOpenChange={setShowPicker}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              Pick account for {debt.creditor}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {accounts.map((a) => (
              <button
                key={a.account_id}
                onClick={() => pickAccount(a)}
                className="w-full text-left p-3 rounded-xl border hover:border-primary hover:bg-primary/5 transition-colors"
              >
                <div className="font-medium">
                  {a.official_name ?? a.name}
                </div>
                <div className="text-sm text-muted-foreground flex gap-4">
                  <span>{a.subtype}</span>
                  <span>Balance: {fmtMoney(a.current_balance)}</span>
                  {a.minimum_payment != null && (
                    <span>Min: {fmtMoney(a.minimum_payment)}</span>
                  )}
                </div>
              </button>
            ))}
            {accounts.length === 0 && (
              <p className="text-sm text-muted-foreground p-4 text-center">
                No accounts found for this connection.
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

/** Header button to sync all linked debt balances at once. */
export function SyncAllDebtBalancesButton() {
  const qc = useQueryClient();
  const [loading, setLoading] = useState(false);

  const sync = async () => {
    setLoading(true);
    try {
      const res = await plaidAction("sync_debt_balances");
      const count = res.updated ?? 0;
      if (count === 0) {
        toast.info("No linked debts to sync");
      } else {
        toast.success(`Updated ${count} debt balance${count > 1 ? "s" : ""}`);
      }
      qc.invalidateQueries({ queryKey: ["debts"] });
    } catch (e: any) {
      toast.error(e.message ?? "Sync failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={sync}
      disabled={loading}
      className="gap-1.5"
    >
      {loading ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : (
        <RefreshCw className="h-3.5 w-3.5" />
      )}
      Sync Balances
    </Button>
  );
}

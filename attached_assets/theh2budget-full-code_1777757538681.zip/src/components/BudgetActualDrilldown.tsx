import { useMemo } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { ArrowRight, Inbox } from "lucide-react";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { fmtMoney, type BudgetLine } from "@/lib/budgetData";
import type { Transaction } from "@/lib/ledgerTypes";
import type { RecurringItem } from "@/lib/forecast";
import {
  getMatchingTransactions,
  sumTransactions,
  signedExpenseAmount,
} from "@/lib/budgetActualMatching";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  line: BudgetLine | null;
  monthLabel: string;
  transactions: Transaction[];
  recurringItems: RecurringItem[];
}

export function BudgetActualDrilldown({
  open,
  onOpenChange,
  line,
  monthLabel,
  transactions,
  recurringItems,
}: Props) {
  const matched = useMemo(() => {
    if (!line) return [];
    return getMatchingTransactions(line, transactions, recurringItems).sort(
      (a, b) => (a.date < b.date ? 1 : -1),
    );
  }, [line, transactions, recurringItems]);

  const kind: "income" | "expense" =
    line?.section === "income" ? "income" : "expense";
  const total = sumTransactions(matched, kind);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[480px] p-0 flex flex-col">
        <SheetHeader className="px-6 pt-6 pb-4 border-b border-border">
          <SheetTitle className="font-display text-xl">
            {line?.label ?? "—"}
          </SheetTitle>
          <SheetDescription className="text-xs uppercase tracking-wider">
            {monthLabel}
          </SheetDescription>
          <div className="pt-3 flex items-baseline justify-between">
            <span className="font-mono-num text-2xl font-semibold text-foreground">
              {fmtMoney(total)}
            </span>
            <span className="text-xs text-muted-foreground">
              {matched.length} {matched.length === 1 ? "transaction" : "transactions"}
            </span>
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto">
          {matched.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center px-8 py-16 text-muted-foreground">
              <Inbox className="h-8 w-8 mb-3 opacity-40" />
              <p className="text-sm">
                No transactions matched this category in {monthLabel}.
              </p>
              <p className="text-xs mt-2 opacity-70">
                Try renaming the budget line, or recategorize transactions on the Banking page.
              </p>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {matched.map((t) => {
                const isIncome = t.type === "income";
                const signed = isIncome
                  ? Math.abs(Number(t.amount))
                  : signedExpenseAmount(t);
                const isCreditRow = !isIncome && signed < 0;
                return (
                  <li
                    key={t.id}
                    className="px-6 py-3 grid grid-cols-[1fr,auto] gap-x-4 gap-y-1 items-baseline"
                  >
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">
                        {t.description || "(no description)"}
                        {isCreditRow && (
                          <span className="ml-2 text-[10px] uppercase tracking-wider text-positive font-semibold">
                            credit
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-muted-foreground uppercase tracking-wider mt-0.5">
                        {formatDate(t.date)} · {t.source}
                      </div>
                    </div>
                    <div
                      className={cn(
                        "font-mono-num text-sm font-semibold tabular-nums",
                        isIncome || isCreditRow ? "text-positive" : "text-foreground",
                      )}
                    >
                      {isIncome ? "+" : isCreditRow ? "−" : ""}
                      {fmtMoney(Math.abs(signed))}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="border-t border-border px-6 py-3">
          <Link
            to="/banking"
            className="text-xs uppercase tracking-wider text-muted-foreground hover:text-foreground inline-flex items-center gap-1.5 transition-colors"
            onClick={() => onOpenChange(false)}
          >
            Open Banking <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function formatDate(d: string): string {
  const [y, m, day] = d.split("-").map(Number);
  if (!y) return d;
  const dt = new Date(y, (m ?? 1) - 1, day ?? 1);
  return dt.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

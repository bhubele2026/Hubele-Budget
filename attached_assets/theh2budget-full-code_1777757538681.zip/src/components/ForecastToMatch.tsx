import { useMemo } from "react";
import { GripVertical, Sparkles, CircleDashed } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fmtMoney } from "@/lib/budgetData";
import { cn } from "@/lib/utils";
import { suggestMatch, type LineRow, type BankLine, type PlanLine } from "@/lib/forecastMatch";
import type { Transaction } from "@/lib/ledgerTypes";

type Props = {
  /** All banking transactions flagged for forecast */
  flaggedTxns: Transaction[];
  /** The plan register rows (for AI suggestion matching) */
  planRows: LineRow[];
  /** IDs of transactions already resolved (matched/ignored) */
  resolvedTxnIds: Set<string>;
  /** Called when user clicks an AI suggestion to auto-match */
  onMatch: (bankRow: BankLine, planRow: PlanLine) => void;
  /** Called when user marks a transaction as unplanned */
  onUnplanned: (bankRow: BankLine) => void;
};

export function ForecastToMatch({ flaggedTxns, planRows, resolvedTxnIds, onMatch, onUnplanned }: Props) {
  // Only show flagged txns that haven't been resolved yet
  const pending = useMemo(
    () => flaggedTxns.filter((t) => !resolvedTxnIds.has(t.id)),
    [flaggedTxns, resolvedTxnIds],
  );

  const pendingTotal = useMemo(
    () => pending.reduce((s, t) => s + Math.abs(Number(t.amount)), 0),
    [pending],
  );

  // Build lightweight BankLine wrappers for suggestion matching
  const bankLines: BankLine[] = useMemo(
    () =>
      pending.map((t) => ({
        kind: "bank" as const,
        date: t.date,
        txn: t,
        amount: t.type === "income" ? Math.abs(t.amount) : -Math.abs(t.amount),
        status: "pending_bank" as const,
      })),
    [pending],
  );

  if (pending.length === 0) return null;

  return (
    <div className="border border-orange-200 bg-card rounded-2xl mb-6 overflow-hidden">
      <div className="px-4 py-3 border-b border-orange-100 bg-orange-50/50 flex items-baseline justify-between">
        <h2 className="font-display text-lg font-semibold flex items-center gap-2">
          <span className="text-orange-500">📋</span> To Match
        </h2>
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
          {pending.length} item{pending.length !== 1 ? "s" : ""} · {fmtMoney(pendingTotal)}
        </span>
      </div>
      <div className="max-h-[280px] overflow-y-auto">
        <ul className="divide-y divide-border">
          {bankLines.map((bl) => (
            <ToMatchRow key={bl.txn.id} bankLine={bl} planRows={planRows} onMatch={onMatch} onUnplanned={onUnplanned} />
          ))}
        </ul>
      </div>
    </div>
  );
}

function ToMatchRow({
  bankLine,
  planRows,
  onMatch,
  onUnplanned,
}: {
  bankLine: BankLine;
  planRows: LineRow[];
  onMatch: (bankRow: BankLine, planRow: PlanLine) => void;
  onUnplanned: (bankRow: BankLine) => void;
}) {
  const suggestion = useMemo(() => suggestMatch(bankLine, planRows), [bankLine, planRows]);
  const d = new Date(bankLine.date + "T00:00:00");
  const dateLabel = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const positive = bankLine.amount > 0;

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData("application/forecast-txn-id", bankLine.txn.id);
    e.dataTransfer.setData("text/plain", bankLine.txn.description);
    e.dataTransfer.effectAllowed = "move";
  };

  return (
    <li
      draggable
      onDragStart={handleDragStart}
      className="flex items-center gap-3 px-4 py-2 text-sm hover:bg-orange-50/30 cursor-grab active:cursor-grabbing"
    >
      <GripVertical className="h-4 w-4 text-muted-foreground/50 shrink-0" />
      <span className="w-16 text-[10px] uppercase tracking-[0.15em] text-muted-foreground shrink-0 font-display">
        {dateLabel}
      </span>
      <span className="flex-1 truncate">{bankLine.txn.description}</span>
      <span className={cn("font-mono-num tabular text-sm w-24 text-right shrink-0", positive && "text-positive")}>
        {positive ? "+" : "−"}{fmtMoney(Math.abs(bankLine.amount))}
      </span>
      <div className="flex items-center gap-1 shrink-0">
        {suggestion && (
          <Button
            size="sm"
            className="h-7 text-xs px-2 gap-1 bg-accent/15 text-accent hover:bg-accent/25 border border-accent/30"
            onClick={() => onMatch(bankLine, suggestion.candidate as PlanLine)}
          >
            <Sparkles className="h-3 w-3" />
            {(suggestion.candidate as PlanLine).label}
          </Button>
        )}
        <Button
          size="sm"
          variant="outline"
          className="h-7 text-xs px-2 gap-1 border-amber-300 text-amber-600 hover:bg-amber-50"
          onClick={() => onUnplanned(bankLine)}
        >
          <CircleDashed className="h-3 w-3" />
          Unplanned
        </Button>
      </div>
    </li>
  );
}

import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Flame,
  ArrowLeftRight,
  CreditCard,
  Receipt,
  Wallet,
  LineChart,
  BarChart3,
  LogOut,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import h2Logo from "@/assets/h2-logo.png";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

const items = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Banking", url: "/banking", icon: ArrowLeftRight },
  { title: "Amex Daily", url: "/amex", icon: CreditCard },
  { title: "Bills", url: "/bills", icon: Receipt },
  { title: "Forecast", url: "/forecast", icon: LineChart },
  { title: "Budget", url: "/budget", icon: Wallet },
  { title: "Avalanche", url: "/debts", icon: Flame },
  { title: "Reports", url: "/reports", icon: BarChart3 },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const { session } = useAuth();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const isActive = (path: string) => (path === "/" ? pathname === "/" : pathname.startsWith(path));

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-2.5 px-2 py-3">
          <img src={h2Logo} alt="H2" className="h-9 w-9 rounded-2xl object-contain bg-white p-0.5 shadow-sm ring-2 ring-accent/30 shrink-0" />
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="font-display font-extrabold text-lg tracking-tight text-brand-gradient">H2</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">Brad + Hannah</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-[10px] uppercase tracking-widest">Sections</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <NavLink to={item.url} end={item.url === "/"} className="flex items-center gap-3">
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border">
        {!collapsed && session?.user.email && (
          <div className="px-2 pt-2 text-[10px] uppercase tracking-widest text-muted-foreground truncate">
            {session.user.email}
          </div>
        )}
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={() => supabase.auth.signOut()}
              tooltip="Sign out"
              className="flex items-center gap-3"
            >
              <LogOut className="h-4 w-4" />
              {!collapsed && <span>Sign out</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

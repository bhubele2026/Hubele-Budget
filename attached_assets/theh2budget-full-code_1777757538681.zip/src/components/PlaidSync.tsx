import { useState } from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw, Loader2, Wrench } from "lucide-react";
import { toast } from "sonner";
import { plaidAction } from "@/lib/plaidAction";
import { useQueryClient } from "@tanstack/react-query";

interface PlaidSyncProps {
  account?: "banking" | "amex";
}

export default function PlaidSync({ account = "banking" }: PlaidSyncProps) {
  const qc = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [repairing, setRepairing] = useState(false);

  const sync = async (resetCursor = false) => {
    setLoading(true);
    try {
      const { items } = await plaidAction("list_items", { account });
      if (!items || items.length === 0) {
        toast.error("No bank connections found. Connect a bank first.");
        return;
      }

      // Only sync the latest connection per institution to avoid duplicate history
      const latestByInstitution = new Map<string, any>();
      for (const item of items) {
        const key = item.institution_name ?? item.item_id;
        const existing = latestByInstitution.get(key);
        if (!existing || new Date(item.created_at) > new Date(existing.created_at)) {
          latestByInstitution.set(key, item);
        }
      }
      const uniqueItems = Array.from(latestByInstitution.values());

      let totalImported = 0;
      let totalUpdated = 0;
      let totalRemoved = 0;
      let totalSkipped = 0;

      for (const item of uniqueItems) {
        if (resetCursor) {
          await plaidAction("reset_cursor", { item_id: item.item_id });
        }
        const res = await plaidAction("sync_transactions", {
          item_id: item.item_id,
          account,
        });
        totalImported += res.imported ?? 0;
        totalUpdated += res.updated ?? 0;
        totalRemoved += res.removed ?? 0;
        totalSkipped += res.skipped ?? 0;
      }

      const parts: string[] = [];
      if (totalImported > 0) parts.push(`${totalImported} new`);
      if (totalUpdated > 0) parts.push(`${totalUpdated} matched`);
      if (totalRemoved > 0) parts.push(`${totalRemoved} removed`);
      if (totalSkipped > 0) parts.push(`${totalSkipped} already synced`);

      if (parts.length > 0) {
        toast.success(`Sync complete: ${parts.join(", ")}`);
      } else {
        toast.info("No new transactions to sync.");
      }
      qc.invalidateQueries({ queryKey: ["ledger"] });
    } catch (e: any) {
      console.error("[PlaidSync] error:", e);
      toast.error(e.message ?? "Failed to sync transactions");
    } finally {
      setLoading(false);
    }
  };

  const repair = async () => {
    setRepairing(true);
    try {
      const source = account === "amex" ? "amex_plaid" : "plaid_import";
      const res = await plaidAction("repair_duplicates", { source });
      if ((res.deleted ?? 0) > 0) {
        toast.success(`Repair complete: merged ${res.merged} groups, removed ${res.deleted} duplicates`);
      } else {
        toast.info("No duplicates found — data looks clean.");
      }
      qc.invalidateQueries({ queryKey: ["ledger"] });
    } catch (e: any) {
      console.error("[PlaidSync] repair error:", e);
      toast.error(e.message ?? "Repair failed");
    } finally {
      setRepairing(false);
    }
  };

  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" className="gap-2" onClick={() => sync(false)} disabled={loading || repairing}>
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
        Sync
      </Button>
      <Button variant="ghost" className="gap-2 text-xs text-muted-foreground" onClick={() => sync(true)} disabled={loading || repairing}>
        Full Re-sync
      </Button>
      <Button variant="ghost" className="gap-2 text-xs text-muted-foreground" onClick={repair} disabled={loading || repairing}>
        {repairing ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wrench className="h-3 w-3" />}
        Fix Dupes
      </Button>
    </div>
  );
}

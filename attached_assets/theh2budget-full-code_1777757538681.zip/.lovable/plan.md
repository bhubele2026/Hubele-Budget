I checked the live data and the code path carefully.

What I found:
- The Ridge Wallet bank transaction is present once in Banking: May 2, $476.81, Forecast unchecked.
- There are zero transactions currently checked for Forecast.
- Ridge Wallet is still appearing in Forecast because a leftover Forecast resolution exists for that transaction:
  - `status = unplanned`
  - `matched_txn_id = Ridge Wallet transaction id`
- The current Forecast code treats any resolution as valid even if the linked bank transaction is no longer Forecast-checked. That is the bug.

Plan:

1. Repair the current bad data
   - Delete the stale Forecast resolution for Ridge Wallet.
   - Verify there are no Forecast resolutions attached to transactions where `forecast_flag = false`.
   - Confirm Ridge Wallet is no longer in the Forecast review bucket.

2. Fix the Forecast logic so unchecked transactions cannot appear in Forecast
   - In the Forecast page, only pass Forecast-checked transactions into the Forecast register and review bucket.
   - This prevents ordinary bank transactions from appearing as bank rows in Forecast.
   - This also prevents unchecked transactions from being counted as unplanned, matched, or not forecasted.

3. Add a safety filter for resolutions
   - Before building the Forecast review bucket, ignore transaction-based resolutions when the linked transaction is not currently Forecast-checked.
   - This makes the UI resilient even if stale data exists from a prior bug or manual repair.

4. Tighten the backend list response
   - Update the Forecast backend function so transaction-enriched resolutions include `forecast_flag`.
   - Optionally filter out transaction-based resolutions whose linked transaction is unchecked, so the client cannot accidentally show stale Forecast rows.

5. Test the full flow after changes
   - Database checks:
     - Ridge Wallet exists in Banking once.
     - Ridge Wallet has `forecast_flag = false`.
     - No resolution exists for Ridge Wallet.
     - No resolutions exist for unchecked transactions.
   - UI checks:
     - Banking still shows Ridge Wallet and Forecast checkbox unchecked.
     - Forecast no longer shows Ridge Wallet in the register or Unplanned bucket.
     - The Forecast flagged count is 0.
     - The bank ending balance remains 0.
   - Regression check:
     - Check a transaction’s Forecast box and confirm it appears in Forecast To Match.
     - Uncheck it and confirm it disappears from Forecast and is not left behind in Unplanned.
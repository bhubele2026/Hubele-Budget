import { Router, type IRouter } from "express";
import { and, eq, sql, asc, desc, lt, inArray, isNull, notInArray } from "drizzle-orm";
import {
  db,
  avalancheSettingsTable,
  budgetCategoriesTable,
  budgetLinesTable,
  budgetMonthsTable,
  debtsTable,
  mappingRulesTable,
  recurringItemsTable,
  settingsTable,
  transactionsTable,
} from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import {
  syncAvalanchePaymentCategory,
  isAvalanchePaymentCategory,
  AVALANCHE_PAYMENT_NAME,
} from "./avalanche";
import {
  CreateCategoryBody,
  DeleteCategoryParams,
  UpdateCategoryBody,
  UpdateCategoryParams,
  GetBudgetMonthParams,
  PinBudgetLineBody,
  PinBudgetMonthBody,
  PinBudgetMonthParams,
  UpsertBudgetLineBody,
} from "@workspace/api-zod";
import {
  BUDGET_CATEGORY_MIGRATION_MAP,
  SEED_CATEGORIES,
  SEED_GROUP_ORDER,
  SEED_MONTH,
  SEED_RECURRING_ITEMS,
  IGNORE_CATEGORY_NAME,
  TRANSFER_CATEGORY_NAME,
  UNCATEGORIZED_CATEGORY_NAME,
} from "../lib/budgetSeed";
import {
  SEED_MAPPING_RULES,
  SEED_MAPPING_PRIORITY,
} from "../lib/mappingSeed";
import { expandItem, parseISO, addDays } from "../lib/cashSignal";

const router: IRouter = Router();

const DEBT_GROUP = "Debt — Minimum Payments";
// Task #690 — dedicated manual bucket on the Budget page for personal
// one-off envelopes that aren't backed by a bill (e.g. "Birthday gifts",
// "Kid's soccer"). Categories with `sourceKind='manual'` and
// `groupName=MY_BUDGET_GROUP` render in a separate card below the
// canonical bill-backed groups. Exported so the same string is reused
// on both the API response and the frontend.
export const MY_BUDGET_GROUP = "My budget";
const DEBT_GROUP_BASE_SORT =
  (SEED_GROUP_ORDER.indexOf(DEBT_GROUP) >= 0
    ? SEED_GROUP_ORDER.indexOf(DEBT_GROUP)
    : 99) * 100;

// Keep budget_categories with sourceKind='auto_debts' in sync with the user's
// active rows in the Debts tracker, and keep the budget line for each one
// updated to the debt's current minimum payment for the requested month.
// Also backfills `category_id` on existing "Payment — <debt name>" transactions
// so the budget's Actual column reflects payments made to each debt.
async function syncAutoDebtCategories(
  householdId: string,
  userId: string,
  monthStart: string,
): Promise<void> {
  const debts = await db
    .select()
    .from(debtsTable)
    .where(
      and(eq(debtsTable.householdId, householdId), eq(debtsTable.status, "active")),
    )
    .orderBy(desc(debtsTable.apr), asc(debtsTable.name));

  const activeIds = debts.map((d) => d.id);

  // 1. Drop stale auto_debts categories: legacy placeholder/seed rows with no
  //    debt link, plus any whose linked debt is no longer active/exists.
  await db
    .delete(budgetCategoriesTable)
    .where(
      and(
        eq(budgetCategoriesTable.householdId, householdId),
        eq(budgetCategoriesTable.sourceKind, "auto_debts"),
        isNull(budgetCategoriesTable.debtId),
      ),
    );
  if (activeIds.length > 0) {
    await db
      .delete(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.householdId, householdId),
          eq(budgetCategoriesTable.sourceKind, "auto_debts"),
          notInArray(budgetCategoriesTable.debtId, activeIds),
        ),
      );
  } else {
    await db
      .delete(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.householdId, householdId),
          eq(budgetCategoriesTable.sourceKind, "auto_debts"),
        ),
      );
  }

  if (debts.length === 0) return;

  // 2. Ensure the budget month row exists so we can attach lines to it.
  await db
    .insert(budgetMonthsTable)
    .values({ userId, householdId, monthStart })
    .onConflictDoNothing();

  // 3. Upsert one auto_debts category per active debt and the matching line
  //    for the requested month with planned = debt.minPayment.
  const existingCats = await db
    .select()
    .from(budgetCategoriesTable)
    .where(
      and(
        eq(budgetCategoriesTable.householdId, householdId),
        eq(budgetCategoriesTable.sourceKind, "auto_debts"),
      ),
    );
  const catByDebtId = new Map(existingCats.map((c) => [c.debtId!, c]));

  for (let i = 0; i < debts.length; i++) {
    const d = debts[i]!;
    const sortOrder = DEBT_GROUP_BASE_SORT + i;
    let catId: string;
    const cur = catByDebtId.get(d.id);
    if (!cur) {
      const [row] = await db
        .insert(budgetCategoriesTable)
        .values({
          userId,
          householdId,
          name: d.name,
          kind: "expense",
          groupName: DEBT_GROUP,
          sourceKind: "auto_debts",
          sortOrder,
          debtId: d.id,
        })
        .onConflictDoNothing({
          target: [budgetCategoriesTable.householdId, budgetCategoriesTable.debtId],
        })
        .returning();
      if (!row) {
        // Re-read in case of a concurrent insert.
        const [existing] = await db
          .select()
          .from(budgetCategoriesTable)
          .where(
            and(
              eq(budgetCategoriesTable.householdId, householdId),
              eq(budgetCategoriesTable.debtId, d.id),
            ),
          );
        if (!existing) continue;
        catId = existing.id;
      } else {
        catId = row.id;
      }
    } else {
      catId = cur.id;
      if (
        cur.name !== d.name ||
        cur.sortOrder !== sortOrder ||
        cur.groupName !== DEBT_GROUP ||
        cur.kind !== "expense"
      ) {
        await db
          .update(budgetCategoriesTable)
          .set({
            name: d.name,
            sortOrder,
            groupName: DEBT_GROUP,
            kind: "expense",
          })
          .where(eq(budgetCategoriesTable.id, cur.id));
      }
    }

    await db
      .insert(budgetLinesTable)
      .values({
        userId,
        householdId,
        monthStart,
        categoryId: catId,
        plannedAmount: d.minPayment,
        note: "Auto-pulled from Debt Tracker",
      })
      .onConflictDoUpdate({
        target: [
          budgetLinesTable.householdId,
          budgetLinesTable.monthStart,
          budgetLinesTable.categoryId,
        ],
        set: { plannedAmount: d.minPayment },
      });

    // Backfill categoryId on payment transactions created by /debts/:id/payments
    // so the budget's Actual column shows what's been paid this month.
    await db
      .update(transactionsTable)
      .set({ categoryId: catId })
      .where(
        and(
          eq(transactionsTable.householdId, householdId),
          isNull(transactionsTable.categoryId),
          sql`${transactionsTable.description} LIKE ${`Payment — ${d.name}%`}`,
        ),
      );
  }
}

// Group name used for auto-pulled budget lines that are created on the fly
// from recurring bills/income that the user added (e.g. via Forecast Review's
// "Add as bill" flow) without picking an existing budget category. These
// lines auto-track the recurring item's monthly total — editing the bill
// updates the budget line.
const RECURRING_BILLS_GROUP = "Recurring Bills";
const RECURRING_INCOME_GROUP = "Income";
const RECURRING_AUTO_BASE_SORT = 9000;

// Ensure every active recurring INCOME item is linked to an `auto_bills`
// budget category so paychecks/other income flow into the Budget page
// automatically. Expense bills are intentionally NOT auto-categorized —
// the user assigns each expense bill to one of the curated manual
// categories (Utilities, Insurance, Car Payments, etc.) on the Bills page,
// and the Budget page rolls those amounts up into the linked category.
// This avoids the duplicate-row problem where every bill spawned its own
// "Recurring Bills" entry alongside the user's existing envelopes.
// One-time, idempotent data heal for users whose recurring expense bills
// were previously linked to per-bill `auto_bills` expense categories
// (the old "Recurring Bills" group). Re-points each known bill name to
// the appropriate manual category, then deletes any auto_bills EXPENSE
// category that no longer has an active recurring item linked to it.
// Safe to run on every request: each step short-circuits when there is
// nothing to do.
const BILL_NAME_TO_MANUAL_CATEGORY: Readonly<Record<string, string>> = {
  "Water/Sewer": "Utilities",
  "MGE Electric & Gas": "Utilities",
  "Verizon Wireless": "Utilities",
  "State Farm Insurance": "Insurance",
  "State Farm": "Insurance",
  "TruStage / Ethos": "Insurance",
  "Toyota Lease": "Car Payments",
  "Hannah's Car (UW Credit Union)": "Car Payments",
  "Kwik Trip / gas": "Gas, Maintenance & Parking",
  "PlayStation Network": "Subscriptions",
  "Dog Waste Removal": "Pets",
};

// In-process per-user gates for the idempotent corrective passes below.
// Each pass is a one-time backfill — running it once per process boot per
// user is sufficient. Without this, every GET /api/budget/months/:m re-scanned
// every category + recurring item for the user, adding ~1.5s of pointless
// DB churn to a hot path that the dashboard hits twice per page load.
const HEAL_BILL_LINKS_DONE = new Set<string>();
const ENSURE_UNCATEGORIZED_DONE = new Set<string>();
const ENSURE_TRANSFER_DONE = new Set<string>();
const ENSURE_IGNORE_DONE = new Set<string>();

async function healLegacyRecurringBillLinks(householdId: string): Promise<void> {
  if (HEAL_BILL_LINKS_DONE.has(householdId)) return;
  // Step 1: relink known bill names to their manual category if such a
  // category exists for this household. No-op if the recurring item is already
  // linked to the right category.
  const billNames = Object.keys(BILL_NAME_TO_MANUAL_CATEGORY);
  const targetNames = Array.from(
    new Set(Object.values(BILL_NAME_TO_MANUAL_CATEGORY)),
  );

  const cats = await db
    .select({
      id: budgetCategoriesTable.id,
      name: budgetCategoriesTable.name,
      sourceKind: budgetCategoriesTable.sourceKind,
      kind: budgetCategoriesTable.kind,
    })
    .from(budgetCategoriesTable)
    .where(eq(budgetCategoriesTable.householdId, householdId));
  const manualByName = new Map<string, string>();
  for (const c of cats) {
    if (c.sourceKind === "manual" && targetNames.includes(c.name)) {
      manualByName.set(c.name, c.id);
    }
  }

  const items = await db
    .select()
    .from(recurringItemsTable)
    .where(eq(recurringItemsTable.householdId, householdId));
  for (const item of items) {
    if (!billNames.includes(item.name)) continue;
    const targetCatName = BILL_NAME_TO_MANUAL_CATEGORY[item.name]!;
    const targetCatId = manualByName.get(targetCatName);
    if (!targetCatId) continue;
    if (item.categoryId === targetCatId) continue;
    await db
      .update(recurringItemsTable)
      .set({ categoryId: targetCatId })
      .where(
        and(
          eq(recurringItemsTable.id, item.id),
          eq(recurringItemsTable.householdId, householdId),
        ),
      );
  }

  // Step 2: cascade-delete any auto_bills EXPENSE category for this household
  // that has no active recurring item still linked to it. Income auto_bills
  // categories (paychecks) are preserved.
  const autoExpenseCats = cats.filter(
    (c) => c.sourceKind === "auto_bills" && c.kind === "expense",
  );
  if (autoExpenseCats.length === 0) {
    HEAL_BILL_LINKS_DONE.add(householdId);
    return;
  }

  const stillLinked = new Set<string>();
  const refreshedItems = await db
    .select({
      categoryId: recurringItemsTable.categoryId,
      active: recurringItemsTable.active,
    })
    .from(recurringItemsTable)
    .where(eq(recurringItemsTable.householdId, householdId));
  for (const r of refreshedItems) {
    if (r.active === "true" && r.categoryId) stillLinked.add(r.categoryId);
  }

  const orphans = autoExpenseCats
    .filter((c) => !stillLinked.has(c.id))
    .map((c) => c.id);
  if (orphans.length === 0) {
    HEAL_BILL_LINKS_DONE.add(householdId);
    return;
  }

  await db
    .delete(budgetLinesTable)
    .where(
      and(
        eq(budgetLinesTable.householdId, householdId),
        inArray(budgetLinesTable.categoryId, orphans),
      ),
    );
  await db
    .update(transactionsTable)
    .set({ categoryId: null })
    .where(
      and(
        eq(transactionsTable.householdId, householdId),
        inArray(transactionsTable.categoryId, orphans),
      ),
    );
  await db
    .delete(mappingRulesTable)
    .where(
      and(
        eq(mappingRulesTable.householdId, householdId),
        inArray(mappingRulesTable.categoryId, orphans),
      ),
    );
  await db
    .delete(budgetCategoriesTable)
    .where(
      and(
        eq(budgetCategoriesTable.householdId, householdId),
        inArray(budgetCategoriesTable.id, orphans),
      ),
    );
  HEAL_BILL_LINKS_DONE.add(householdId);
}

async function syncAutoBillsFromRecurring(
  householdId: string,
  userId: string,
): Promise<void> {
  const items = (
    await db
      .select()
      .from(recurringItemsTable)
      .where(
        and(
          eq(recurringItemsTable.householdId, householdId),
          eq(recurringItemsTable.active, "true"),
        ),
      )
  ).filter((i) => i.kind === "income");
  if (items.length === 0) return;

  // A recurring item needs an auto category when it has no categoryId, OR
  // its categoryId points to a category that no longer exists (orphaned).
  const linkedIds = Array.from(
    new Set(
      items
        .map((i) => i.categoryId)
        .filter((id): id is string => typeof id === "string"),
    ),
  );
  const validIds = new Set<string>();
  if (linkedIds.length > 0) {
    const found = await db
      .select({ id: budgetCategoriesTable.id })
      .from(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.householdId, householdId),
          inArray(budgetCategoriesTable.id, linkedIds),
        ),
      );
    for (const r of found) validIds.add(r.id);
  }
  const needsCategory = items.filter(
    (i) => !i.categoryId || !validIds.has(i.categoryId),
  );
  if (needsCategory.length === 0) return;

  // Existing categories indexed by name so we can reuse one if a category
  // with the same name already exists (avoids unique-constraint conflicts
  // when a user re-adds a bill they previously linked manually).
  const existingByName = new Map<string, { id: string; sourceKind: string }>();
  {
    const all = await db
      .select({
        id: budgetCategoriesTable.id,
        name: budgetCategoriesTable.name,
        sourceKind: budgetCategoriesTable.sourceKind,
      })
      .from(budgetCategoriesTable)
      .where(eq(budgetCategoriesTable.householdId, householdId));
    for (const c of all) existingByName.set(c.name, c);
  }

  let nextSort = RECURRING_AUTO_BASE_SORT;
  for (const item of needsCategory) {
    const existing = existingByName.get(item.name);
    let categoryId: string;
    if (existing) {
      categoryId = existing.id;
    } else {
      const isIncome = item.kind === "income";
      const [row] = await db
        .insert(budgetCategoriesTable)
        .values({
          userId,
          householdId,
          name: item.name,
          kind: isIncome ? "income" : "expense",
          groupName: isIncome ? RECURRING_INCOME_GROUP : RECURRING_BILLS_GROUP,
          sourceKind: "auto_bills",
          sortOrder: nextSort++,
        })
        .onConflictDoNothing({
          target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
        })
        .returning({ id: budgetCategoriesTable.id });
      if (row) {
        categoryId = row.id;
      } else {
        // Concurrent insert raced us — re-read.
        const [reread] = await db
          .select({ id: budgetCategoriesTable.id })
          .from(budgetCategoriesTable)
          .where(
            and(
              eq(budgetCategoriesTable.householdId, householdId),
              eq(budgetCategoriesTable.name, item.name),
            ),
          );
        if (!reread) continue;
        categoryId = reread.id;
      }
      existingByName.set(item.name, { id: categoryId, sourceKind: "auto_bills" });
    }

    await db
      .update(recurringItemsTable)
      .set({ categoryId })
      .where(
        and(
          eq(recurringItemsTable.id, item.id),
          eq(recurringItemsTable.householdId, householdId),
        ),
      );
  }
}

// One-time per-user consolidation of the legacy ~45-category budget seed
// into the new ~22-category list (task #65). Idempotent: gated by a flag in
// `settings.preferences.budgetCategoriesV2`. Re-runs are safe — the mapping
// is applied only when an old category still exists.
//
// For each old → new mapping:
//   - Find/create the new target category (matching the new SEED metadata)
//   - Sum old budget_lines.planned_amount into the new line per month
//   - Re-point transactions.category_id, recurring_items.category_id,
//     mapping_rules.category_id, and avalanche_settings.extra_budget_category_id
//   - Delete the old category
// For categories that stay (same name), we also refresh group_name and
// sort_order to match the new seed so the UI groups them correctly.
async function migrateBudgetCategoriesV2(
  householdId: string,
  householdOwnerId: string,
  userId: string,
): Promise<void> {
  // Check the flag first.
  const [s] = await db
    .select()
    .from(settingsTable)
    .where(eq(settingsTable.userId, householdOwnerId));
  const prefs = (s?.preferences as Record<string, unknown> | null) ?? null;
  if (prefs && prefs.budgetCategoriesV2 === true) return;

  await db.transaction(async (tx) => {
    const cats = await tx
      .select()
      .from(budgetCategoriesTable)
      .where(eq(budgetCategoriesTable.householdId, householdId));
    const byName = new Map(cats.map((c) => [c.name, c]));

    // Build sortOrder lookup from the new seed.
    const sortOrderByGroup = new Map<string, number>();
    SEED_GROUP_ORDER.forEach((g, i) => sortOrderByGroup.set(g, i * 100));
    const seedByName = new Map(SEED_CATEGORIES.map((s) => [s.name, s]));
    const seedIndex = new Map(SEED_CATEGORIES.map((s, i) => [s.name, i]));

    // Helper: find or create the new target category by name with seed metadata.
    const ensureCategory = async (newName: string) => {
      let cur = byName.get(newName);
      if (cur) return cur;
      const seed = seedByName.get(newName);
      const groupName = seed?.groupName ?? "Other";
      const kind = seed?.kind ?? "expense";
      const sourceKind = seed?.sourceKind ?? "manual";
      const groupBase = sortOrderByGroup.get(groupName) ?? 9999;
      const sortOrder = groupBase + (seedIndex.get(newName) ?? 0);
      const [row] = await tx
        .insert(budgetCategoriesTable)
        .values({
          userId,
          householdId,
          name: newName,
          kind,
          groupName,
          sourceKind,
          sortOrder,
        })
        .onConflictDoUpdate({
          target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
          set: { groupName, sortOrder },
        })
        .returning();
      if (row) byName.set(row.name, row);
      return row!;
    };

    // 1. Process every old → new mapping where the old category still exists.
    for (const [oldName, newName] of Object.entries(
      BUDGET_CATEGORY_MIGRATION_MAP,
    )) {
      const oldCat = byName.get(oldName);
      if (!oldCat) continue;
      if (oldName === newName) continue;
      const newCat = await ensureCategory(newName);
      if (!newCat || newCat.id === oldCat.id) continue;

      // Re-point references on tables that hold category_id.
      await tx
        .update(transactionsTable)
        .set({ categoryId: newCat.id })
        .where(
          and(
            eq(transactionsTable.householdId, householdId),
            eq(transactionsTable.categoryId, oldCat.id),
          ),
        );

      await tx
        .update(recurringItemsTable)
        .set({ categoryId: newCat.id })
        .where(
          and(
            eq(recurringItemsTable.householdId, householdId),
            eq(recurringItemsTable.categoryId, oldCat.id),
          ),
        );

      await tx
        .update(mappingRulesTable)
        .set({ categoryId: newCat.id })
        .where(
          and(
            eq(mappingRulesTable.householdId, householdId),
            eq(mappingRulesTable.categoryId, oldCat.id),
          ),
        );

      await tx
        .update(avalancheSettingsTable)
        .set({ extraBudgetCategoryId: newCat.id })
        .where(
          and(
            eq(avalancheSettingsTable.userId, householdOwnerId),
            eq(avalancheSettingsTable.extraBudgetCategoryId, oldCat.id),
          ),
        );

      // Merge budget_lines: sum planned_amount per month into the new
      // category's line. We rely on the unique (householdId, monthStart, categoryId)
      // index — for each month where both old and new lines exist we sum then
      // delete the old; where only old exists we re-point it.
      const oldLines = await tx
        .select()
        .from(budgetLinesTable)
        .where(
          and(
            eq(budgetLinesTable.householdId, householdId),
            eq(budgetLinesTable.categoryId, oldCat.id),
          ),
        );

      for (const ol of oldLines) {
        const [existingNewLine] = await tx
          .select()
          .from(budgetLinesTable)
          .where(
            and(
              eq(budgetLinesTable.householdId, householdId),
              eq(budgetLinesTable.monthStart, ol.monthStart),
              eq(budgetLinesTable.categoryId, newCat.id),
            ),
          );

        if (existingNewLine) {
          const summed = (
            (parseFloat(existingNewLine.plannedAmount) || 0) +
            (parseFloat(ol.plannedAmount) || 0)
          ).toFixed(2);
          const mergedNote =
            existingNewLine.note && ol.note && existingNewLine.note !== ol.note
              ? `${existingNewLine.note} · ${ol.note}`
              : existingNewLine.note ?? ol.note ?? null;
          await tx
            .update(budgetLinesTable)
            .set({ plannedAmount: summed, note: mergedNote })
            .where(eq(budgetLinesTable.id, existingNewLine.id));
          await tx
            .delete(budgetLinesTable)
            .where(eq(budgetLinesTable.id, ol.id));
        } else {
          await tx
            .update(budgetLinesTable)
            .set({ categoryId: newCat.id })
            .where(eq(budgetLinesTable.id, ol.id));
        }
      }

      // Finally delete the old, now-orphan category row.
      await tx
        .delete(budgetCategoriesTable)
        .where(eq(budgetCategoriesTable.id, oldCat.id));
      byName.delete(oldName);
    }

    // 2. Refresh group_name / sort_order on every category whose name matches
    //    the new seed (covers categories that stayed but moved groups).
    for (const seed of SEED_CATEGORIES) {
      const cur = byName.get(seed.name);
      if (!cur) continue;
      const groupBase = sortOrderByGroup.get(seed.groupName) ?? 9999;
      const sortOrder = groupBase + (seedIndex.get(seed.name) ?? 0);
      if (cur.groupName !== seed.groupName || cur.sortOrder !== sortOrder) {
        await tx
          .update(budgetCategoriesTable)
          .set({ groupName: seed.groupName, sortOrder })
          .where(eq(budgetCategoriesTable.id, cur.id));
      }
    }

    // 3. Set the flag so this only runs once per household.
    const nextPrefs = { ...(prefs ?? {}), budgetCategoriesV2: true };
    if (s) {
      await tx
        .update(settingsTable)
        .set({ preferences: nextPrefs })
        .where(eq(settingsTable.userId, householdOwnerId));
    } else {
      await tx
        .insert(settingsTable)
        .values({ userId: householdOwnerId, householdId, preferences: nextPrefs })
        .onConflictDoUpdate({
          target: settingsTable.userId,
          set: { preferences: nextPrefs },
        });
    }
  });
}

// One-time per-user reconciliation of the May 2026 budget planned amounts to
// the user's canonical source-of-truth values (task #106). Idempotent: gated
// by `settings.preferences.budgetMay2026AmountsV1`.
//
// For each consolidated category in the table, upsert the budget_lines row
// for 2026-05-01 with the listed planned amount. Auto-pulled rows
// (paychecks via Bills, debt minimums via the Debt Tracker) are only written
// when the existing planned amount differs from canonical, so we don't fight
// the auto-sync logic. Also sets avalanche_settings.manualExtra = 6225.00 and
// re-syncs the managed Avalanche payment line.
const MAY_2026_CANONICAL_PLANNED: Record<string, string> = {
  "Hannah's paycheck (Exact)": "4499.99",
  "Brad's paycheck (KFI)": "8100.00",
  "Other Income": "88.00",
  "Mortgage (Lakeview)": "1989.81",
  "HELOC (Figure)": "677.40",
  "Utilities": "774.24",
  "Home Maintenance & Warranty": "53.85",
  "Health": "0",
  "Insurance": "345.13",
  "Groceries": "460.00",
  "Dining & Coffee": "460.00",
  "Car Payments": "1324.35",
  "Gas, Maintenance & Parking": "250.00",
  "Childcare & Activities": "0",
  "Pets": "0",
  "Subscriptions": "315.62",
  "Shopping": "0",
  "Entertainment": "0",
  "Charitable Giving & Education": "0",
  "Misc / Buffer": "237.58",
  "Emergency Fund": "0",
  "Investments & Retirement": "0",
  "Kids' Savings / 529": "0",
  "Tax Sinking Fund": "0",
};
const MAY_2026_MONTH = "2026-05-01";
const MAY_2026_AVALANCHE_MANUAL_EXTRA = "6225.00";

async function reconcileMay2026Amounts(
  householdId: string,
  householdOwnerId: string,
  userId: string,
): Promise<void> {
  const [s] = await db
    .select()
    .from(settingsTable)
    .where(eq(settingsTable.userId, householdOwnerId));
  const prefs = (s?.preferences as Record<string, unknown> | null) ?? null;
  if (prefs && prefs.budgetMay2026AmountsV1 === true) return;

  await db.transaction(async (tx) => {
    const cats = await tx
      .select()
      .from(budgetCategoriesTable)
      .where(eq(budgetCategoriesTable.householdId, householdId));
    const byName = new Map(cats.map((c) => [c.name, c]));

    await tx
      .insert(budgetMonthsTable)
      .values({ userId, householdId, monthStart: MAY_2026_MONTH })
      .onConflictDoNothing();

    for (const [catName, canonical] of Object.entries(
      MAY_2026_CANONICAL_PLANNED,
    )) {
      const cat = byName.get(catName);
      if (!cat) continue;
      const isAuto = cat.sourceKind === "auto_bills" || cat.sourceKind === "auto_debts";

      const [existing] = await tx
        .select()
        .from(budgetLinesTable)
        .where(
          and(
            eq(budgetLinesTable.householdId, householdId),
            eq(budgetLinesTable.monthStart, MAY_2026_MONTH),
            eq(budgetLinesTable.categoryId, cat.id),
          ),
        );

      // For auto-pulled rows, leave alone if already canonical so we don't
      // fight the auto-sync that will re-write these on the next request.
      if (
        isAuto &&
        existing &&
        parseFloat(existing.plannedAmount) === parseFloat(canonical)
      ) {
        continue;
      }

      await tx
        .insert(budgetLinesTable)
        .values({
          userId,
          householdId,
          monthStart: MAY_2026_MONTH,
          categoryId: cat.id,
          plannedAmount: canonical,
          pinned: isAuto,
        })
        .onConflictDoUpdate({
          target: [
            budgetLinesTable.householdId,
            budgetLinesTable.monthStart,
            budgetLinesTable.categoryId,
          ],
          set: isAuto
            ? { plannedAmount: canonical, pinned: true }
            : { plannedAmount: canonical },
        });
    }

    // Mark May 2026 as a pinned month so the per-line pinned flag is
    // unambiguous — the response builder uses either signal to prefer the
    // persisted budget_lines value over the live derivation. (task #115)
    await tx
      .update(budgetMonthsTable)
      .set({ pinned: true })
      .where(
        and(
          eq(budgetMonthsTable.householdId, householdId),
          eq(budgetMonthsTable.monthStart, MAY_2026_MONTH),
        ),
      );

    // Upsert avalanche manualExtra to the canonical $6,225.00 for this household.
    // Use ON CONFLICT to be safe against concurrent reconciles racing the
    // initial INSERT (the dashboard fires multiple parallel month requests).
    await tx
      .insert(avalancheSettingsTable)
      .values({
        userId: householdOwnerId,
        householdId,
        manualExtra: MAY_2026_AVALANCHE_MANUAL_EXTRA,
      })
      .onConflictDoUpdate({
        target: avalancheSettingsTable.userId,
        set: {
          manualExtra: MAY_2026_AVALANCHE_MANUAL_EXTRA,
          updatedAt: new Date(),
        },
      });

    const nextPrefs = { ...(prefs ?? {}), budgetMay2026AmountsV1: true };
    if (s) {
      await tx
        .update(settingsTable)
        .set({ preferences: nextPrefs })
        .where(eq(settingsTable.userId, householdOwnerId));
    } else {
      await tx
        .insert(settingsTable)
        .values({ userId: householdOwnerId, householdId, preferences: nextPrefs })
        .onConflictDoUpdate({
          target: settingsTable.userId,
          set: { preferences: nextPrefs },
        });
    }
  });

  // Re-sync the managed Avalanche payment line to reflect the new manualExtra.
  await syncAvalanchePaymentCategory(householdId, householdOwnerId, MAY_2026_MONTH);
}

// (#474) Idempotently ensure the system-managed "Uncategorized" category
// exists for the user. Picked on Transactions/Chase/Amex to mark a row as
// triaged without contaminating budget math. Stored with
// `exclude_from_budget=true` so the Budget page filters it out of every
// roll-up (planned, actual, group, summary) — same way transfers are
// excluded from actuals. Idempotent via the (userId, name) unique index;
// also self-heals legacy rows that pre-date the flag by flipping it on.
async function ensureUncategorizedCategory(
  householdId: string,
  userId: string,
): Promise<void> {
  if (ENSURE_UNCATEGORIZED_DONE.has(householdId)) return;
  const sortOrderByGroup = new Map<string, number>();
  SEED_GROUP_ORDER.forEach((g, i) => sortOrderByGroup.set(g, i * 100));
  // Park it well after the canonical groups so any debug surface that
  // ignores `exclude_from_budget` still renders it last.
  const sortOrder = (SEED_GROUP_ORDER.length + 10) * 100;
  await db
    .insert(budgetCategoriesTable)
    .values({
      userId,
      householdId,
      name: UNCATEGORIZED_CATEGORY_NAME,
      kind: "expense",
      groupName: UNCATEGORIZED_CATEGORY_NAME,
      sourceKind: "manual",
      sortOrder,
      excludeFromBudget: true,
    })
    .onConflictDoUpdate({
      target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
      set: { excludeFromBudget: true },
    });
  ENSURE_UNCATEGORIZED_DONE.add(householdId);
}

// (#607) Mirror of `ensureUncategorizedCategory` for the system-managed
// "Transfer" category. Picked on a transaction's category picker to
// classify the row as an internal transfer without contaminating budget
// math. Stored with `exclude_from_budget=true` so the Budget page filters
// it out of every roll-up. Idempotent via the (userId, name) unique
// index; also self-heals legacy rows by flipping the flag on.
async function ensureTransferCategory(
  householdId: string,
  userId: string,
): Promise<void> {
  if (ENSURE_TRANSFER_DONE.has(householdId)) return;
  // Park it well after the canonical groups so any debug surface that
  // ignores `exclude_from_budget` still renders it last (one slot after
  // the Uncategorized row).
  const sortOrder = (SEED_GROUP_ORDER.length + 11) * 100;
  await db
    .insert(budgetCategoriesTable)
    .values({
      userId,
      householdId,
      name: TRANSFER_CATEGORY_NAME,
      kind: "expense",
      groupName: TRANSFER_CATEGORY_NAME,
      sourceKind: "manual",
      sortOrder,
      excludeFromBudget: true,
    })
    .onConflictDoUpdate({
      target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
      set: { excludeFromBudget: true },
    });
  ENSURE_TRANSFER_DONE.add(householdId);
}

// (#624) Mirror of `ensureUncategorizedCategory` / `ensureTransferCategory`
// for the system-managed "Ignore" category. Picked on a transaction's
// category picker to drop the row from every Budget/Reports roll-up while
// leaving balance math untouched (balance helpers sum by amount/account
// scope only and never filter by category). Stored with
// `exclude_from_budget=true` so the same Budget filter that hides
// Uncategorized/Transfer hides Ignore too. Idempotent via the
// (userId, name) unique index; also self-heals legacy rows that pre-date
// the flag by flipping it on.
async function ensureIgnoreCategory(
  householdId: string,
  userId: string,
): Promise<void> {
  if (ENSURE_IGNORE_DONE.has(householdId)) return;
  // Park it well after the canonical groups so any debug surface that
  // ignores `exclude_from_budget` still renders it last (one slot after
  // the Transfer row).
  const sortOrder = (SEED_GROUP_ORDER.length + 12) * 100;
  await db
    .insert(budgetCategoriesTable)
    .values({
      userId,
      householdId,
      name: IGNORE_CATEGORY_NAME,
      kind: "expense",
      groupName: IGNORE_CATEGORY_NAME,
      sourceKind: "manual",
      sortOrder,
      excludeFromBudget: true,
    })
    .onConflictDoUpdate({
      target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
      set: { excludeFromBudget: true },
    });
  ENSURE_IGNORE_DONE.add(householdId);
}

router.get("/budget/categories", requireAuth, async (req, res): Promise<void> => {
  const householdId = req.householdId!;
  const userId = req.userId!;
  await ensureSeededDefaults(householdId, userId);
  await ensureUncategorizedCategory(householdId, userId);
  await ensureTransferCategory(householdId, userId);
  await ensureIgnoreCategory(householdId, userId);
  const rows = await db
    .select()
    .from(budgetCategoriesTable)
    .where(eq(budgetCategoriesTable.householdId, householdId))
    .orderBy(asc(budgetCategoriesTable.sortOrder), asc(budgetCategoriesTable.name));
  res.json(rows);
});

router.post(
  "/budget/categories",
  requireAuth,
  async (req, res): Promise<void> => {
    const parsed = CreateCategoryBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }
    const data = parsed.data;
    const [row] = await db
      .insert(budgetCategoriesTable)
      .values({
        userId: req.userId!,
        householdId: req.householdId!,
        name: data.name,
        kind: data.kind ?? "expense",
        groupName: data.groupName ?? "Other",
        sourceKind: data.sourceKind ?? "manual",
        sortOrder: data.sortOrder ?? 0,
      })
      .onConflictDoUpdate({
        target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
        set: {
          kind: data.kind ?? "expense",
          ...(data.groupName ? { groupName: data.groupName } : {}),
          ...(data.sourceKind ? { sourceKind: data.sourceKind } : {}),
        },
      })
      .returning();
    res.status(201).json(row);
  },
);

// Task #692 — partial update for a category. Powers the Budget page's
// inline rename input and the up/down reorder buttons on My budget
// envelopes. Any field may be omitted; `name` collisions return 409 so
// the UI can surface a friendly "already taken" message and the user
// can re-edit without losing the input. We never let `name` be set to
// the system-managed "Uncategorized" label (it's the lazy-insert target
// for orphaned txns and renaming a user row over it would collapse two
// distinct buckets), and we coerce blank names to a 400 so the row's
// name never silently becomes "".
router.patch(
  "/budget/categories/:id",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = UpdateCategoryParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const body = UpdateCategoryBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const householdId = req.householdId!;
    const [existing] = await db
      .select()
      .from(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.id, params.data.id),
          eq(budgetCategoriesTable.householdId, householdId),
        ),
      )
      .limit(1);
    if (!existing) {
      res.status(404).json({ error: "category not found" });
      return;
    }
    const data = body.data;
    const updates: Record<string, unknown> = {};
    // (#692) Renames are restricted to sourceKind="manual" rows. The
    // auto_bills / auto_debts categories are rebuilt from their backing
    // recurring item / debt every time those change, so a rename here
    // would silently get clobbered and confuse the user. The frontend
    // already hides the rename affordance off those rows; this is the
    // server-side belt-and-suspenders.
    if (typeof data.name === "string") {
      if (existing.sourceKind !== "manual") {
        res.status(400).json({
          error:
            "Only manual categories can be renamed — bill- and debt-backed envelopes are managed automatically.",
        });
        return;
      }
      const trimmed = data.name.trim();
      if (!trimmed) {
        res.status(400).json({ error: "name cannot be blank" });
        return;
      }
      if (trimmed === UNCATEGORIZED_CATEGORY_NAME) {
        res.status(400).json({
          error: `name "${UNCATEGORIZED_CATEGORY_NAME}" is reserved`,
        });
        return;
      }
      // (#701) Pre-check duplicates so we return a friendly 409 with the
      // taken name in the message, instead of letting the (household_id,
      // name) unique index throw a generic 500. The UI surfaces this
      // verbatim as a destructive toast.
      if (trimmed !== existing.name) {
        const [dup] = await db
          .select({ id: budgetCategoriesTable.id })
          .from(budgetCategoriesTable)
          .where(
            and(
              eq(budgetCategoriesTable.householdId, householdId),
              eq(budgetCategoriesTable.name, trimmed),
            ),
          )
          .limit(1);
        if (dup && dup.id !== existing.id) {
          res.status(409).json({
            error: `A category named "${trimmed}" already exists.`,
          });
          return;
        }
      }
      updates.name = trimmed;
    }
    if (typeof data.sortOrder === "number") {
      updates.sortOrder = data.sortOrder;
    }
    if (Object.keys(updates).length === 0) {
      res.json(existing);
      return;
    }
    try {
      const [row] = await db
        .update(budgetCategoriesTable)
        .set(updates)
        .where(
          and(
            eq(budgetCategoriesTable.id, params.data.id),
            eq(budgetCategoriesTable.householdId, householdId),
          ),
        )
        .returning();
      if (!row) {
        res.status(404).json({ error: "not found" });
        return;
      }
      res.json(row);
    } catch (e) {
      // Race-condition fallback for the unique-name pre-check above.
      const msg = (e as Error).message ?? "";
      if (/unique|duplicate/i.test(msg) && typeof updates.name === "string") {
        res.status(409).json({
          error: `A category named "${updates.name}" already exists.`,
        });
        return;
      }
      throw e;
    }
  },
);

router.delete(
  "/budget/categories/:id",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = DeleteCategoryParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    await db
      .delete(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.id, params.data.id),
          eq(budgetCategoriesTable.householdId, req.householdId!),
        ),
      );
    res.sendStatus(204);
  },
);

// Per-user gates for the lazy seed-defaults heal triggered from
// GET /budget/categories. The transaction body itself is fully
// idempotent, but on a fresh user it does ~50 inserts, so we only
// want to pay for it on the first /budget/categories hit per process.
//
// Three pieces of state cooperate:
//   - DONE: terminal "this user already has the seed". Skips all work.
//   - INFLIGHT: shared Promise for the currently-running seed attempt
//     so two concurrent first GETs from the same user share one pass
//     instead of double-seeding (which a Set-only gate would allow).
//   - FAILED_AT: cooldown timestamp so a persistent seed failure
//     doesn't hot-loop on every poll.
const ENSURE_SEEDED_DEFAULTS_DONE = new Set<string>();
const ENSURE_SEEDED_DEFAULTS_INFLIGHT = new Map<string, Promise<void>>();
const ENSURE_SEEDED_DEFAULTS_FAILED_AT = new Map<string, number>();
const ENSURE_SEEDED_DEFAULTS_FAILURE_COOLDOWN_MS = 60_000;

async function seedDefaultsForUser(
  householdId: string,
  userId: string,
): Promise<{
  categoriesInserted: number;
  linesInserted: number;
  mappingRulesInserted: number;
  alreadySeeded: boolean;
}> {
  return db.transaction(async (tx) => {
      const existing = await tx
        .select()
        .from(budgetCategoriesTable)
        .where(eq(budgetCategoriesTable.householdId, householdId));
      const byName = new Map(existing.map((c) => [c.name, c]));

      let categoriesInserted = 0;
      const sortOrderByGroup = new Map<string, number>();
      SEED_GROUP_ORDER.forEach((g, i) => sortOrderByGroup.set(g, i * 100));

      for (let i = 0; i < SEED_CATEGORIES.length; i++) {
        const seed = SEED_CATEGORIES[i]!;
        const groupBase = sortOrderByGroup.get(seed.groupName) ?? 9999;
        const sortOrder = groupBase + i;
        const cur = byName.get(seed.name);
        if (!cur) {
          // onConflictDoUpdate keeps the seed transaction safe when
          // another code path (e.g. ensureUncategorizedCategory called
          // from POST /transactions) has already inserted a row with
          // the same (householdId, name) before this lazy seed fires. The
          // update is a no-op shape-wise; we just need a returning row
          // to populate byName for downstream budget_lines linking.
          const [row] = await tx
            .insert(budgetCategoriesTable)
            .values({
              userId,
              householdId,
              name: seed.name,
              kind: seed.kind,
              groupName: seed.groupName,
              sourceKind: seed.sourceKind,
              sortOrder,
              excludeFromBudget: seed.excludeFromBudget ?? false,
            })
            .onConflictDoUpdate({
              target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
              set: {
                groupName: seed.groupName,
                sourceKind: seed.sourceKind,
                kind: seed.kind,
                excludeFromBudget: seed.excludeFromBudget ?? false,
                sortOrder,
              },
            })
            .returning();
          if (row) byName.set(row.name, row);
          categoriesInserted++;
        } else if (
          cur.groupName !== seed.groupName ||
          cur.sourceKind !== seed.sourceKind ||
          cur.kind !== seed.kind ||
          cur.excludeFromBudget !== (seed.excludeFromBudget ?? false)
        ) {
          // Backfill metadata for existing categories without overwriting their identity.
          await tx
            .update(budgetCategoriesTable)
            .set({
              groupName: seed.groupName,
              sourceKind: seed.sourceKind,
              kind: seed.kind,
              excludeFromBudget: seed.excludeFromBudget ?? false,
              sortOrder,
            })
            .where(eq(budgetCategoriesTable.id, cur.id));
        }
      }

      // Ensure budget month row.
      await tx
        .insert(budgetMonthsTable)
        .values({ userId, householdId, monthStart: SEED_MONTH })
        .onConflictDoNothing();

      // Seed recurring items that back auto_bills budget categories.
      // Bills link by `categoryName` (so the recurring row name and category
      // name can differ); legacy/income items fall back to a name match.
      // Idempotent skip-by-name at the *group* level: if the household already
      // has any recurring row with a given seed name we leave the entire
      // group untouched (preserves user edits). Duplicate names in the seed
      // (e.g. two PlayStation Network rows on day 5 / day 16) are still
      // inserted atomically on a fresh household because the existence check
      // runs against the pre-seed table snapshot only.
      const existingRecurring = await tx
        .select()
        .from(recurringItemsTable)
        .where(eq(recurringItemsTable.householdId, householdId));
      const existingRecurringNames = new Set(existingRecurring.map((r) => r.name));
      for (const r of SEED_RECURRING_ITEMS) {
        if (existingRecurringNames.has(r.name)) continue;
        const cat = byName.get(r.categoryName ?? r.name);
        await tx.insert(recurringItemsTable).values({
          userId,
          householdId,
          name: r.name,
          kind: r.kind,
          amount: r.amount,
          frequency: r.frequency,
          dayOfMonth: r.dayOfMonth,
          anchorDate: r.anchorDate,
          active: "true",
          categoryId: cat?.id ?? null,
        });
      }

      const existingLines = await tx
        .select()
        .from(budgetLinesTable)
        .where(
          and(
            eq(budgetLinesTable.householdId, householdId),
            eq(budgetLinesTable.monthStart, SEED_MONTH),
          ),
        );
      const lineByCat = new Map(existingLines.map((l) => [l.categoryId, l]));

      let linesInserted = 0;
      for (const seed of SEED_CATEGORIES) {
        // (#474) Excluded categories (e.g. Uncategorized) never get a
        // budget_lines row — they're not part of the budget.
        if (seed.excludeFromBudget) continue;
        const cat = byName.get(seed.name);
        if (!cat) continue;
        const cur = lineByCat.get(cat.id);
        if (!cur) {
          await tx
            .insert(budgetLinesTable)
            .values({
              userId,
              householdId,
              monthStart: SEED_MONTH,
              categoryId: cat.id,
              plannedAmount: seed.planned,
              note: seed.note,
            })
            .onConflictDoNothing({
              target: [
                budgetLinesTable.householdId,
                budgetLinesTable.monthStart,
                budgetLinesTable.categoryId,
              ],
            });
          linesInserted++;
        } else if (cur.note == null && seed.note != null) {
          // Backfill missing notes only; do not overwrite planned amount.
          await tx
            .update(budgetLinesTable)
            .set({ note: seed.note })
            .where(eq(budgetLinesTable.id, cur.id));
        }
      }

      // Seed mapping rules. Idempotent on (householdId, pattern) — we skip seeding
      // any pattern the household already has a rule for. Existing user-created
      // rules (including different categoryId mappings for the same pattern)
      // are left untouched so manual customizations survive re-seeds.
      const existingRules = await tx
        .select()
        .from(mappingRulesTable)
        .where(eq(mappingRulesTable.householdId, householdId));
      const existingPatterns = new Set(
        existingRules.map((r) => r.pattern.toLowerCase()),
      );
      let mappingRulesInserted = 0;
      for (const seed of SEED_MAPPING_RULES) {
        if (existingPatterns.has(seed.pattern.toLowerCase())) continue;
        const cat = byName.get(seed.categoryName);
        if (!cat) continue;
        await tx.insert(mappingRulesTable).values({
          userId,
          householdId,
          pattern: seed.pattern,
          matchType: "contains",
          categoryId: cat.id,
          priority: SEED_MAPPING_PRIORITY,
        });
        mappingRulesInserted++;
      }

      return {
        categoriesInserted,
        linesInserted,
        mappingRulesInserted,
        alreadySeeded:
          categoriesInserted === 0 &&
          linesInserted === 0 &&
          mappingRulesInserted === 0,
      };
    });
}

// (#594-followup) Lazy-trigger the seed on the first read, so e2e
// specs that just call GET /budget/categories (and poll for length>0)
// see the full default seed without depending on the frontend
// useEffect that fires on /budget mount. Per-process gated.
async function ensureSeededDefaults(
  householdId: string,
  userId: string,
): Promise<void> {
  if (ENSURE_SEEDED_DEFAULTS_DONE.has(householdId)) return;
  const existingInflight = ENSURE_SEEDED_DEFAULTS_INFLIGHT.get(householdId);
  if (existingInflight) {
    // Concurrent first-hit: piggy-back on the in-flight attempt instead of
    // running a second seed transaction in parallel (which would duplicate
    // ~50 inserts and risk unique-constraint races on the seed rows).
    await existingInflight;
    return;
  }
  const failedAt = ENSURE_SEEDED_DEFAULTS_FAILED_AT.get(householdId);
  if (
    failedAt !== undefined &&
    Date.now() - failedAt < ENSURE_SEEDED_DEFAULTS_FAILURE_COOLDOWN_MS
  ) {
    // Recent failure: don't hot-loop on every poll. The cooldown still
    // expires on its own so a transient DB blip eventually self-heals
    // on the next /budget/categories hit.
    return;
  }
  const attempt = (async () => {
    // Skip the seed only when every canonical SEED_CATEGORIES name is
    // already present for this household. The previous "any non-excluded
    // category exists -> skip" check produced an intermittent partial-
    // seed bug: if any other code path (or a prior failed seed) had
    // inserted even one non-excluded category before this lazy seed
    // first fired, the full seed would be skipped and downstream
    // expectations like "Dining & Coffee exists" would silently fail.
    // The seed transaction is idempotent (onConflictDoUpdate on the
    // (householdId, name) unique index) so re-running it on a partially-
    // seeded household is safe and just fills the gaps.
    const existing = await db
      .select({ name: budgetCategoriesTable.name })
      .from(budgetCategoriesTable)
      .where(eq(budgetCategoriesTable.householdId, householdId));
    const existingNames = new Set(existing.map((r) => r.name));
    const allSeedPresent = SEED_CATEGORIES.every((c) =>
      existingNames.has(c.name),
    );
    if (allSeedPresent) {
      ENSURE_SEEDED_DEFAULTS_DONE.add(householdId);
      ENSURE_SEEDED_DEFAULTS_FAILED_AT.delete(householdId);
      return;
    }
    try {
      await seedDefaultsForUser(householdId, userId);
      ENSURE_SEEDED_DEFAULTS_DONE.add(householdId);
      ENSURE_SEEDED_DEFAULTS_FAILED_AT.delete(householdId);
    } catch (err) {
      ENSURE_SEEDED_DEFAULTS_FAILED_AT.set(householdId, Date.now());
      console.error("[budget] ensureSeededDefaults failed", {
        householdId,
        userId,
        err: err instanceof Error ? err.message : String(err),
      });
    }
  })();
  ENSURE_SEEDED_DEFAULTS_INFLIGHT.set(householdId, attempt);
  try {
    await attempt;
  } finally {
    ENSURE_SEEDED_DEFAULTS_INFLIGHT.delete(householdId);
  }
}

router.post(
  "/budget/seed-defaults",
  requireAuth,
  async (req, res): Promise<void> => {
    const result = await seedDefaultsForUser(req.householdId!, req.userId!);
    ENSURE_SEEDED_DEFAULTS_DONE.add(req.householdId!);
    res.json(result);
  },
);

// One-shot endpoint to seed (or top up) the user's recurring bills. Useful
// for users who already ran /budget/seed-defaults back when it only seeded
// the 3 income items, so we don't have to re-run the whole defaults flow.
// Idempotent: skips any (name, frequency, dayOfMonth, anchorDate) row the
// user already has, and only creates the few support categories
// (Subscriptions, Discretionary, Home services) that the new bills link to.
router.post(
  "/budget/seed-bills",
  requireAuth,
  async (req, res): Promise<void> => {
    const userId = req.userId!;
    const householdId = req.householdId!;
    const result = await db.transaction(async (tx) => {
      const bills = SEED_RECURRING_ITEMS.filter((r) => r.kind !== "income");

      // 1. Ensure every category referenced by a bill exists. We only insert
      //    missing categories (planned 0, manual source) and never modify
      //    existing rows here so user customizations survive.
      const neededCategoryNames = Array.from(
        new Set(bills.map((b) => b.categoryName).filter((n): n is string => !!n)),
      );
      const existingCats = await tx
        .select()
        .from(budgetCategoriesTable)
        .where(eq(budgetCategoriesTable.householdId, householdId));
      const catByName = new Map(existingCats.map((c) => [c.name, c]));

      const sortOrderByGroup = new Map<string, number>();
      SEED_GROUP_ORDER.forEach((g, i) => sortOrderByGroup.set(g, i * 100));

      let categoriesInserted = 0;
      for (const name of neededCategoryNames) {
        if (catByName.has(name)) continue;
        const seed = SEED_CATEGORIES.find((c) => c.name === name);
        if (!seed) continue;
        const groupBase = sortOrderByGroup.get(seed.groupName) ?? 9999;
        const [row] = await tx
          .insert(budgetCategoriesTable)
          .values({
            userId,
            householdId,
            name: seed.name,
            kind: seed.kind,
            groupName: seed.groupName,
            sourceKind: seed.sourceKind,
            sortOrder: groupBase + SEED_CATEGORIES.indexOf(seed),
          })
          .onConflictDoNothing({
            target: [budgetCategoriesTable.householdId, budgetCategoriesTable.name],
          })
          .returning();
        if (row) {
          catByName.set(row.name, row);
          categoriesInserted++;
        }
      }

      // 2. Insert every missing bill. Skip-by-name at the *group* level: if
      //    the household already has any recurring row with a given seed name we
      //    skip the entire group (preserving user edits). Duplicate seed
      //    names (PlayStation Network, Kwik Trip / gas) are still inserted
      //    atomically on a fresh household because the existence check runs
      //    against the pre-seed snapshot only.
      const existingRecurring = await tx
        .select()
        .from(recurringItemsTable)
        .where(eq(recurringItemsTable.householdId, householdId));
      const existingRecurringNames = new Set(existingRecurring.map((r) => r.name));

      let billsInserted = 0;
      for (const r of bills) {
        if (existingRecurringNames.has(r.name)) continue;
        const cat = catByName.get(r.categoryName ?? r.name);
        await tx.insert(recurringItemsTable).values({
          userId,
          householdId,
          name: r.name,
          kind: r.kind,
          amount: r.amount,
          frequency: r.frequency,
          dayOfMonth: r.dayOfMonth,
          anchorDate: r.anchorDate,
          active: "true",
          categoryId: cat?.id ?? null,
        });
        billsInserted++;
      }

      return {
        categoriesInserted,
        billsInserted,
        billsTotal: bills.length,
        alreadySeeded: categoriesInserted === 0 && billsInserted === 0,
      };
    });
    res.json(result);
  },
);

router.get(
  "/budget/months/:monthStart",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = GetBudgetMonthParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const monthStart = params.data.monthStart;

    // Hard floor: data starts April 2026. A bookmarked URL or stale client
    // requesting an earlier month gets an empty payload rather than a
    // computed (and meaningless) view. Skipped before any work below.
    if (monthStart < "2026-04-01") {
      res.json({
        monthStart,
        note: null,
        lines: [],
        groups: [],
        summary: {
          income: { budget: "0.00", actual: "0.00" },
          expenses: { budget: "0.00", actual: "0.00" },
          net: { budget: "0.00", actual: "0.00" },
          percentSpent: { budget: "0.0", actual: "0.0" },
        },
      });
      return;
    }

    const householdId = req.householdId!;
    const householdOwnerId = req.householdOwnerId!;
    const userId = req.userId!;

    // One-time consolidation of the legacy budget category list (task #65).
    // Gated by a per-household flag, so it's a no-op on subsequent requests.
    await migrateBudgetCategoriesV2(householdId, householdOwnerId, userId);

    // (#474) Ensure the system-managed Uncategorized category exists and
    // carries `exclude_from_budget=true`. Idempotent — safe on every GET.
    await ensureUncategorizedCategory(householdId, userId);
    // (#607) Same treatment for the system-managed Transfer category.
    await ensureTransferCategory(householdId, userId);
    // (#624) And the system-managed Ignore category — picked to drop
    // a row from Budget/Reports roll-ups while still affecting balances.
    await ensureIgnoreCategory(householdId, userId);

    // One-time reconciliation of May 2026 planned amounts to the household's
    // canonical source-of-truth values (task #106). Only runs when this
    // request is for May 2026; gated by a per-household flag thereafter.
    if (monthStart === MAY_2026_MONTH) {
      await reconcileMay2026Amounts(householdId, householdOwnerId, userId);
    }

    // Pull the live Debts tracker into auto_debts categories/lines for this
    // month before reading anything back. Each call ensures the budget rows
    // match the current Debts state (adds, removes, renames, min changes).
    await syncAutoDebtCategories(householdId, userId, monthStart);

    // Ensure every active recurring bill/income (including ones added on the
    // fly via Forecast Review's "Add as bill" flow) has an `auto_bills`
    // budget category linked to it, so the bill appears as a budget line
    // for monthly budgeting. No-op for items already linked to a curated
    // category (e.g. "Utilities" rolling up several bills).
    await healLegacyRecurringBillLinks(householdId);
    await syncAutoBillsFromRecurring(householdId, userId);

    // Ensure the system-managed "Avalanche payment" line is present and
    // mirrors avalancheSettings.manualExtra for this month.
    await syncAvalanchePaymentCategory(householdId, householdOwnerId, monthStart);

    const [month] = await db
      .select()
      .from(budgetMonthsTable)
      .where(
        and(
          eq(budgetMonthsTable.householdId, householdId),
          eq(budgetMonthsTable.monthStart, monthStart),
        ),
      );

    const allCats = await db
      .select()
      .from(budgetCategoriesTable)
      .where(eq(budgetCategoriesTable.householdId, householdId))
      .orderBy(asc(budgetCategoriesTable.sortOrder), asc(budgetCategoriesTable.name));

    // (#474) Filter out `exclude_from_budget` categories (today: just the
    // system-managed "Uncategorized" row) before computing planned/actual
    // roll-ups. Their actuals contribute to nothing — same treatment as
    // transfers. They never appear as a line, in a group, or in the
    // month-summary totals.
    const cats = allCats.filter((c) => !c.excludeFromBudget);

    let lines = await db
      .select()
      .from(budgetLinesTable)
      .where(
        and(
          eq(budgetLinesTable.householdId, householdId),
          eq(budgetLinesTable.monthStart, monthStart),
        ),
      );

    // Carry-forward: for every MANUAL category that doesn't yet have a line
    // this month, copy the most recent prior month's planned amount + note
    // from that same category. Auto-pulled categories (auto_bills/auto_debts)
    // are skipped — their amounts derive from Bills/Debts on each request.
    //
    // We can't just gate on `lines.length === 0` here because
    // syncAutoDebtCategories above may have already inserted auto_debts lines
    // for this month, which would make every future-month carry-forward a
    // no-op (the bug that left June+ showing $0 across the manual rows).
    {
      const manualCategoryIds = cats
        .filter((c) => c.sourceKind === "manual")
        .map((c) => c.id);

      if (manualCategoryIds.length > 0) {
        const haveLineForCat = new Set(
          lines
            .filter((l) => manualCategoryIds.includes(l.categoryId))
            .map((l) => l.categoryId),
        );
        const missingManualIds = manualCategoryIds.filter(
          (id) => !haveLineForCat.has(id),
        );

        if (missingManualIds.length > 0) {
          // For each missing manual category, find its most recent prior
          // line (across all prior months) and clone its planned amount +
          // note into this month. Done with a single SQL query using a
          // window function so we get one row per category.
          const priorLines = await db.execute<{
            category_id: string;
            planned_amount: string;
            note: string | null;
          }>(sql`
            SELECT category_id, planned_amount, note
            FROM (
              SELECT
                category_id,
                planned_amount,
                note,
                ROW_NUMBER() OVER (
                  PARTITION BY category_id
                  ORDER BY month_start DESC
                ) AS rn
              FROM budget_lines
              WHERE household_id = ${householdId}
                AND month_start < ${monthStart}
                AND category_id IN (${sql.join(
                  missingManualIds.map((id) => sql`${id}`),
                  sql`, `,
                )})
            ) t
            WHERE rn = 1
          `);

          // node-postgres returns a QueryResult with `.rows`; older drizzle
          // typings sometimes hint an array directly. Handle both shapes.
          const carry = (
            Array.isArray(priorLines)
              ? priorLines
              : ((priorLines as unknown as { rows?: unknown[] }).rows ?? [])
          ) as Array<{
            category_id: string;
            planned_amount: string;
            note: string | null;
          }>;

          if (carry.length > 0) {
            await db
              .insert(budgetMonthsTable)
              .values({ userId, householdId, monthStart })
              .onConflictDoNothing();

            await db
              .insert(budgetLinesTable)
              .values(
                carry.map((l) => ({
                  userId,
                  householdId,
                  monthStart,
                  categoryId: l.category_id,
                  plannedAmount: l.planned_amount,
                  note: l.note,
                })),
              )
              .onConflictDoNothing({
                target: [
                  budgetLinesTable.householdId,
                  budgetLinesTable.monthStart,
                  budgetLinesTable.categoryId,
                ],
              });

            lines = await db
              .select()
              .from(budgetLinesTable)
              .where(
                and(
                  eq(budgetLinesTable.householdId, householdId),
                  eq(budgetLinesTable.monthStart, monthStart),
                ),
              );
          }
        }
      }
    }

    // Source-derived planned amounts for auto categories. We compute these
    // on the fly from Bills (recurring_items) and Debts so they always reflect
    // the current source values, regardless of what (if anything) was carried
    // forward into this month's budget_lines.
    const monthEnd0 = new Date(monthStart);
    monthEnd0.setMonth(monthEnd0.getMonth() + 1);
    const monthEndStr0 = monthEnd0.toISOString().slice(0, 10);
    const monthFromDate = parseISO(monthStart);
    const monthToDate = addDays(parseISO(monthEndStr0), -1);

    const autoDebtCats = cats.filter((c) => c.sourceKind === "auto_debts");

    const autoPlannedByCat = new Map<string, string>();
    const billBackedCatIds = new Set<string>();
    type LinkedBill = {
      id: string;
      name: string;
      amount: string;
      frequency: string;
      eventCount: number;
    };
    const linkedBillsByCat = new Map<string, LinkedBill[]>();

    // Roll every active recurring item (bills + income + one-off) into the
    // category it points at, regardless of that category's source_kind.
    // Manual categories with linked bills become "bill-backed": their
    // planned amount is the sum of expanded events for the viewed month
    // instead of the manually-entered budget_lines value. This is what
    // lets a user assign State Farm + TruStage to "Insurance" and see the
    // sum on the Budget page automatically.
    {
      const catIdSet = new Set(cats.map((c) => c.id));
      const recurring = await db
        .select()
        .from(recurringItemsTable)
        .where(eq(recurringItemsTable.householdId, householdId));
      const sums = new Map<string, number>();
      for (const r of recurring) {
        if (r.active === "false") continue;
        if (!r.categoryId || !catIdSet.has(r.categoryId)) continue;
        const events = expandItem(r, monthFromDate, monthToDate);
        let total = 0;
        for (const ev of events) total += Math.abs(ev.amount);
        if (events.length > 0) {
          sums.set(r.categoryId, (sums.get(r.categoryId) ?? 0) + total);
        } else if (!sums.has(r.categoryId)) {
          // Item is linked to this category but produces no events this
          // month (e.g. one-time bill in a different month, biweekly with
          // 0 hits). The category still counts as bill-backed so the line
          // shows $0.00 from bills rather than the carried-forward amount.
          sums.set(r.categoryId, 0);
        }
        billBackedCatIds.add(r.categoryId);
        const arr = linkedBillsByCat.get(r.categoryId) ?? [];
        arr.push({
          id: r.id,
          name: r.name,
          amount: total.toFixed(2),
          frequency: r.frequency ?? "monthly",
          eventCount: events.length,
        });
        linkedBillsByCat.set(r.categoryId, arr);
      }
      for (const [catId, total] of sums) {
        autoPlannedByCat.set(catId, total.toFixed(2));
      }
    }

    if (autoDebtCats.length > 0) {
      const debts = await db
        .select()
        .from(debtsTable)
        .where(eq(debtsTable.householdId, householdId));
      const activeDebts = debts
        .filter((d) => d.status === "active")
        .sort((a, b) => b.name.length - a.name.length);
      for (const cat of autoDebtCats) {
        const match = activeDebts.find((d) => cat.name.includes(d.name));
        if (match) {
          autoPlannedByCat.set(cat.id, parseFloat(match.minPayment).toFixed(2));
        }
      }
    }

    const monthEnd = new Date(monthStart);
    monthEnd.setMonth(monthEnd.getMonth() + 1);
    const monthEndStr = monthEnd.toISOString().slice(0, 10);

    // Spend / inflow aggregation. Bank-style sources (Plaid bank, manual,
    // import) follow the standard convention: NEGATIVE amounts are spend,
    // POSITIVE amounts are inflow. Amex (`source='amex'`) uses the canonical
    // Amex convention (Task #93/#130): POSITIVE amounts are charges (spend),
    // NEGATIVE amounts are payments / credits (inflow). Transfers are
    // excluded from both totals. We also break down by source so the budget
    // row can show "Bank" / "Amex" counts.
    const actuals = await db
      .select({
        categoryId: transactionsTable.categoryId,
        source: transactionsTable.source,
        spend: sql<string>`coalesce(sum(case
          when ${transactionsTable.source} = 'amex' and ${transactionsTable.amount} > 0 then ${transactionsTable.amount}
          when ${transactionsTable.source} <> 'amex' and ${transactionsTable.amount} < 0 then -${transactionsTable.amount}
          else 0 end)::text, '0')`,
        inflow: sql<string>`coalesce(sum(case
          when ${transactionsTable.source} = 'amex' and ${transactionsTable.amount} < 0 then -${transactionsTable.amount}
          when ${transactionsTable.source} <> 'amex' and ${transactionsTable.amount} > 0 then ${transactionsTable.amount}
          else 0 end)::text, '0')`,
        cnt: sql<string>`count(*)::text`,
      })
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.householdId, householdId),
          sql`${transactionsTable.occurredOn} >= ${monthStart}`,
          sql`${transactionsTable.occurredOn} < ${monthEndStr}`,
          eq(transactionsTable.isTransfer, false),
        ),
      )
      .groupBy(transactionsTable.categoryId, transactionsTable.source);

    type SourceBucket = { source: string; count: number; amount: number };
    const spendByCat = new Map<string, number>();
    const inflowByCat = new Map<string, number>();
    const breakdownByCat = new Map<string, SourceBucket[]>();
    for (const a of actuals) {
      if (!a.categoryId) continue;
      const spend = parseFloat(a.spend) || 0;
      const inflow = parseFloat(a.inflow) || 0;
      spendByCat.set(a.categoryId, (spendByCat.get(a.categoryId) ?? 0) + spend);
      inflowByCat.set(
        a.categoryId,
        (inflowByCat.get(a.categoryId) ?? 0) + inflow,
      );
      const arr = breakdownByCat.get(a.categoryId) ?? [];
      arr.push({
        source: a.source,
        count: parseInt(a.cnt, 10) || 0,
        amount: spend > 0 ? spend : inflow,
      });
      breakdownByCat.set(a.categoryId, arr);
    }
    const linesByCat = new Map(lines.map((l) => [l.categoryId, l]));

    const monthPinned = month?.pinned === true;
    // Per-line `pinned` is authoritative: a month-level pin marks every
    // auto line as pinned at pin time (see POST /budget/months/:m/pin),
    // but a user can later flip a single line back to `pinned = false`
    // to opt that one line back into live derivation while the rest of
    // the month stays snapshotted. (task #780)
    const responseLines = cats.map((c) => {
      const line = linesByCat.get(c.id);
      const actualNum =
        c.kind === "income"
          ? inflowByCat.get(c.id) ?? 0
          : spendByCat.get(c.id) ?? 0;
      const derived = autoPlannedByCat.get(c.id);
      // For auto-pulled categories, the user can "pin" a month — or an
      // individual line — so the persisted budget_lines value is preferred
      // over the live Bills/Debts derivation. This lets the user lock in
      // a monthly amount (e.g. one paycheck of $4,499.99) instead of the
      // 2–3 biweekly events that the recurring-item expansion would yield
      // for some months. Manual categories are unaffected. (task #115)
      // A category is "auto-derived" when it's an auto_bills/auto_debts row
      // (paychecks, debt mins) OR it's a manual category that has at least
      // one recurring item linked to it (bill-backed envelope, e.g.
      // Insurance = State Farm + TruStage). Pinning still wins so the user
      // can lock a snapshot value in either case.
      const isAuto = c.sourceKind !== "manual" || billBackedCatIds.has(c.id);
      const linePinned = line?.pinned === true;
      const usePinnedLine = isAuto && line !== undefined && linePinned;
      const plannedAmount = usePinnedLine
        ? line!.plannedAmount
        : isAuto && derived !== undefined
          ? derived
          : line?.plannedAmount ?? "0";
      const buckets = breakdownByCat.get(c.id) ?? [];
      // Collapse "plaid:bank", "plaid:capitalone", etc. into a single "Bank"
      // bucket; Amex stays as Amex; everything else (manual, import) groups
      // under "Other" so the badge row stays compact.
      type Label = "Bank" | "Amex" | "Other";
      const labelFor = (s: string): Label => {
        if (s === "amex") return "Amex";
        if (s.startsWith("plaid:amex")) return "Amex";
        if (s.startsWith("plaid:")) return "Bank";
        return "Other";
      };
      const grouped = new Map<Label, { count: number; amount: number }>();
      for (const b of buckets) {
        const k = labelFor(b.source);
        const cur = grouped.get(k) ?? { count: 0, amount: 0 };
        cur.count += b.count;
        cur.amount += b.amount;
        grouped.set(k, cur);
      }
      const sourceBreakdown = Array.from(grouped.entries()).map(
        ([label, v]) => ({
          source: label,
          count: v.count,
          amount: v.amount.toFixed(2),
        }),
      );
      // Provenance for the Budgeted amount, surfaced in the UI as a
      // "where did this come from?" popover. Order matters: pinned wins
      // over bills which wins over derived (auto_debts) which wins over
      // plain manual.
      const linkedBills = linkedBillsByCat.get(c.id) ?? [];
      const plannedSourceKind: "pinned" | "bills" | "derived" | "manual" =
        usePinnedLine
          ? "pinned"
          : linkedBills.length > 0
            ? "bills"
            : c.sourceKind === "auto_debts" && derived !== undefined
              ? "derived"
              : "manual";
      const plannedSource = {
        kind: plannedSourceKind,
        bills: linkedBills,
      };
      return {
        id: line?.id ?? null,
        categoryId: c.id,
        categoryName: c.name,
        plannedAmount,
        actualAmount: actualNum.toFixed(2),
        note: line?.note ?? null,
        groupName: c.groupName,
        sourceKind: c.sourceKind,
        sortOrder: c.sortOrder,
        kind: c.kind,
        pinned: usePinnedLine,
        sourceBreakdown,
        plannedSource,
      };
    });

    // Group by groupName, ordering by SEED_GROUP_ORDER first then any extra groups alphabetically.
    const groupMap = new Map<string, typeof responseLines>();
    for (const l of responseLines) {
      const arr = groupMap.get(l.groupName) ?? [];
      arr.push(l);
      groupMap.set(l.groupName, arr);
    }
    const orderIdx = new Map(SEED_GROUP_ORDER.map((g, i) => [g, i]));
    const orderedGroups = Array.from(groupMap.keys()).sort((a, b) => {
      const ai = orderIdx.has(a) ? orderIdx.get(a)! : 1000;
      const bi = orderIdx.has(b) ? orderIdx.get(b)! : 1000;
      if (ai !== bi) return ai - bi;
      return a.localeCompare(b);
    });

    // Always include the canonical groups even if empty, so the UI shows them in order.
    for (const g of SEED_GROUP_ORDER) {
      if (!groupMap.has(g)) {
        groupMap.set(g, []);
        orderedGroups.push(g);
      }
    }
    // Task #690 — "My budget" is a dedicated manual bucket the Budget page
    // renders below the bill-backed groups. Always include it so a user
    // who hasn't added any personal envelopes yet still sees the section
    // and can add their first line.
    if (!groupMap.has(MY_BUDGET_GROUP)) {
      groupMap.set(MY_BUDGET_GROUP, []);
      orderedGroups.push(MY_BUDGET_GROUP);
    }
    // Re-dedupe orderedGroups while preserving order. "My budget" is
    // appended last so it never elbows into the canonical seed groups.
    const seen = new Set<string>();
    const finalGroupOrder = [];
    for (const g of [...SEED_GROUP_ORDER, ...orderedGroups, MY_BUDGET_GROUP]) {
      if (seen.has(g)) continue;
      seen.add(g);
      if (groupMap.has(g)) finalGroupOrder.push(g);
    }

    const groups = finalGroupOrder.map((groupName) => {
      const items = (groupMap.get(groupName) ?? []).slice().sort(
        (a, b) => a.sortOrder - b.sortOrder || a.categoryName.localeCompare(b.categoryName),
      );
      let plannedTotal = 0;
      let actualTotal = 0;
      for (const l of items) {
        plannedTotal += parseFloat(l.plannedAmount) || 0;
        actualTotal += parseFloat(l.actualAmount) || 0;
      }
      return {
        groupName,
        plannedTotal: plannedTotal.toFixed(2),
        actualTotal: actualTotal.toFixed(2),
        lines: items,
      };
    });

    let incomeBudget = 0;
    let incomeActual = 0;
    let expenseBudget = 0;
    let expenseActual = 0;
    for (const l of responseLines) {
      const planned = parseFloat(l.plannedAmount) || 0;
      const actual = parseFloat(l.actualAmount) || 0;
      if (l.kind === "income") {
        incomeBudget += planned;
        incomeActual += actual;
      } else {
        expenseBudget += planned;
        expenseActual += actual;
      }
    }
    const pct = (n: number, d: number) =>
      d > 0 ? ((n / d) * 100).toFixed(1) : "0.0";

    const summary = {
      income: { budget: incomeBudget.toFixed(2), actual: incomeActual.toFixed(2) },
      expenses: { budget: expenseBudget.toFixed(2), actual: expenseActual.toFixed(2) },
      net: {
        budget: (incomeBudget - expenseBudget).toFixed(2),
        actual: (incomeActual - expenseActual).toFixed(2),
      },
      percentSpent: {
        budget: pct(expenseBudget, incomeBudget),
        actual: pct(expenseActual, incomeActual),
      },
    };

    res.json({
      monthStart,
      note: month?.note ?? null,
      monthPinned,
      lines: responseLines,
      groups,
      summary,
    });
  },
);

router.post("/budget/lines", requireAuth, async (req, res): Promise<void> => {
  const parsed = UpsertBudgetLineBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const householdId = req.householdId!;
  const householdOwnerId = req.householdOwnerId!;
  const userId = req.userId!;
  await db
    .insert(budgetMonthsTable)
    .values({ userId, householdId, monthStart: parsed.data.monthStart })
    .onConflictDoNothing();

  const existing = await db
    .select()
    .from(budgetLinesTable)
    .where(
      and(
        eq(budgetLinesTable.householdId, householdId),
        eq(budgetLinesTable.monthStart, parsed.data.monthStart),
        eq(budgetLinesTable.categoryId, parsed.data.categoryId),
      ),
    );

  let row;
  if (existing.length > 0) {
    [row] = await db
      .update(budgetLinesTable)
      .set({
        plannedAmount: parsed.data.plannedAmount,
        note: parsed.data.note ?? null,
      })
      .where(eq(budgetLinesTable.id, existing[0]!.id))
      .returning();
  } else {
    [row] = await db
      .insert(budgetLinesTable)
      .values({ ...parsed.data, userId, householdId })
      .returning();
  }

  // If the user just edited the managed "Avalanche payment" line on the
  // Budget page, push the new amount back into avalancheSettings.manualExtra
  // so the Avalanche slider stays in sync.
  if (await isAvalanchePaymentCategory(householdId, parsed.data.categoryId)) {
    await db
      .insert(avalancheSettingsTable)
      .values({ userId: householdOwnerId, householdId, manualExtra: parsed.data.plannedAmount })
      .onConflictDoUpdate({
        target: avalancheSettingsTable.userId,
        set: {
          manualExtra: parsed.data.plannedAmount,
          updatedAt: new Date(),
        },
      });
  }
  res.json(row);
});

// Snapshot every auto-pulled category's currently displayed planned amount
// (live Bills/Debts derivation) into budget_lines for the given month. Used
// by the pin endpoints so that pinning captures whatever is on screen now,
// not whatever happens to already be persisted (which may be stale).
async function snapshotAutoLinesForMonth(
  householdId: string,
  householdOwnerId: string,
  userId: string,
  monthStart: string,
): Promise<void> {
  await syncAutoDebtCategories(householdId, userId, monthStart);
  await syncAvalanchePaymentCategory(householdId, householdOwnerId, monthStart);

  const cats = await db
    .select()
    .from(budgetCategoriesTable)
    .where(eq(budgetCategoriesTable.householdId, householdId));

  const monthEnd0 = new Date(monthStart);
  monthEnd0.setMonth(monthEnd0.getMonth() + 1);
  const monthEndStr0 = monthEnd0.toISOString().slice(0, 10);
  const monthFromDate = parseISO(monthStart);
  const monthToDate = addDays(parseISO(monthEndStr0), -1);

  const autoDebtCats = cats.filter((c) => c.sourceKind === "auto_debts");
  const autoPlannedByCat = new Map<string, string>();

  // Mirror the GET-handler model: roll every active recurring item into
  // its linked categoryId regardless of the category's source_kind.
  {
    const catIdSet = new Set(cats.map((c) => c.id));
    const recurring = await db
      .select()
      .from(recurringItemsTable)
      .where(eq(recurringItemsTable.householdId, householdId));
    const sums = new Map<string, number>();
    for (const r of recurring) {
      if (r.active === "false") continue;
      if (!r.categoryId || !catIdSet.has(r.categoryId)) continue;
      const events = expandItem(r, monthFromDate, monthToDate);
      let total = 0;
      for (const ev of events) total += Math.abs(ev.amount);
      sums.set(r.categoryId, (sums.get(r.categoryId) ?? 0) + total);
    }
    for (const [catId, total] of sums) {
      autoPlannedByCat.set(catId, total.toFixed(2));
    }
  }

  if (autoDebtCats.length > 0) {
    const debts = await db
      .select()
      .from(debtsTable)
      .where(eq(debtsTable.householdId, householdId));
    const activeDebts = debts
      .filter((d) => d.status === "active")
      .sort((a, b) => b.name.length - a.name.length);
    for (const cat of autoDebtCats) {
      const match = activeDebts.find((d) => cat.name.includes(d.name));
      if (match) {
        autoPlannedByCat.set(cat.id, parseFloat(match.minPayment).toFixed(2));
      }
    }
  }

  if (autoPlannedByCat.size === 0) return;

  await db
    .insert(budgetMonthsTable)
    .values({ userId, householdId, monthStart })
    .onConflictDoNothing();

  for (const [categoryId, planned] of autoPlannedByCat) {
    // Overwrite plannedAmount on conflict so the snapshot reflects the
    // live derivation at pin time, even if a carry-forward stub row was
    // already created for this month (e.g. for bill-backed manual
    // categories like Insurance, which the GET handler seeds via the
    // manual carry-forward path). Without this update, pinning would
    // freeze the carry-forward value instead of what the user actually
    // sees on screen. (task #780)
    await db
      .insert(budgetLinesTable)
      .values({ userId, householdId, monthStart, categoryId, plannedAmount: planned })
      .onConflictDoUpdate({
        target: [
          budgetLinesTable.householdId,
          budgetLinesTable.monthStart,
          budgetLinesTable.categoryId,
        ],
        set: { plannedAmount: planned },
      });
  }
}

router.post(
  "/budget/months/:monthStart/pin",
  requireAuth,
  async (req, res): Promise<void> => {
    const params = PinBudgetMonthParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }
    const body = PinBudgetMonthBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const householdId = req.householdId!;
    const householdOwnerId = req.householdOwnerId!;
    const userId = req.userId!;
    const { monthStart } = params.data;
    const { pinned } = body.data;

    if (pinned) {
      // Snapshot whatever the live derivation currently shows so the pin
      // captures what the user sees on screen.
      await snapshotAutoLinesForMonth(householdId, householdOwnerId, userId, monthStart);
    }

    await db
      .insert(budgetMonthsTable)
      .values({ userId, householdId, monthStart, pinned })
      .onConflictDoUpdate({
        target: [budgetMonthsTable.householdId, budgetMonthsTable.monthStart],
        set: { pinned },
      });

    // Per-line `pinned` is now the source of truth in the response
    // builder (task #780): mark every line in the month with the new
    // pinned state, and the response gates by `isAuto` so manual
    // non-bill-backed rows are unaffected on read. This deliberately
    // covers bill-backed manual categories (e.g. Insurance = State Farm
    // + TruStage), which the response treats as auto-derived even
    // though their sourceKind is 'manual'. Pinning manual rows is a
    // harmless no-op for the response builder.
    await db
      .update(budgetLinesTable)
      .set({ pinned })
      .where(
        and(
          eq(budgetLinesTable.householdId, householdId),
          eq(budgetLinesTable.monthStart, monthStart),
        ),
      );

    const linesPinned = pinned
      ? (
          await db
            .select({ id: budgetLinesTable.id })
            .from(budgetLinesTable)
            .innerJoin(
              budgetCategoriesTable,
              eq(budgetCategoriesTable.id, budgetLinesTable.categoryId),
            )
            .where(
              and(
                eq(budgetLinesTable.householdId, householdId),
                eq(budgetLinesTable.monthStart, monthStart),
                eq(budgetLinesTable.pinned, true),
                inArray(budgetCategoriesTable.sourceKind, [
                  "auto_bills",
                  "auto_debts",
                ]),
              ),
            )
        ).length
      : 0;

    res.json({ monthStart, monthPinned: pinned, linesPinned });
  },
);

router.post(
  "/budget/lines/pin",
  requireAuth,
  async (req, res): Promise<void> => {
    const body = PinBudgetLineBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    const householdId = req.householdId!;
    const householdOwnerId = req.householdOwnerId!;
    const userId = req.userId!;
    const { monthStart, categoryId, pinned } = body.data;

    // Confirm the category is auto-pulled — pinning a manual category is
    // a no-op since manual rows already use their persisted value.
    const [cat] = await db
      .select()
      .from(budgetCategoriesTable)
      .where(
        and(
          eq(budgetCategoriesTable.householdId, householdId),
          eq(budgetCategoriesTable.id, categoryId),
        ),
      );
    if (!cat) {
      res.status(404).json({ error: "Category not found" });
      return;
    }

    if (pinned && cat.sourceKind !== "manual") {
      // Snapshot just this line's currently derived value.
      await snapshotAutoLinesForMonth(householdId, householdOwnerId, userId, monthStart);
    }

    await db
      .insert(budgetMonthsTable)
      .values({ userId, householdId, monthStart })
      .onConflictDoNothing();

    const [existing] = await db
      .select()
      .from(budgetLinesTable)
      .where(
        and(
          eq(budgetLinesTable.householdId, householdId),
          eq(budgetLinesTable.monthStart, monthStart),
          eq(budgetLinesTable.categoryId, categoryId),
        ),
      );
    if (existing) {
      await db
        .update(budgetLinesTable)
        .set({ pinned })
        .where(eq(budgetLinesTable.id, existing.id));
    } else {
      await db
        .insert(budgetLinesTable)
        .values({ userId, householdId, monthStart, categoryId, plannedAmount: "0", pinned })
        .onConflictDoNothing();
    }

    const [month] = await db
      .select()
      .from(budgetMonthsTable)
      .where(
        and(
          eq(budgetMonthsTable.householdId, householdId),
          eq(budgetMonthsTable.monthStart, monthStart),
        ),
      );

    res.json({
      monthStart,
      monthPinned: month?.pinned === true,
      linesPinned: pinned ? 1 : 0,
    });
  },
);

export default router;

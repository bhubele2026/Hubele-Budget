import {
  describe,
  it,
  expect,
  beforeAll,
  afterAll,
  beforeEach,
  vi,
} from "vitest";
import { randomUUID } from "node:crypto";
import { createServer, type Server } from "node:http";
import express from "express";
import { and, eq } from "drizzle-orm";
import { createTestHousehold } from "./_helpers/testHousehold";

const TEST_USER = `cutoff-${process.pid}-${Date.now()}-${randomUUID().slice(0, 8)}`;
let TEST_HOUSEHOLD_ID: string;

vi.mock("../middlewares/requireAuth", () => ({
  requireAuth: (
    req: {
      userId?: string;
      actualUserId?: string;
      householdId?: string;
      householdOwnerId?: string;
    },
    _res: unknown,
    next: () => void,
  ) => {
    req.userId = TEST_USER;
    req.actualUserId = TEST_USER;
    req.householdId = TEST_HOUSEHOLD_ID;
    req.householdOwnerId = TEST_USER;
    next();
  },
}));

type AddedTxn = {
  transaction_id: string;
  account_id: string;
  date: string;
  amount: number;
  name: string;
  pending?: boolean;
};

let nextSyncResponse: {
  added: AddedTxn[];
  modified: AddedTxn[];
  removed: { transaction_id: string }[];
} = { added: [], modified: [], removed: [] };

vi.mock("../lib/plaid", async () => {
  const actual =
    await vi.importActual<typeof import("../lib/plaid")>("../lib/plaid");
  return {
    ...actual,
    plaid: () => ({
      transactionsSync: async () => ({
        data: {
          added: nextSyncResponse.added,
          modified: nextSyncResponse.modified,
          removed: nextSyncResponse.removed,
          next_cursor: "cursor-1",
          has_more: false,
        },
      }),
      accountsBalanceGet: async () => ({ data: { accounts: [] } }),
      itemGet: async () => ({
        data: {
          item: { item_id: "item-default", consent_expiration_time: null },
        },
      }),
    }),
  };
});

import {
  db,
  debtsTable,
  forecastSettingsTable,
  plaidAccountsTable,
  plaidItemsTable,
  transactionsTable,
} from "@workspace/db";
import plaidRouter from "../routes/plaid";
import { syncPlaidItem } from "../lib/plaidSync";
import { autoDetectCutoffsForItem } from "../lib/plaidImportCutoff";

const app = express();
app.use(express.json());
app.use((req: { log?: unknown }, _res, next) => {
  req.log = {
    info: () => {},
    warn: () => {},
    error: () => {},
    debug: () => {},
  };
  next();
});
app.use(plaidRouter);

let server: Server;
let baseUrl: string;

async function cleanup(): Promise<void> {
  await db
    .delete(transactionsTable)
    .where(eq(transactionsTable.userId, TEST_USER));
  await db.delete(debtsTable).where(eq(debtsTable.userId, TEST_USER));
  await db
    .delete(plaidAccountsTable)
    .where(eq(plaidAccountsTable.userId, TEST_USER));
  await db.delete(plaidItemsTable).where(eq(plaidItemsTable.userId, TEST_USER));
  await db
    .delete(forecastSettingsTable)
    .where(eq(forecastSettingsTable.userId, TEST_USER));
}

beforeAll(async () => {
  const _h = await createTestHousehold(TEST_USER);
  TEST_HOUSEHOLD_ID = _h.householdId;
  await cleanup();
  server = createServer(app);
  await new Promise<void>((res) => server.listen(0, "127.0.0.1", res));
  const addr = server.address();
  if (!addr || typeof addr === "string") throw new Error("no addr");
  baseUrl = `http://127.0.0.1:${addr.port}`;
});

afterAll(async () => {
  await cleanup();
  await new Promise<void>((res) => server.close(() => res()));
});

beforeEach(async () => {
  await cleanup();
  nextSyncResponse = { added: [], modified: [], removed: [] };
});

async function seedAmexCardScenario(opts: {
  withLinkedDebt?: boolean;
  manualDates?: string[];
  amexSourceDates?: string[];
}): Promise<{
  itemRowId: string;
  acctRowId: string;
  externalAcctId: string;
  debtId: string | null;
}> {
  const [item] = await db
    .insert(plaidItemsTable)
    .values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      itemId: `item-${randomUUID()}`,
      accessToken: `access-sandbox-${randomUUID()}`,
      institutionName: "American Express",
      institutionSlug: "amex",
    })
    .returning();
  const externalAcctId = `acct-${randomUUID()}`;
  const [acct] = await db
    .insert(plaidAccountsTable)
    .values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      itemId: item!.id,
      accountId: externalAcctId,
      name: "Amex Gold",
      type: "credit",
      subtype: "credit card",
    })
    .returning();
  let debtId: string | null = null;
  if (opts.withLinkedDebt) {
    const [debt] = await db
      .insert(debtsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        name: "Amex Gold",
        balance: "1000",
        plaidAccountId: acct!.id,
      })
      .returning();
    debtId = debt!.id;
    for (const d of opts.manualDates ?? []) {
      await db.insert(transactionsTable).values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        occurredOn: d,
        description: `manual ${d}`,
        amount: "-50.00",
        source: "manual",
        debtId,
      });
    }
  }
  for (const d of opts.amexSourceDates ?? []) {
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: d,
      description: `amex import ${d}`,
      amount: "-25.00",
      source: "amex",
      debtId,
    });
  }
  return { itemRowId: item!.id, acctRowId: acct!.id, externalAcctId, debtId };
}

describe("(#361) Plaid first-sync import cutoff", () => {
  it("auto-detects the cutoff from existing manual rows on a linked credit account", async () => {
    const { itemRowId, acctRowId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-01-15", "2026-02-20", "2026-02-28"],
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.importCutoffDate).toBe("2026-02-28");
    expect(acct.firstSyncCompletedAt).toBeNull();
  });

  it("falls back to source='amex' rows when an Amex account has no linked debt yet", async () => {
    const { itemRowId, acctRowId } = await seedAmexCardScenario({
      withLinkedDebt: false,
      amexSourceDates: ["2026-03-01", "2026-03-10"],
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.importCutoffDate).toBe("2026-03-10");
  });

  it("first sync skips added rows on/before the cutoff and stamps firstSyncCompletedAt", async () => {
    const { itemRowId, acctRowId, externalAcctId } =
      await seedAmexCardScenario({
        withLinkedDebt: true,
        manualDates: ["2026-02-28"],
      });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-old-1",
          account_id: externalAcctId,
          date: "2026-02-10",
          amount: 12.34,
          name: "Old purchase before cutoff",
        },
        {
          transaction_id: "plaid-on-cutoff",
          account_id: externalAcctId,
          date: "2026-02-28",
          amount: 99.0,
          name: "On cutoff (no manual match) — skipped",
        },
        {
          transaction_id: "plaid-new-1",
          account_id: externalAcctId,
          date: "2026-03-05",
          amount: 7.5,
          name: "After cutoff — kept",
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const txns = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, TEST_USER));
    const plaidIds = txns
      .map((t) => t.plaidTransactionId)
      .filter((x): x is string => x !== null)
      .sort();
    expect(plaidIds).toEqual(["plaid-new-1"]);
    // Manual row preserved untouched.
    const manualRows = txns.filter((t) => t.source === "manual");
    expect(manualRows).toHaveLength(1);
    expect(manualRows[0].plaidTransactionId).toBeNull();

    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.firstSyncCompletedAt).not.toBeNull();
  });

  it("merges a near-cutoff added row into a matching manual row by adopting plaidTransactionId", async () => {
    const { itemRowId, externalAcctId, debtId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-26"],
    });
    // Pre-seed a separate manual row at $42 on 2026-02-26 that the
    // sync's added row should merge with (same date, amount, debt
    // scope, source=manual, plaidTransactionId NULL).
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: "2026-02-26",
      description: "Coffee — manually entered before link",
      amount: "-42.00",
      source: "manual",
      debtId,
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");

    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-merge-target",
          account_id: externalAcctId,
          // 1 day before the cutoff (2026-02-26): inside ±7d so the
          // merge path runs first; also <= cutoff so without the merge
          // it would be skipped instead of duplicated.
          date: "2026-02-26",
          amount: 42.0,
          name: "Coffee shop",
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const matched = await db
      .select()
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, TEST_USER),
          eq(transactionsTable.plaidTransactionId, "plaid-merge-target"),
        ),
      );
    expect(matched).toHaveLength(1);
    // (#452) The merge now upgrades `source` to `plaid:<slug>` so the
    // surviving row no longer claims to be a manual entry.
    expect(matched[0].source).toBe("plaid:amex");
    expect(matched[0].amount).toBe("-42.00");
    expect(matched[0].description).toBe("Coffee — manually entered before link");
  });

  it("(#452) absorbs a manual row dated well before the cutoff (no longer a ±7-day window)", async () => {
    const { itemRowId, externalAcctId, debtId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-28"],
    });
    // A manual row dated Jan 5 — six weeks before the cutoff. The
    // pre-#452 ±7-day gate would have left it stranded AND would have
    // skipped Plaid's matching row, leaving the user looking at a
    // stale manual line. Post-#452, anything <= cutoff is fair game.
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: "2026-01-05",
      description: "Annual fee — typed in last month",
      amount: "-95.00",
      source: "manual",
      debtId,
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");

    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-old-manual-merge",
          account_id: externalAcctId,
          date: "2026-01-05",
          amount: 95.0,
          name: "Annual Membership Fee",
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const merged = await db
      .select()
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, TEST_USER),
          eq(transactionsTable.plaidTransactionId, "plaid-old-manual-merge"),
        ),
      );
    expect(merged).toHaveLength(1);
    expect(merged[0].source).toBe("plaid:amex");
    // Description preserved from the manual row.
    expect(merged[0].description).toBe("Annual fee — typed in last month");
  });

  it("(#452) absorbs a pending→posted near-miss (±$0.01, ±3 days) instead of inserting a duplicate", async () => {
    const { itemRowId, externalAcctId, debtId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-28"],
    });
    // Manual "pending" row at $19.99 on 2026-02-25.
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: "2026-02-25",
      description: "Coffee (pending)",
      amount: "-19.99",
      source: "manual",
      debtId,
      notes: "[pending]",
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");

    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-pending-posted",
          account_id: externalAcctId,
          // 2 days later, 1¢ apart — must merge, not insert a twin.
          date: "2026-02-27",
          amount: 20.0,
          name: "Coffee shop",
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const remaining = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, TEST_USER));
    // Two manual rows seeded (the cutoff seed + the pending coffee). The
    // coffee row should now carry the Plaid id and source — not be
    // duplicated. So we still expect 2 rows total.
    expect(remaining).toHaveLength(2);
    const merged = remaining.find(
      (r) => r.plaidTransactionId === "plaid-pending-posted",
    );
    expect(merged).toBeDefined();
    expect(merged!.source).toBe("plaid:amex");
  });

  it("(#662) inserts a pending=true row even when its date is on/before the cutoff and exposes skippedPreCutoff", async () => {
    const { itemRowId, acctRowId, externalAcctId } =
      await seedAmexCardScenario({
        withLinkedDebt: true,
        manualDates: ["2026-02-28"],
      });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    nextSyncResponse = {
      added: [
        {
          // Pending Plaid row with an authorization date a couple days
          // before the cutoff — pre-#662 the gate would have silently
          // dropped it because t.date <= cutoff and no manual pre-image
          // exists to merge with.
          transaction_id: "plaid-pending-bypass",
          account_id: externalAcctId,
          date: "2026-02-26",
          amount: 502.0,
          name: "Pending Venmo charge",
          pending: true,
        },
        {
          // Posted backfill row pre-cutoff — must STILL be skipped so
          // historical Plaid noise doesn't double the user's manual
          // ledger after a relink.
          transaction_id: "plaid-posted-skipped",
          account_id: externalAcctId,
          date: "2026-02-10",
          amount: 12.34,
          name: "Posted backfill before cutoff",
        },
      ],
      modified: [],
      removed: [],
    };
    const result = await syncPlaidItem(TEST_USER, itemRowId);

    const txns = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, TEST_USER));
    const plaidIds = txns
      .map((t) => t.plaidTransactionId)
      .filter((x): x is string => x !== null)
      .sort();
    // The pending row landed; the posted backfill row was filtered out.
    expect(plaidIds).toEqual(["plaid-pending-bypass"]);
    const pending = txns.find(
      (t) => t.plaidTransactionId === "plaid-pending-bypass",
    );
    expect(pending).toBeDefined();
    // (#728) pending is now a real boolean column; the legacy
    // notes='[pending]' marker is gone.
    expect(pending!.pending).toBe(true);
    expect(pending!.notes).toBeNull();
    // The skip is now observable on the per-item result.
    expect(result.skippedPreCutoff).toBe(1);
    // Manual seed row preserved untouched.
    const manualRows = txns.filter((t) => t.source === "manual");
    expect(manualRows).toHaveLength(1);
    expect(manualRows[0].plaidTransactionId).toBeNull();
    // First sync still considered complete on this account.
    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.firstSyncCompletedAt).not.toBeNull();
  });

  it("does not gate added rows once firstSyncCompletedAt is stamped", async () => {
    const { itemRowId, acctRowId, externalAcctId } =
      await seedAmexCardScenario({
        withLinkedDebt: true,
        manualDates: ["2026-02-28"],
      });
    // Pretend the first sync already completed.
    await db
      .update(plaidAccountsTable)
      .set({
        importCutoffDate: "2026-02-28",
        firstSyncCompletedAt: new Date("2026-03-01T00:00:00Z"),
      })
      .where(eq(plaidAccountsTable.id, acctRowId));

    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-late-arrival",
          account_id: externalAcctId,
          // On the cutoff — would be skipped on first sync, must not be
          // skipped on subsequent syncs.
          date: "2026-02-28",
          amount: 5.0,
          name: "Late arrival from Plaid",
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const [hit] = await db
      .select()
      .from(transactionsTable)
      .where(
        and(
          eq(transactionsTable.userId, TEST_USER),
          eq(transactionsTable.plaidTransactionId, "plaid-late-arrival"),
        ),
      );
    expect(hit).toBeDefined();
  });

  it("removed events never delete a manual row that the merge logic never claimed", async () => {
    const { itemRowId, debtId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-15"],
    });
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: "2026-02-20",
      description: "Pure manual row",
      amount: "-9.99",
      source: "manual",
      debtId,
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");

    nextSyncResponse = {
      added: [],
      modified: [],
      removed: [{ transaction_id: "plaid-never-existed" }],
    };
    await syncPlaidItem(TEST_USER, itemRowId);

    const remaining = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, TEST_USER));
    // Both manual rows still present.
    expect(remaining.filter((t) => t.source === "manual")).toHaveLength(2);
  });

  it("PATCH /plaid/accounts/:id/import-cutoff overrides while first sync is pending and rejects after", async () => {
    const { acctRowId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-28"],
    });
    const ok = await fetch(
      `${baseUrl}/plaid/accounts/${acctRowId}/import-cutoff`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ importCutoffDate: "2026-01-01" }),
      },
    );
    expect(ok.status).toBe(200);
    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.importCutoffDate).toBe("2026-01-01");

    // Simulate first sync completion, then attempt another override.
    await db
      .update(plaidAccountsTable)
      .set({ firstSyncCompletedAt: new Date() })
      .where(eq(plaidAccountsTable.id, acctRowId));
    const denied = await fetch(
      `${baseUrl}/plaid/accounts/${acctRowId}/import-cutoff`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ importCutoffDate: "2026-04-01" }),
      },
    );
    expect(denied.status).toBe(409);

    const bad = await fetch(
      `${baseUrl}/plaid/accounts/${acctRowId}/import-cutoff`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ importCutoffDate: "not-a-date" }),
      },
    );
    expect(bad.status).toBe(400);
  });

  // (#662) Regression coverage: after a relink mints fresh
  // plaid_accounts rows (firstSyncCompletedAt = null, fresh
  // importCutoffDate ≈ today), Plaid's pending charges carry an
  // authorization date a day or two old. The pre-fix gate skipped
  // every one of them — bank showed pending, app showed nothing,
  // Sync toast said "0 added". Pending rows now bypass the gate
  // entirely; posted rows still respect it.
  it("(#662) inserts pending Plaid rows on first sync even when t.date <= cutoff (posted rows still gated)", async () => {
    const { itemRowId, acctRowId, externalAcctId } =
      await seedAmexCardScenario({
        withLinkedDebt: true,
        manualDates: ["2026-02-28"],
      });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    // Cutoff is "2026-02-28" (newest manual). The pending row dated
    // "2026-02-20" is BEFORE cutoff, no manual match at $502 — pre-fix
    // it would have been silently skipped. Post-fix it MUST insert.
    // The posted row dated "2026-02-10" with no manual match MUST
    // still be skipped (gate behavior unchanged for non-pending).
    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-pending-venmo",
          account_id: externalAcctId,
          date: "2026-02-20",
          amount: 502.0,
          name: "VENMO PAYMENT (pending)",
          pending: true,
        },
        {
          transaction_id: "plaid-posted-old",
          account_id: externalAcctId,
          date: "2026-02-10",
          amount: 9.99,
          name: "Old posted purchase, no manual match",
          pending: false,
        },
        {
          transaction_id: "plaid-posted-new",
          account_id: externalAcctId,
          date: "2026-03-05",
          amount: 7.5,
          name: "New posted purchase after cutoff",
          pending: false,
        },
      ],
      modified: [],
      removed: [],
    };
    const result = await syncPlaidItem(TEST_USER, itemRowId);

    const txns = await db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, TEST_USER));
    const plaidIds = txns
      .map((t) => t.plaidTransactionId)
      .filter((x): x is string => x !== null)
      .sort();
    // Pending row inserted despite t.date <= cutoff. Posted-after-
    // cutoff row inserted (normal path). Posted-before-cutoff row
    // skipped (gate still applies to non-pending).
    expect(plaidIds).toEqual(["plaid-pending-venmo", "plaid-posted-new"]);

    // (#728) The pending row carries pending=true on the boolean
    // column so the pending→posted reconciliation later updates it
    // in place (the legacy notes='[pending]' marker is gone).
    const pending = txns.find(
      (t) => t.plaidTransactionId === "plaid-pending-venmo",
    );
    expect(pending).toBeDefined();
    expect(pending!.pending).toBe(true);
    expect(pending!.notes).toBeNull();
    expect(pending!.amount).toBe("-502.00");

    // Manual row preserved.
    expect(txns.filter((t) => t.source === "manual")).toHaveLength(1);

    // Result surfaces the skipped count — observability hook.
    expect(result.skippedPreCutoff).toBe(1);

    // First-sync gate stays "completed" after this run.
    const [acct] = await db
      .select()
      .from(plaidAccountsTable)
      .where(eq(plaidAccountsTable.id, acctRowId));
    expect(acct.firstSyncCompletedAt).not.toBeNull();
  });

  // (#662) Lifecycle: the pending row's later posted twin (same
  // transaction_id, pending=false) arrives as a `modified` row,
  // which the gate already bypasses. The same DB row updates in
  // place via onConflictDoUpdate — no duplicate.
  it("(#662) pending→posted converges on a single row via the modified path", async () => {
    const { itemRowId, externalAcctId } = await seedAmexCardScenario({
      withLinkedDebt: true,
      manualDates: ["2026-02-28"],
    });
    await autoDetectCutoffsForItem(TEST_USER, itemRowId, "amex");
    nextSyncResponse = {
      added: [
        {
          transaction_id: "plaid-pending-then-posted",
          account_id: externalAcctId,
          date: "2026-02-25",
          amount: 85.0,
          name: "VENMO CASHOUT (pending)",
          pending: true,
        },
      ],
      modified: [],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);
    let txns = await db
      .select()
      .from(transactionsTable)
      .where(
        eq(transactionsTable.plaidTransactionId, "plaid-pending-then-posted"),
      );
    expect(txns).toHaveLength(1);
    // (#728) pending tracked via boolean column, not notes marker.
    expect(txns[0]!.pending).toBe(true);
    expect(txns[0]!.notes).toBeNull();

    // Plaid replays the same transaction_id as `modified`, now
    // posted. The cursor moves; gate doesn't re-engage on modified.
    nextSyncResponse = {
      added: [],
      modified: [
        {
          transaction_id: "plaid-pending-then-posted",
          account_id: externalAcctId,
          date: "2026-02-25",
          amount: 85.0,
          name: "VENMO CASHOUT",
          pending: false,
        },
      ],
      removed: [],
    };
    await syncPlaidItem(TEST_USER, itemRowId);
    txns = await db
      .select()
      .from(transactionsTable)
      .where(
        eq(transactionsTable.plaidTransactionId, "plaid-pending-then-posted"),
      );
    expect(txns).toHaveLength(1);
    expect(txns[0]!.notes).toBeNull();
  });
});

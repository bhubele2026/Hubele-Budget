import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from "vitest";
import { randomUUID } from "node:crypto";
import { createServer, type Server } from "node:http";
import express from "express";
import { eq } from "drizzle-orm";

// (#483) Regression coverage: when a user has Plaid-linked Amex accounts but
// no `debts` row named "Amex" (and no manual settings anchor), GET
// /amex/anchor must resolve the ending balance from the live Plaid liability
// balances cached on the linked plaid_accounts rows — not stay null and
// leave the page tile stuck on "Loading…".

const TEST_USER = `amex-plaid-${process.pid}-${Date.now()}-${randomUUID().slice(0, 8)}`;

let TEST_HOUSEHOLD_ID: string;
vi.mock("../middlewares/requireAuth", () => ({
    requireAuth: (
      req: {
        userId?: string;
        actualUserId?: string;
        householdId?: string;
        householdOwnerId?: string;
      },
      _res: unknown,
      next: () => void,
    ) => {
      req.userId = TEST_USER;
      req.actualUserId = TEST_USER;
      req.householdId = TEST_HOUSEHOLD_ID;
      req.householdOwnerId = TEST_USER;
      next();
    },
  }));

import {
  db,
  debtsTable,
  plaidAccountsTable,
  plaidItemsTable,
  settingsTable,
  transactionsTable,
} from "@workspace/db";
import amexRouter from "../routes/amex";

import { createTestHousehold } from "./_helpers/testHousehold";
const app = express();
app.use(express.json());
app.use((req: { log?: unknown }, _res, next) => {
  req.log = { info: () => {}, warn: () => {}, error: () => {}, debug: () => {} };
  next();
});
app.use(amexRouter);

let server: Server;
let baseUrl: string;

async function cleanup(): Promise<void> {
  await db.delete(transactionsTable).where(eq(transactionsTable.userId, TEST_USER));
  await db.delete(debtsTable).where(eq(debtsTable.userId, TEST_USER));
  await db
    .delete(plaidAccountsTable)
    .where(eq(plaidAccountsTable.userId, TEST_USER));
  await db.delete(plaidItemsTable).where(eq(plaidItemsTable.userId, TEST_USER));
  await db.delete(settingsTable).where(eq(settingsTable.userId, TEST_USER));
}

beforeAll(async () => {
  const _h = await createTestHousehold(TEST_USER);
  TEST_HOUSEHOLD_ID = _h.householdId;
  await cleanup();
  server = createServer(app);
  await new Promise<void>((res) => server.listen(0, "127.0.0.1", res));
  const addr = server.address();
  if (!addr || typeof addr === "string") throw new Error("no addr");
  baseUrl = `http://127.0.0.1:${addr.port}`;
});

afterAll(async () => {
  await cleanup();
  await new Promise<void>((res) => server.close(() => res()));
});

beforeEach(cleanup);

describe("GET /amex/anchor — Plaid liability fallback (#483)", () => {
  it("sums Plaid balances across multiple linked Amex accounts when no debt row matches", async () => {
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();

    const fetchedAt = new Date("2026-04-15T12:00:00.000Z");
    const olderFetchedAt = new Date("2026-04-14T08:00:00.000Z");
    await db.insert(plaidAccountsTable).values([
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-gold-${suffix}`,
        name: "Amex Gold",
        mask: "1001",
        type: "credit",
        subtype: "credit card",
        liabilityBalance: "500.25",
        liabilityLastFetchedAt: olderFetchedAt,
      },
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-platinum-${suffix}`,
        name: "Amex Platinum",
        mask: "1002",
        type: "credit",
        subtype: "credit card",
        liabilityBalance: "1200.50",
        liabilityLastFetchedAt: fetchedAt,
      },
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-blue-${suffix}`,
        name: "Amex Blue",
        mask: "1003",
        type: "credit",
        subtype: "credit card",
        liabilityBalance: "75.00",
        liabilityLastFetchedAt: olderFetchedAt,
      },
    ]);

    // No debts row for Amex; no settings anchor; no transactions yet.
    const res = await fetch(`${baseUrl}/amex/anchor`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as {
      amexEndingBalance: number | null;
      asOf: string;
      source: string;
    };
    expect(body.source).toBe("plaid");
    expect(body.amexEndingBalance).toBeCloseTo(500.25 + 1200.5 + 75.0, 2);
    // asOf is the most recent liability_last_fetched_at across the linked
    // accounts (the Platinum row).
    expect(body.asOf).toBe(fetchedAt.toISOString());
  });

  it("still falls back to Plaid balance when only transactions (no debt) exist", async () => {
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "Some Bank",
        // Intentionally non-amex slug so discovery has to come from
        // the txn-derived path instead of institution_slug.
        institutionSlug: "some-bank",
      })
      .returning();
    const externalAcct = `acct-amex-${suffix}`;
    await db.insert(plaidAccountsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      itemId: item!.id,
      accountId: externalAcct,
      name: "Amex Card",
      mask: "1010",
      type: "credit",
      subtype: "credit card",
      liabilityBalance: "321.00",
      liabilityLastFetchedAt: new Date("2026-04-20T00:00:00.000Z"),
    });
    await db.insert(transactionsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      occurredOn: "2026-04-10",
      description: "Some Amex charge",
      amount: "-50.00",
      source: "plaid:amex",
      plaidAccountId: externalAcct,
    });

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number | null;
      source: string;
    };
    expect(body.source).toBe("plaid");
    expect(body.amexEndingBalance).toBeCloseTo(321.0, 2);
  });

  it("(#651) live Plaid balance wins over a stale settings anchor", async () => {
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();
    await db.insert(plaidAccountsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      itemId: item!.id,
      accountId: `acct-${suffix}`,
      name: "Amex",
      mask: "9999",
      type: "credit",
      subtype: "credit card",
      liabilityBalance: "100.00",
      liabilityLastFetchedAt: new Date("2026-04-15T00:00:00.000Z"),
    });
    await db.insert(settingsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      preferences: {
        amexAnchor: { balance: 999.99, asOf: "2026-04-01T00:00:00.000Z" },
      },
    });

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number;
      source: string;
    };
    expect(body.source).toBe("plaid");
    expect(body.amexEndingBalance).toBeCloseTo(100.0, 2);
  });

  it("(#651) excludes non-credit sub-accounts (depository cash) from the Plaid balance sum", async () => {
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();
    const fetchedAt = new Date("2026-04-15T12:00:00.000Z");
    await db.insert(plaidAccountsTable).values([
      // Real credit-card debt — should count.
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-card-${suffix}`,
        name: "Amex Platinum",
        mask: "0001",
        type: "credit",
        subtype: "credit card",
        liabilityBalance: "1500.00",
        liabilityLastFetchedAt: fetchedAt,
      },
      // Same-login HYSA / Membership Rewards cash sub-account whose
      // generic /accounts/get balance leaked into liability_balance.
      // Pre-fix: this $2,729.43 of POSITIVE cash was being summed
      // alongside the credit-card debt, yielding -$1,229.43
      // (1500 - 2729.43) and a stale "1 week ago" timestamp on the
      // tile because /plaid/sync never re-pulled liabilities.
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-hysa-${suffix}`,
        name: "Amex High-Yield Savings",
        mask: "0002",
        type: "depository",
        subtype: "savings",
        liabilityBalance: "2729.43",
        liabilityLastFetchedAt: fetchedAt,
      },
    ]);
    // Force the depository sub-account into the discovery set via a
    // transaction tagged source=amex (mirrors the real-world bug:
    // institution_slug discovery picks both up).
    await db.insert(transactionsTable).values([
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        occurredOn: "2026-04-10",
        description: "Amex card charge",
        amount: "-50.00",
        source: "plaid:amex",
        plaidAccountId: `acct-card-${suffix}`,
      },
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        occurredOn: "2026-04-10",
        description: "HYSA interest",
        amount: "1.50",
        source: "plaid:amex",
        plaidAccountId: `acct-hysa-${suffix}`,
      },
    ]);

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number;
      source: string;
    };
    expect(body.source).toBe("plaid");
    // Only the credit-card debt counts — depository cash is excluded.
    expect(body.amexEndingBalance).toBeCloseTo(1500.0, 2);
  });

  it("(#689) excludes Amex installment/Pay-Over-Time LOAN sub-accounts from the Plaid balance sum", async () => {
    // Real-world bug: a user with an Amex personal-loan / "Plan-It"
    // installment sub-account (type='loan', $20,000 outstanding) on
    // the same Amex login was seeing the dashboard's "Amex Ending
    // Balance" tile report that loan balance as the credit-card
    // ending balance. The Amex page (and its mirror tile) is
    // specifically about the revolving credit-card liability — loan
    // sub-accounts belong on /debts, not in this sum.
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();
    const fetchedAt = new Date("2026-05-15T12:00:00.000Z");
    await db.insert(plaidAccountsTable).values([
      // Real Amex credit-card debt — should count.
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-card-${suffix}`,
        name: "Amex Platinum",
        mask: "0001",
        type: "credit",
        subtype: "credit card",
        liabilityKind: "credit",
        liabilityBalance: "742.18",
        liabilityLastFetchedAt: fetchedAt,
      },
      // Amex Plan-It installment loan, same login. Pre-(#689) this
      // $20,000 was summed into the credit-card ending balance.
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-loan-${suffix}`,
        name: "Amex Pay Over Time",
        mask: "0002",
        type: "loan",
        subtype: "loan",
        liabilityBalance: "20000.00",
        liabilityLastFetchedAt: fetchedAt,
      },
    ]);

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number;
      source: string;
    };
    expect(body.source).toBe("plaid");
    // Only the credit-card debt counts — the $20,000 loan is excluded.
    expect(body.amexEndingBalance).toBeCloseTo(742.18, 2);
  });

  it("(#689) excludes student/mortgage liability sub-accounts even when type='credit' looks ambiguous", async () => {
    // Belt-and-suspenders: even if some quirky Plaid response set
    // `type='credit'` on a non-revolving sub-account, the
    // `liability_kind` filter still keeps student / mortgage rows out.
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();
    const fetchedAt = new Date("2026-05-15T12:00:00.000Z");
    await db.insert(plaidAccountsTable).values([
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-card-${suffix}`,
        name: "Amex Gold",
        mask: "0001",
        type: "credit",
        subtype: "credit card",
        liabilityKind: "credit",
        liabilityBalance: "500.00",
        liabilityLastFetchedAt: fetchedAt,
      },
      {
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: item!.id,
        accountId: `acct-student-${suffix}`,
        name: "Some Student Loan",
        mask: "0002",
        type: "credit",
        subtype: "student",
        liabilityKind: "student",
        liabilityBalance: "15000.00",
        liabilityLastFetchedAt: fetchedAt,
      },
    ]);

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number;
      source: string;
    };
    expect(body.source).toBe("plaid");
    expect(body.amexEndingBalance).toBeCloseTo(500.0, 2);
  });

  it("returns missing when Plaid accounts exist but liability balances are null", async () => {
    const suffix = randomUUID().slice(0, 8);
    const [item] = await db
      .insert(plaidItemsTable)
      .values({
        userId: TEST_USER,
        householdId: TEST_HOUSEHOLD_ID,
        itemId: `amex-item-${suffix}`,
        accessToken: "test-no-access",
        institutionName: "American Express",
        institutionSlug: "amex",
      })
      .returning();
    await db.insert(plaidAccountsTable).values({
      userId: TEST_USER,
      householdId: TEST_HOUSEHOLD_ID,
      itemId: item!.id,
      accountId: `acct-${suffix}`,
      name: "Amex",
      mask: "9999",
      type: "credit",
      subtype: "credit card",
      // No liabilityBalance yet (Plaid sync hasn't run for this item).
    });

    const res = await fetch(`${baseUrl}/amex/anchor`);
    const body = (await res.json()) as {
      amexEndingBalance: number | null;
      source: string;
    };
    expect(body.source).toBe("missing");
    expect(body.amexEndingBalance).toBeNull();
  });
});
